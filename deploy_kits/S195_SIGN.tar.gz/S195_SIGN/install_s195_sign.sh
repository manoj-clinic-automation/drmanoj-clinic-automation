#!/bin/bash
# =====================================================================
#  S195_SIGN — the credit-note sign, in one place
#
#  WHAT WENT WRONG, 18-08-2026
#    The day held one credit note of 1,640. finance_ingest stores a
#    credit note as a MAGNITUDE plus a "_return" service, because
#    sale_item carries a non-negative constraint. Two readers summed
#    those rows with a plain SUM(amount_p), which ADDS the refund:
#
#        true net of the loaded rows   20,599.00
#        what both screens displayed   23,879.00   (out by 2 x 1,640)
#
#    That figure was near enough to the total under dispute to send a
#    real investigation down the wrong road for an hour, and it was on
#    the strength of it that the correction was nearly abandoned. The
#    guard on the medical PC had it right all along -- it reported
#    NET 25176.00 and said the credit note was "carried through
#    signed". The server did not.
#
#  THE FIX
#    marg_net_sql() -- ONE SQL expression, used by every reader:
#      * api_day_mirror        (the maker's reveal -- the one that lied)
#      * /finance/api/workbench/<ym>  (the checker's month grid)
#      * _marg_month_compare   (A4, written correctly but with its own
#                               inline copy -- folded in, so a future
#                               change cannot reach only two of three)
#    The same argument as MARG_VARIANCE_THRESHOLD_P: two copies of a
#    rule is how two screens come to disagree about the same day.
#
#  NOT CHANGED, deliberately: a push whose status stays 'pending' while
#  applied_at is set is CORRECT. It means part of the push landed and a
#  day in it is still unfiled, so the rest is still owed. It reads like
#  an inconsistency and is not one.
#
#  7 new selftests, including two that would have caught this:
#    * the expression is exercised against the real 18-Aug shape
#    * a source guard refuses any unsigned SUM over sale_item coming
#      back. Its needles are ASSEMBLED, not written whole -- a literal
#      search string occurs in the source it searches, so the first
#      version found itself and failed forever.
#
#  Currency-gated. Backup, py_compile, --selftest ALL-GREEN and grown,
#  restart, rollback on any red.
# =====================================================================
set -u
cd "$(dirname "$0")"
LIVE=/root/finance/finance_app.py
SVC=clinic-finance.service
WANT=af617bf043a2bdda562f88fc6893e906
LOG=/tmp/s195_sign_smoke.$$

show(){ echo "      ---- last 40 lines ----"; tail -40 "$1" | sed 's/^/      /'
        echo "      -----------------------"; }

echo "==============================================================="
echo " S195_SIGN · the credit-note sign, in one place"
echo "==============================================================="
echo "[1/8] kit bytes"; md5sum -c SUMS.md5 || { echo '*** RED. STOP.'; exit 1; }

echo "[2/8] currency gate"
H=$(md5sum "$LIVE" 2>/dev/null|cut -d' ' -f1); echo "      finance_app : $H"
[ "$H" = "$WANT" ] || { echo "*** RED: expected $WANT. STOP — tell Cowork this hash."; exit 1; }

echo "[3/8] baseline smoke"
(cd /root/finance && python3 finance_app.py --selftest) >"$LOG" 2>&1
CUR=$(grep -m1 "SMOKE " "$LOG"); echo "      ${CUR:-<no SMOKE line — the suite crashed>}"
echo "${CUR:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { echo '*** RED: baseline not all-green.'; grep "FAIL:" "$LOG"|sed 's/^/        /'; show "$LOG"; exit 1; }
CUR_T=$(echo "$CUR"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')

TS=$(date +%Y%m%d_%H%M%S); BK=/root/finance/_backup_S195_SIGN_$TS; mkdir -p "$BK"
echo "[4/8] backup -> $BK"; cp -p "$LIVE" "$BK/"
rollback(){ echo "*** RED -- ROLLBACK."; cp -p "$BK/finance_app.py" "$LIVE"; systemctl restart $SVC; sleep 2; echo "   service: $(systemctl is-active $SVC)"; echo "   log kept at $LOG"; exit 1; }

echo "[5/8] swap"; cp finance_app.py "$LIVE" || rollback
echo "[6/8] py_compile"; python3 -c "import py_compile; py_compile.compile('$LIVE',doraise=True); print('      OK')" || rollback

echo "[7/8] smoke — ALL-GREEN and GROWN"
(cd /root/finance && python3 finance_app.py --selftest) >"$LOG" 2>&1
NEW=$(grep -m1 "SMOKE " "$LOG"); echo "      ${NEW:-<no SMOKE line — the suite crashed>}"
echo "${NEW:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { grep "FAIL:" "$LOG"|sed 's/^/        /'; show "$LOG"; rollback; }
NEW_T=$(echo "$NEW"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')
[ "$NEW_T" -gt "$CUR_T" ] || { echo "*** RED: the new checks did not run ($CUR_T -> $NEW_T)."; rollback; }

echo "[8/8] restart + verify"; systemctl restart $SVC; sleep 2; systemctl is-active --quiet $SVC || rollback

rm -f "$LOG"
echo "==============================================================="
echo " GREEN.  finance_app.py $(md5sum $LIVE|cut -d' ' -f1)  smoke $NEW_T (was $CUR_T)"
echo " Re-read 18-Aug's mirror: the Marg line should now be the SIGNED net."
echo " Backup: $BK"
echo "==============================================================="
