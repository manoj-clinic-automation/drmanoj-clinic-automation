#!/bin/bash
# =====================================================================
#  S195_CLUB2 — three fixes, one install, three independent gates
#
#  1. DARPAN'S ACCURACY ON HIS TILE  (portal.py)
#     api_my_day_summary has returned an `accuracy` block since the
#     S195_SHARE build; portal.py simply did not render it. Now his
#     Daily Sale tile reads, beside "today: filed",
#         "✔ cash/UPI matched 26/26"   or   "⚠ 1 cash/UPI day to fix"
#     and says NOTHING when the bank could witness no day at all --
#     there is nothing to claim then. Proved by running the tile's own
#     JavaScript against six data shapes, not by reading it.
#
#  2. THE EMAIL AGENT'S LOST COMMANDS  (email_agent.py)
#     The first diagnosis was wrong and the test caught it. A long
#     ASCII subject is not encoded -- it is FOLDED, so a space in the
#     middle of the command becomes "\n ", and the SQL that reached
#     dr_query carried an embedded newline. Separately, ONE non-ASCII
#     character (a rupee sign is enough) makes Gmail RFC2047-encode
#     that run in place, so the middle of the command arrived as
#     "=?utf-8?q?=E2=82=B9=27?=". Unfold, then decode. Five subject
#     shapes now recover BYTE-IDENTICALLY; before, only the short one
#     did. A trusted sender whose subject is not recognised is now also
#     LOGGED rather than dropped in silence -- silence is what let this
#     survive.
#
#  3. THE MONTH, AND THE DAYS THAT NEVER ARRIVED  (finance_app.py)
#     A1 compares one day against its own Marg report and cannot, by
#     construction, see a day that never arrived at all. A4 closes that:
#       * /finance/api/marg-month -- books vs Marg for the month, totalled
#         ONLY over days both sides have, so the figure means something,
#         with the days each side is missing named separately.
#       * The health page now carries both, including the standing
#         MARG_DAY_NOT_FILED days -- Marg had bills, no day was filed,
#         the export was skipped. Those three flags nobody had looked at
#         were not being shown anywhere he looks.
#     The Marg side is rebuilt from sale_item with returns SIGNED back to
#     negative; summing without that turns a refund into a sale.
#
#  Every file is gated on its own recorded live hash. If ANY gate is
#  red, nothing at all is touched. A failure after that point restores
#  all three and restarts both services.
# =====================================================================
set -u
cd "$(dirname "$0")"
FIN=/root/finance
POR=/root/portal
DEP=/root/deploy

WANT_FIN=3e2f707b83994b69019a99b8f9621c0c
WANT_POR=bd4ed0a3b89659676e7e193998eeb1a9
WANT_EML=2c191082c27cb9a4acc52bb0e068aa2b

NEW_FIN=af617bf043a2bdda562f88fc6893e906
NEW_POR=ff08980737c107c3babb78b0c5c169c2
NEW_EML=e535c4f8116abd2fe60b7fda334f33ec

LOG=/tmp/s195_club2_smoke.$$
cur(){ md5sum "$1" 2>/dev/null | awk '{print $1}'; }
show(){ echo "      ---- last 40 lines ----"; tail -40 "$1" | sed 's/^/      /'
        echo "      -----------------------"; }

echo "==============================================================="
echo " S195_CLUB2 · tile accuracy · email subjects · the month check"
echo "==============================================================="

echo "[1/12] kit bytes"; md5sum -c SUMS.md5 || { echo '*** RED. STOP.'; exit 1; }

# The gate imports clinic_users / clinic_sso / portal_config from the LIVE
# portal directory. A stub of any of those sitting in THIS folder would shadow
# the real one and the gate would then be testing against a fake -- passing
# while proving nothing. Offline development uses exactly such stubs, so refuse
# outright rather than trust that they were cleaned up.
for STUB in clinic_users.py clinic_sso.py portal_config.py; do
  [ -e "$STUB" ] && { echo "*** RED: $STUB is in the kit. That would shadow the"
                      echo "    real module and make the portal gate meaningless."
                      echo "    NOTHING CHANGED."; exit 1; }
done

echo "[2/12] currency gates — ALL of them, before anything is touched"
FAIL=0
for spec in "finance_app.py|$FIN/finance_app.py|$WANT_FIN|$NEW_FIN" \
            "portal.py|$POR/portal.py|$WANT_POR|$NEW_POR" \
            "email_agent.py|$DEP/email_agent.py|$WANT_EML|$NEW_EML"; do
  IFS='|' read -r NAME PATHX WANT NEW <<< "$spec"
  C=$(cur "$PATHX")
  if   [ "$C" = "$NEW"  ]; then echo "      $NAME : already this build (idempotent)"
  elif [ "$C" = "$WANT" ]; then echo "      $NAME : OK ($C)"
  else echo "      $NAME : *** RED — live is '$C', expected '$WANT'"; FAIL=1; fi
done
[ "$FAIL" = "0" ] || { echo "*** NOTHING CHANGED. Tell Cowork the hashes above."; exit 1; }

echo "[3/12] portal served-HTML gate — candidate vs the LIVE portal, before any swap"
python3 smoke_portal_P2a.py portal.py "$POR/portal.py" >"$LOG" 2>&1 \
  && grep -q "GATE GREEN" "$LOG" \
  || { echo "*** RED: portal gate. Nothing changed."; show "$LOG"; exit 1; }
grep -E "RESULT:" "$LOG" | sed 's/^/      /'

echo "[4/12] email agent — the CANDIDATE's own selftest, before it goes live"
python3 email_agent.py --selftest >"$LOG" 2>&1
grep -q "SELFTEST OK" "$LOG" || { echo "*** RED: email agent selftest."; show "$LOG"; exit 1; }
tail -1 "$LOG" | sed 's/^/      /'

echo "[5/12] finance baseline smoke"
(cd "$FIN" && python3 finance_app.py --selftest) >"$LOG" 2>&1
CUR=$(grep -m1 "SMOKE " "$LOG"); echo "      ${CUR:-<no SMOKE line — the suite crashed>}"
echo "${CUR:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { echo '*** RED: baseline not all-green.'; grep "FAIL:" "$LOG"|sed 's/^/        /'; show "$LOG"; exit 1; }
CUR_T=$(echo "$CUR"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')

TS=$(date +%Y%m%d_%H%M%S); BK=/root/finance/_backup_S195_CLUB2_$TS; mkdir -p "$BK"
echo "[6/12] backup all three -> $BK"
cp -p "$FIN/finance_app.py" "$BK/" && cp -p "$POR/portal.py" "$BK/" && cp -p "$DEP/email_agent.py" "$BK/"
SWAPPED=""
rollback(){
  echo "*** RED -- ROLLBACK ($SWAPPED)"
  case "$SWAPPED" in *fin*) cp -p "$BK/finance_app.py" "$FIN/finance_app.py";; esac
  case "$SWAPPED" in *por*) cp -p "$BK/portal.py"      "$POR/portal.py";; esac
  case "$SWAPPED" in *eml*) cp -p "$BK/email_agent.py" "$DEP/email_agent.py";; esac
  systemctl restart clinic-finance clinic-portal; sleep 2
  echo "   clinic-finance: $(systemctl is-active clinic-finance)"
  echo "   clinic-portal : $(systemctl is-active clinic-portal)"
  echo "   log kept at $LOG"; exit 1; }

echo "[7/12] swap finance_app.py"; cp finance_app.py "$FIN/finance_app.py" || rollback; SWAPPED="$SWAPPED fin"
echo "[8/12] py_compile"; python3 -c "import py_compile; py_compile.compile('$FIN/finance_app.py',doraise=True); print('      OK')" || rollback

echo "[9/12] finance smoke — ALL-GREEN and GROWN (the new month checks must run)"
(cd "$FIN" && python3 finance_app.py --selftest) >"$LOG" 2>&1
NEW=$(grep -m1 "SMOKE " "$LOG"); echo "      ${NEW:-<no SMOKE line — the suite crashed>}"
echo "${NEW:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { grep "FAIL:" "$LOG"|sed 's/^/        /'; show "$LOG"; rollback; }
NEW_T=$(echo "$NEW"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')
[ "$NEW_T" -gt "$CUR_T" ] || { echo "*** RED: the new checks did not run ($CUR_T -> $NEW_T)."; rollback; }
systemctl restart clinic-finance; sleep 2; systemctl is-active --quiet clinic-finance || rollback

echo "[10/12] swap portal.py"; cp portal.py "$POR/portal.py" || rollback; SWAPPED="$SWAPPED por"
systemctl restart clinic-portal; sleep 2; systemctl is-active --quiet clinic-portal || rollback

echo "[11/12] swap email_agent.py"
cp email_agent.py "$DEP/email_agent.py" && chmod 700 "$DEP/email_agent.py" || rollback
SWAPPED="$SWAPPED eml"
python3 "$DEP/email_agent.py" --selftest >"$LOG" 2>&1
grep -q "SELFTEST OK" "$LOG" || { show "$LOG"; rollback; }

echo "[12/12] verify"
for s in clinic-finance clinic-portal; do echo "      $s: $(systemctl is-active $s)"; done

rm -f "$LOG"
echo "==============================================================="
echo " GREEN."
echo "   finance_app.py $(cur $FIN/finance_app.py)   smoke $NEW_T (was $CUR_T)"
echo "   portal.py      $(cur $POR/portal.py)"
echo "   email_agent.py $(cur $DEP/email_agent.py)"
echo "   Backup: $BK"
echo "   Health : https://followup.dr-manoj.in/finance/health"
echo "   Month  : https://followup.dr-manoj.in/finance/api/marg-month"
echo "==============================================================="
