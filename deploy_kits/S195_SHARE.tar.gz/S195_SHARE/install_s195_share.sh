#!/bin/bash
# =====================================================================
#  S195_SHARE — handing the correction list to Amir
#
#  Amir sits at the MEDICAL PC with Marg open. The work wants a sheet he
#  can keep open, tick down and write on -- not a chat message. So the
#  main deliverable here is an Excel workbook; WhatsApp and email are
#  how you TELL him the work exists.
#
#    * "Excel for Amir" -> /finance/api/marg-corrections.xlsx
#      One row per day. The instruction is ONE crisp phrase in its own
#      column -- "CASH -> UPI" -- not a sentence to read twice.
#      Amounts are NUMBERS (they add up and sort). Header frozen,
#      auto-filter on, columns sized. Two columns are HIS: Remarks, and
#      Done? as a Yes/No DROPDOWN so the column can be filtered and so
#      "y", "YES", "done" and a tick never become four answers to one
#      question. The system never writes in either; its own Status
#      column sits beside them, not on top. The re-export warning sits
#      at the foot of the sheet.
#
#  SCOPE (new): corrections before FINANCE_CORRECTION_FROM (default
#  2026-08-01) are NOT turned into work. Amir applied the older ones
#  already, and a list opening with three months of dead entries is a
#  list nobody reads. The older bank history stays loaded, stored and
#  visible -- the health page states how many older days differ and
#  says plainly that they are not being chased. Change the date with
#  the env var when the answer to "would we actually chase this?"
#  changes.
#    * "Copy for WhatsApp" puts a plain-text list on the clipboard and
#      says loudly that it copied. WhatsApp will not take a push from
#      us: Meta only allows free text inside a 24-hour window the OTHER
#      person opens, and there is no approved template for this. So the
#      honest mechanism is a clipboard, not a robot.
#    * "Email" opens the mail app with the same text already written.
#    * "CSV" unchanged, for the accountants' tools.
#    * /finance/api/marg-corrections.txt serves the same words, so every
#      route hands over the SAME list. A selftest asserts it: two ways
#      of sending two different lists is how a correction gets done
#      twice.
#
#  A bill number is named ONLY where exactly one bill carries the
#  amount. Where several do, or none, it says so. Sending someone to
#  edit the wrong sale is worse than sending them to look.
#
#  TWO DEFECTS FIXED since the first attempt (which rolled back cleanly):
#    * KeyError 'diff_p' -- the Excel export read a key _correction_rows
#      never built. It passed an offline test because the test's own
#      fixture invented the key. A fixture is not the shape. There is
#      now a static producer/consumer check (tools/check_row_keys.py)
#      that compares the real dict literal against every r["..."] its
#      consumers read, plus a selftest asserting the row shape.
#    * UnboundLocalError 'io' -- selftest() does `import io` far below,
#      which makes `io` local to the WHOLE function, so touching it
#      earlier fails at runtime. Neither py_compile nor pyflakes says a
#      word about this. tools/check_late_locals.py now finds it; it was
#      proved against a synthetic case before being trusted.
#
#  Currency-gated. Backup, py_compile, --selftest ALL-GREEN and grown,
#  restart, rollback on any red.
# =====================================================================
set -u
cd "$(dirname "$0")"
LIVE=/root/finance/finance_app.py
SVC=clinic-finance.service
WANT=8c7dc9660444ee8724402920bf1e3438
LOG=/tmp/s195_share_smoke.$$

echo "==============================================================="
echo " S195_SHARE · Excel / WhatsApp / email handover to Amir"
echo "==============================================================="
echo "[1/9] kit bytes"; md5sum -c SUMS.md5 || { echo '*** RED. STOP.'; exit 1; }

echo "[2/9] openpyxl (the workbook needs it)"
python3 -c "import openpyxl; print('      openpyxl', openpyxl.__version__)" || {
  echo '*** RED: openpyxl not installed. STOP.'; exit 1; }

echo "[3/9] currency gate"
[ -f "$LIVE" ] || { echo "*** RED: $LIVE missing."; exit 1; }
H=$(md5sum "$LIVE"|cut -d' ' -f1); echo "      finance_app : $H"
[ "$H" = "$WANT" ] || { echo "*** RED: not the expected build ($WANT). STOP — tell Cowork this hash."; exit 1; }

show_smoke(){ echo "      ---- last 40 lines of the selftest ----"
              tail -40 "$1" | sed 's/^/      /'
              echo "      ---------------------------------------"; }

echo "[4/9] baseline smoke"
(cd /root/finance && python3 finance_app.py --selftest) >"$LOG" 2>&1
CUR=$(grep -m1 "SMOKE " "$LOG"); echo "      ${CUR:-<no SMOKE line — the suite crashed>}"
echo "${CUR:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { echo '*** RED: baseline not all-green. STOP.'; grep "FAIL:" "$LOG"|sed 's/^/        /'; show_smoke "$LOG"; exit 1; }
CUR_T=$(echo "$CUR"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')

TS=$(date +%Y%m%d_%H%M%S); BK=/root/finance/_backup_S195_SHARE_$TS; mkdir -p "$BK"
echo "[5/9] backup -> $BK"; cp -p "$LIVE" "$BK/"
rollback(){ echo "*** RED -- ROLLBACK."; cp -p "$BK/finance_app.py" "$LIVE"; systemctl restart $SVC; sleep 2; echo "   service: $(systemctl is-active $SVC)"; echo "   smoke log kept at $LOG"; exit 1; }

echo "[6/9] swap"; cp finance_app.py "$LIVE" || rollback
echo "[7/9] py_compile"; python3 -c "import py_compile; py_compile.compile('$LIVE',doraise=True); print('      OK')" || rollback

echo "[8/9] smoke — ALL-GREEN and GROWN (the new share + Excel checks must run)"
(cd /root/finance && python3 finance_app.py --selftest) >"$LOG" 2>&1
NEW=$(grep -m1 "SMOKE " "$LOG"); echo "      ${NEW:-<no SMOKE line — the suite crashed>}"
echo "${NEW:-}"|grep -Eq "SMOKE ([0-9]+)/\1 " || { grep "FAIL:" "$LOG"|sed 's/^/        /'; show_smoke "$LOG"; rollback; }
NEW_T=$(echo "$NEW"|sed -n 's#.*SMOKE [0-9]*/\([0-9]*\).*#\1#p')
[ "$NEW_T" -gt "$CUR_T" ] || { echo "*** RED: the new checks did not run ($CUR_T -> $NEW_T)."; rollback; }

echo "[9/9] restart + verify"; systemctl restart $SVC; sleep 2; systemctl is-active --quiet $SVC || rollback

rm -f "$LOG"
echo "==============================================================="
echo " GREEN.  finance_app.py $(md5sum $LIVE|cut -d' ' -f1)  smoke $NEW_T (was $CUR_T)"
echo " Checklist : https://followup.dr-manoj.in/finance/marg-worklist"
echo " Backup: $BK"
echo "==============================================================="
