# CANONICAL MANIFEST — Dr. Manoj Agarwal Clinic (Tier 0 · linchpin)

**Bareilly · maintained with Claude · governs the canonical document set (D247).**

**STATUS: canonical — current at the S197 FOLD-IN (23 Aug 2026 · EOS-light · owner-delegated · the four-session canon debt CLEARED).** Sessions S193–S196 folded in one pass: **Archive v1.43 → v1.44** (§S193…§S196 pure append, the 800,148 bytes before v1.43's END marker proven byte-identical, +34,510) · **Fault Register v2.32 → v2.33** (the F-series fork reconciled — F-155–F-159 S193's, F-160–F-162 S196's, S194's candidate minted F-163, S195's five unnumbered faults minted F-164–F-168; F-148/F-153 closed-S193; reverse-application-proven) · **KB Register v5.40 → v5.41** (~12 moved live pins, D333+D334 into the decisions index, reserved next-free D317→D335, reverse-application-proven) · **Runbook v128 → v131** (v129/v130 were the debt, retained) · **START_HERE 193 → 198** · **`live_pins.txt` regenerated from v5.41 (A8 — the checker had been unprotecting since S193)** · the S192-owed and S193–S196 project-knowledge docs FILED to the repo (`deploy_kits/KB_canon_S197fold/filed/`, F-107 closed for those sessions) · **cold kit TAKEN** (was due, 4 of 3–5 since S192). **NO live code moved, NO live data changed, NO pin moved** — the trusted pin list is the S196-close set (`finance_app.py 388c8ac0…` · `portal.py ee749cd9…` · `staff_ledger.py acd7b538…` · `staff_register.py 9087954c…` v0.4 · `att_month_report.py 9ab98313…` v2.6 · `email_agent.py e535c4f8…` · Marg `signatures.json 1b21f3bf…`). Next free **D335 · F-169 · A-D25 · Session 198**. Full narrative: the §S193–§S197 fold block below + Archive §S193–§S196.** *(S192-close status, retained below:)* **STATUS: canonical — current at the S192 CLOSE (three D332 kits LIVE — `S192_SL5` the waiver instrument + policy-date settings + the F-151 wording fix (218→240), `S192_SL6` the schedule lane + DEFER + the capacity rule (240→274), `S192_SL7` the per-staff Perks view (274→287); ledger pin `470bb113…` → **`44e39d6abf34db5e11acc2223ac908d3`**, three installs each landing first time on its stated number, no schema change and no data write in any of them. **The gated data corrections EXECUTED** (D332 §6 items 1–4) after a read-only survey and a dry run, on the owner's separate GO: the **₹10,000 tripwire killed** before the August close could collect it twice, the ₹15,000 + ₹5,000 consolidated into ONE **₹20,000 SPECIAL** (`0cc0b26b38c5`, PENDING on its signed application) carrying the owner's real **8/4/4/4** schedule, `advance_pct` Darpan **75 → 50**, and a ₹0 record narrating the July zero — verified by re-running the survey, not by assertion. **The KB cleanup** (the owner's S191 ruling): **47 superseded docs deleted, every one proven byte-present in the git canon first** — project knowledge **1,919,222 → 1,149,776 chars (96% → 57.5%)**. **`S192_F6` designed and deliberately NOT built** — its smoke suite copies the live `finance.db` and cannot run offline, so building blind would be **F-87** exactly; design filed. **F-147 · F-149 · F-150 · F-151 CLOSED** by code now running; **F-148 open**; **F-152 · F-153 · F-154 minted**. Archive **v1.43** (§S192 pure append, the 786,212 bytes before v1.42's END marker proven byte-identical, +14,280) · Register **v5.40** (reverse-application-proven onto the `28a807a0…` pin) · Fault Register **v2.32** · Runbook **v128** · START_HERE **193** · **cold kit TAKEN**. Next free **D333 · F-155 · A-D25 · Session 193**.)** *(S191-close status, retained:)* **STATUS: canonical — current at the S191 CLOSE (the confirmation session: F-141…F-146 ruled at the mid-session fold; the staff advance system CONFIRMED against the live box — SL4 payload = live pin `470bb113…`, owner-run selftest 218/218, every D331/SL3/SL4 clause holding — and the confirmation surfaced **F-147…F-151**, five gaps between D250's written judgment and the machine that faithfully implements only its arithmetic, every one ruled by the owner the same day and appended at this close (Fault Register **v2.31**); **D332 MINTED AND SIGNED** — the Waiver, Defer & Repayment-Defined Advance layer, contract `S191_Waiver_Capacity_Layer_D332_Design.md` v3 filed and pinned, builds S192_SL5/SL6/SL7/F6; July's pre-policy over-deduction quantified at **₹16,552.38 across all twelve staff** (F-150) and remediated by the owner-side sheet, which is **deliberately NOT filed** (F-31/D320: all-staff salary data — recorded here so the F-107 inverse check reads intent, not absence); Darpan's data corrections GATED on a separate GO — the ₹10,000 `fbd756fe1473` settled-inside-July tripwire recorded loudest; **NO live code moved, NO live data changed — no pin changed**; the twelfth consecutive GREEN pin run, owner-run, proving the mid-session fold end to end. Archive **v1.42** (§S191 pure append, the 765,415 characters before v1.41's END marker proven byte-identical, +9,311) · Register **v5.39** · Runbook **v127** · START_HERE **192** · cold kit NOT taken, count 3 of 3–5, **due within 1–3 sessions**. Next free **D333 · F-152 · A-D25 · Session 192**.)** *(S190-close status, retained:)* *(was:)* **STATUS: canonical — current at the S190 CLOSE (D330 + D331 minted AND executed; EIGHT kits live this session: `S190_E2` · `S190_SL2` · `S190_F2` · `S190_SL3` · `S190_F3` · `S190_F4` · `S190_F5` · `S190_SL4`).** *(The S190 full fold-in, executed end to end under the EOS automation boundary (Runbook v126 §4). **The session that put the owner's money rules into the machines the same day he ruled them:** D330 (the three-category expense menu · the derived per-staff ceiling shown inline and refused past · compulsory per-row evidence at File, no escape hatch · drawings split · clinic in scope for expenses only · petty book PARKED — supersedes D329 whole) and D331 (the staff-wide advance policy: derived ceiling for every staff member · SPECIAL above it, unapprovable without the uploaded application signed by Dr Manoj / Dr Bhawna · `against_month` attribution · the cross-system forward-only count) both executed; then four owner live-looks fixed four faults the same hour each was found (SL3 the migration-dated quota · F4 the broker-role locked-day gate · F5 the hidden-legacy queue · SL4 the QUOTA LANE, owner ruling "A": a quota advance recovers in full at the first close ≥ its month, in its own lane beside the D250 waterfall). **The ₹30,000 sitting closed end to end** — ₹10,000 · 31 Jul (filed AND approved) · ₹15,000 · Aug · ₹5,000 attributed against September; cash in hand **₹1,75,198.00, the counted figure to the rupee**, verified on the live tile in the owner's own Chrome; all three ledger advances in the book, recovering automatically at the Aug/Aug/Sep closes. **Finance smoke 509 → 550 · ledger selftest 190 → 218 — sixteen consecutive exact projections; two kit v1s refused by their own gates (both toolchain, both right); six mid-session folds each zero-loss-proven; eleven GREEN pin runs.** Archive **v1.41** (§S190 pure append, the 754,537 characters before v1.40's END marker proven byte-identical, +11,188) · Fault Register **v2.30 at S191** *(this line read "stays v2.29" — true when written, spent the moment the ruling landed; the F-45/F-116 footer family, corrected not silently)* (the F-141 ruling was the owner's, deferred to S191 and made there — SIX candidates recorded: the fabricated hash tail · the wrong install path · the tail-1 harness · the migration-dated quota · the broker-role gate · the hidden-legacy queue; plus the refusal-looks-like-save UX note) · Register **v5.37** · Runbook **v126** · START_HERE **191** · cold kit NOT taken (count 3 of 3–5, next due ~S192–S194). Deferred by the owner to S191: Darpan's real 17/18 Aug figures + scans · Surendra's ₹8,000 PENDING decision · the F-141 ruling. Next free **D332 · F-141 · A-D25 · Session 191**. Corrected here, recorded not silent: this STATUS line still read "FIFTH FOLD" after the sixth fold — the fold updated the Register rows and appended its §S190-F block but not this header; the F-45/F-116 footer family in the manifest's own head.)* **(S189 close status, retained:)** *(The full fold-in, executed by the assistant end to end under the new **EOS automation boundary** (Runbook v125 §4: the owner's residual work is ONE `PUBLISH_ALL.bat` double-click + the on-box pin-list copy — anything more in a close is a fault in the close). **D329 MINTED — the Advance Pool**: random drawer advances auto-join one pool on approval (B6, scoped on-box token), recovered at min(pool, checker-set instalment) each monthly close beside — never inside — the D250 waterfall, with Advance-Skip (2/FY, no capitalisation) and Advance-Waive (reasoned), a month-end reconciliation card with one-tap LINK, and no consolidation ceremony because the pool IS the consolidation; signed design pinned below as a Tier-1 CONTRACT; builds as S190_SL1 → token → S190_F1. **Session 189 final tally: seven kits live (G1a · W1a · W1b · C1a · E1b + three canon folds), one kit retired unlived by its own honest gate (E1a), findings F-130…F-133 + F-135…F-140 every one raised-and-handled the session it was found, two gate refusals both right, smoke 478 → 509, four proved GREENs, the ₹2 lakh question closed by schema + count, the ₹70,000 gate verified open, the D3 salary bridge unblocked and specified.** Archive **v1.40** (§S189 pure append, prefix proven byte-identical, +12,133) · Fault Register stays **v2.29** (nothing owed — every finding was appended the session it was raised) · Register **v5.30** · Runbook **v125** · START_HERE **190** · `EOS_DEFINITION_PORTABLE.md` (the cross-project close spec) · cold kit **`KB_S189_close`** taken AT the close, count **3 of 3–5**. Next free **D330 · F-141 · A-D25 · Session 190**.)* **(S189 third-fold status, retained:)** *(Kit **`S189_E1b`** is live — the owner-ruled expense MENU on the maker's page: free text demoted to a deliberate last choice with required details, a skipped category refused server-side, and a salary advance attributed by the SERVER. **F-139**: the old page's staff dropdown was hardcoded ids 1/2 into a `staff_ref` **empty since S179** that nothing in the app ever read — *"Someone else"* was a fake staff member; surveyed first, zero rows ever carried a staff_id, loaded gun never fired. **F-140**: kit `S189_E1a` was **refused by its own D317 gate on the box** — its rehearsal-day finder walked forward from 1 April into a D322 Sunday hole 135 days back, where the save answers `too_old` before the expense parse; the continuous offline store had the schema, not the SHAPE. Reproduced offline to the exact six FAILs, fixed (backward finder + server errors in check labels), rehearsed on FOUR store shapes, landed **488/488 → 509/509, +21 exactly** — E1a retired unlived, the second kit today refused by a gate and the second time the gate was right. **Also at this fold: the §4a ₹70,000 gate is VERIFIED OPEN (D326(c))** — five machine checks (ledger raw, finance drawer, live workbook, the migration record, July's close) plus the owner's confirmation that the Apr–Jun advances were recovered from salaries in the workbook era; no double-count exists in any book; the salary bridge (Daily Flow v2 stage D3) is UNBLOCKED. `S189_70k_Gate_Verification.md` FILED and pinned at this fold — written to project knowledge hours earlier, which is the F-107 condition, closed here rather than left to the close.)* **(S189 second-fold status, retained:)** *(**The ₹2 lakh question is CLOSED, and closing it minted two findings, both fixed and installed the same day.** **F-137:** the record — Runbook v124 ⭐0b, the S188-POST block of THIS manifest, F-133's own entry — diagnosed cash in hand as *overstated by unbooked handovers*. Reading the schema before building: `v_day_cash` subtracts EVERY `cash_movement` row from cash in hand, so the prescribed fix would have cut ₹2,05,198 to ≈₹30,000 against the S186 physical count proving ₹1,75,198 genuinely held (owner ₹18,963 · Dr Bhawna ₹1,56,235). **There was no overstatement** — the custody facts had been recorded as PROSE in `cash_count.explanation`, the same session `cash_custody_event` was built to hold them. Owner ruling: doctor-held cash IS cash in hand, located elsewhere. Fixed in three kits, all live: `S189_W1a` (the card reads custody; +6 checks proving a custody event moves the card and not the ledger, and a movement the reverse), `S189_W1b`, and `S189_C1a` (the counted position recorded, cash in hand gate-proven byte-identical). **F-138:** C1a's FIRST run was refused by three of the new F-137 checks asserting the store's absolute state — after a fourth in the same block had been converted to a delta citing F-106. The installer's honest red restored the books untouched; the gate was flawless, the checks were the fault. Fixed in `S189_W1b`, whose installer proves a count-equal kit (488 → 488) by REPRODUCING the red on a migrated throwaway copy — on the box it reproduced at 485/488 with every FAIL naming F-137, then went 488/488 twice. Smoke 482 → **488**. Pins recorded as they moved: Register **v5.28**, Fault Register **v2.28** (F-0…F-138, next free F-139).)* **(S189 first-fold status, retained:)** *(Kit **`S189_G1a`** is live — **F-130 closed**: the served pages are now held to their RECORDED design state on the real routes, **in both directions**, so a page cannot silently revert AND a rebuild cannot silently land. Live smoke **478/478 → 482/482**, the fifth projection in a row to hit its number. The pin was recorded **as it moved** (Register **v5.27**), not saved for the close. **F-135** — the S188 close wrote a remediation instruction naming three pages; surveyed at S189 on the real bytes, **two of the three carry none of the four markers it asked to assert**, because both predate Clinic Design Language v1. It was a claim about three files written without opening two of them: **F-132's shape, one document over.** Caught before it reached an installer. **F-136 — RAISED AND FIXED IN THIS FILE.** The Tier-2 Attendance row carried `staff_ledger.py v2.4 74dac84e…` while calling the value *Register-tracked*; the Register moved to `92665b64…` at S162 and **no check has ever looked at the manifest's copy** — `gen_live_pins.py` builds the pin list FROM the Register, so a manifest-only hash never enters it, and Phase 0's F-88 cross-check only asks whether a token is a *document*. **A hash in the manifest but not in the Register is checked by neither.** A sweep of every current-state row found **exactly one** such hash — this one — and it is now stripped, the pointer kept. Also at this fold: the duplicate-CURRENT labelling the S187 close fixed **has recurred across four document families** and is corrected again, with the Runbook rows re-named `(pre-…)` because theirs was the only family where the duplicates shared a bare name — the one shape that would break the strict single-CURRENT rule. Recorded, not minted; the owner's call whether it earns F-137.)* **(S188 FINAL status, retained:)** *(The post-close canon was published; the owner then ran the end-of-session verification the routine is supposed to end with — `verify_live_pins.py` — and it went **RED on two files the box had exactly right**. **F-134:** `live_pins.txt` is generated **from the KB Register**, so a Register bump stales it by definition. S187 regenerated it and wrote so **in this manifest's §S187 block — narrative, not procedure**: `END_OF_SESSION_PROMPT_v4` §A ran A0→A7 and stopped at *"the manifest, ALWAYS updated last."* **It was not last.** The S188 close rebuilt manifest + `MD5SUMS_ALL` + `KIT_ID` and left the pin list on **Register v5.22, three versions stale**. **The tool was flawless** — it refused to print VERIFIED, raised `MANIFEST_MISMATCH`, and printed the CURRENT pin it expected beside the one it held (F-122's v1.2 fix, the chain F-97 → D321 → F-110 → F-117 → F-122 catching this unaided). **Fixed: `END_OF_SESSION_PROMPT` v4 → v5 with step A8** — regenerate the pin list AFTER the manifest, because the generator refuses unless the Register hashes to the manifest's CURRENT row (F-110) — and the list regenerated from **v5.26**, `register_pin_verified: yes`. **Eight findings this session, every one appended the session it was raised.** Full narrative: **Archive §S188-FINAL**.)* **(S188 post-close status, retained:)** *(The S188 close was published, verified and reported. The owner then logged into **Darpan's own account from an incognito window on his phone**, looked at the page, and asked one question — *"it is showing total amount also"* — and **that one look reopened the session.** **F-132:** the field labelled *"Opening cash · carried from the last filed day"* was `v_cash_ledger`'s window `ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING` — a running total of every day since the books began — rendered to the maker at 24px, with closing beneath at 30px. **D2a had gated that route hours earlier and recorded its payload, in the kit and in this canon, as "already correctly scoped". Nobody had looked.** Worse than the disclosure: it was **not true of him** (most of that balance is parked with Dr Bhawna, D323; ~₹87,205 is a pre-April adjustment, S186), and that half predates F-127 — live since S179. It leaked through **three** doors: the GET, the save response, and the D2 mirror. **F-133:** asked to display cash parked with the two doctors, the box was surveyed first **and the survey was the finding** — `cash_movement` for medical holds only `bank/out` (15 rows, ₹15,70,600), `cash_custody_event` is empty, and **not one handover to either doctor has ever been recorded** though the entry has existed on that page since S179. Built blind it would have printed a confident `₹0` against roughly two lakh. **It also explains the ₹2,05,198** — S184/S186 recorded parked cash as exception text, never as movements, so the ledger counts it as in-hand; **that overstatement is OPEN and is about the owner's books, not the maker's screen.** Kit **`S188_D2c`** live: 464/464 → **478/478**, the fourth projection in a row to land on its number. Full narrative: **Archive §S188-POST**.)* **(S188 close status, retained:)** *(S188 shipped **two kits, both live, both landing exactly to a projection written down before the box was touched** — `S188_D2a` 400/400 → 453/453 and `S188_D2b` 453/453 → 464/464, no incident. **Daily Flow v2 stage D2 is live:** Darpan saves, sees the bank/Marg check, then files, with **save-then-see enforced on the server** (`409 not_saved`), a reveal fingerprinted on the money shown so the Scan-path draft save is correctly not an edit, and an `EDITED_AFTER_REVEAL` badge that **reaches the checker's Day Page with no checker-side code change** because `/full` already renders `data_flag` rows. His page was rebuilt under **Clinic Design Language v1** with the H1c logo. **FIVE findings, all appended the session they were raised** (Fault Register v2.23 then v2.24 — fourth consecutive clean close): **F-127** the maker's page had been pulling the whole unit cash position on every load since S179 (a role gate on the surface is not a role gate on the data — the F-84 family one layer in), **F-128** the offline harness had been granting the smoke user a checker role the box does not have, so eight role-refusal assertions passed by accident and the baseline moved 375 → 398 when it was fixed, **F-129** the reveal marker recorded the day rather than the person so a checker's glance armed the badge against the maker, **F-130** a page-only kit that preserves every id is invisible to an id-based test so the *design* is the one thing 464 green checks cannot see, **F-131** `git status` is not read-only and left an index lock that blocked a publish — fourteen such locks dated across S185–S188 sat in `.git/`, every one a silent workaround, **not one recorded**. **NO DECISION MINTED** — S188 is the execution of D326, and an implementation detail does not earn a D-number; next free stays **D329**. Three superseded intermediates that had sat in `KB_canon_all` with no manifest row (`Fault_Action_Register_v2_20`, `KB_History_Archive_v1_34`, `KB_Register_v5_11`) are **listed below at this close** — the F-107 shape in reverse, closed. Full narrative: **Archive §S188**.)* **(S187 close status, retained:)** *(S187 shipped **eight kits, all live, every one landing to its stated projection — no incident**: the attestation chain made provable (`S187_V1a`, checker/generator v1.2 — F-117/F-122 closed structurally: attest the stable CURRENT-row pin, prove it on the box, VERIFIED only on proof), **B5** — reception pushes the Marg report from the medical PC with a scoped stage-only token and the checker alone applies (`S187_M1a`, **D325**; proven end to end the same day), **Daily Flow v2 stage D1** — the canonical Day Page + approvals surface (`S187_D1a`, **D326**; the full v2 + returns/360 design signed as contract, build paused for S188), the portal tile chain — every seat's tile speaks (`S187_P1a`→`P1b`→`P2a`; the P1a RED was our own state-asserting test broken by the FIRST real reception push, **F-125**, gate restored perfectly), and the owner's **Sanjeevni Hub** — one page for all Sanjeevni info and work, rebuilt under the new **Clinic Design Language v1** (THE default from here) with the real Canva logo and the corrected name line (`S187_H1a`→`H1c`; H1b retired unlived; **F-126** raised the whole-file `bash -n` installer rule). **D327** (the `counter` role) and **D328** (`PUBLISH_ALL.bat` the default publish method; publish-autonomy boundary: repo-write credentials never transit chat) minted at the close. **F-122 … F-126 all appended to Fault Register v2.22 the same session** — second consecutive close with no owed append. **F-123 executed at this close**: the S177-stale twin `canonical-docs/CANONICAL_MANIFEST.md` retired to the attic and renamed; exactly ONE file named `CANONICAL_MANIFEST.md` remains. **Also corrected here, recorded not silent:** five "(pre-…)" rows below still carried the label CURRENT beside their successors (two Registers, a runbook, an Archive and a Fault Register among them) — de-labelled; START_HERE_187's internal self-contradiction and Runbook v121's "v120" end-marker are corrected in their S187 successors. The two S186 docs that lived in project knowledge only (the F-107 condition their rows named) are **FILED and pinned** at this close, as are the three S187 design docs. Full narrative: **Archive §S187**.)* **(S186 post-close status, retained:)** *(rebuilt from real bytes after F-116/F-119/F-120.)* *(S186 was the longest build session in the project: **six kits, five live installs, six findings, two decisions, no incident.** The Sanjeevni cash chain was **closed by physical count** — the phantom 13 Aug ₹75,000 deposit removed (**F-112**), **₹87,205** parked as one approved adjustment (**D323**), and the 29 `negative_cash` exceptions resolved to **ZERO**, S184's derived ≈₹85,000 requirement and the counted ₹87,205 agreeing to about ₹2,200. Three upgrades shipped — the **Yes Bank cash reconciliation** (F-103 closed, and it found F-112 unaided), the **reconciliation workbench**, and **explicit cash custody** with the taken/carried marker — then two more: **F-114 fixed** and **Marg exports uploading through the portal**, and **F-104 cleared** (review queue 2,072 → 0, flagged days 120 → 4). The pin chain was repaired first (**F-109, F-110, F-111**, kit `S186_V1a`), which is what made every later build safe: both live-code kits were built on **bytes verified from the box**, not on the repo copy, which is two builds stale. **D324** minted. **Everything folded in at this close — Archive v1.34, Fault Register v2.20 (no owed append for the first time since S181), Register v5.11, this manifest, START_HERE 187.** Full narrative: **Archive §S186**.)* **(S185 status, retained:)** *(S184 shipped the live Sanjeevni cash correction + the D322 holiday classifier but folded no canon; S185 verified Phase 0 green, raised **F-107** and **F-108** from the record's own blind spots, and then cleared **all three sessions of canonical debt in one pass** — Archive v1.30 → **v1.33** (§S183 · §S184 · §S185, chronological, prefix byte-identical), Fault Register v2.18 → **v2.19** (F-90 … F-108; the §7 index had been stale at F-89 for four sessions), Register v5.5 → **v5.6**, this manifest rebuilt, START_HERE promoted to **186**. `HANDOFF_RUNBOOK v118` and `START_HERE_SESSION_185` — written to project knowledge only at the S184 close, which is **F-107** — were filed to the repo here, hashed as delivered, and pinned. **One honest gap remains and is flagged, not filled: the `finance_app.py` live pin is PARTIAL (`c66bec2b76…`)** — the full md5 was never written down and was not invented; complete it from the box at the S186 open (D321). See the §S184 and §S185 blocks below.)* **(S183 status, retained:)** (FULL code session, three threads: (1) the **F-97 structural fix shipped** — `verify_live_pins.py` at `/root/deploy/` checks every live-code pin against the box (D321); its first run corrected NINE Register rows (F-101 eight wrong paths + F-102 one stale md5); F-100 fixed `push_kit.bat` silently dropping a `.gitignore`-excluded file. (2) The **Marg pharmacy feed went LIVE and backfilled** — `marg_report.py` reads `.xlsx` too (kit S183_M2a), migration `S183_marg_map`, `marg_backfill.py` v2 backfilled **119 days / 15,574 drug lines / 982 attributed bills**, money byte-identical (D313 proven at scale). (3) The **Sanjeevni cash chain was reconciled from bank records and found whole** — the −₹30,056 was 16 unrecorded Yes Bank cash deposits (₹16,45,600), not missing money; ICICI holds card/UPI only (Darpan's UPI confirmed T+1), Yes Bank holds all cash; F-103/F-104 minted; **no live finance write made** — booking is S184. Register v5.4 → **v5.5**. **Archive stays v1.30 and Fault Register stays v2.18 this close — the formal §S183 append + F-100–F-104 append are OWED as S184 opening housekeeping** (precedent: the S181 owed-appends); the S183 narrative + findings are fully captured in the Register, the Runbook §0, and three dedicated S183 docs. Below, the historical S182 status block is retained.)

**(S182 status, retained:)** FULL code session: the **Marg pharmacy feed** was established offline end-to-end and **sale returns were made to reach the books**, across FOUR separate live installs on `clinic-finance`. `finance_ingest.py` and `finance_app.py` were both replaced; four new modules landed at `/root/finance/` (`marg_report.py`, `finance_returns.py`, `finance_returns.sql`, `finance_identity.py`); the database gained one **redefined view** (`v_day_attribution`, netting `*_return`) and one **new table** (`sale_line_item`), both non-destructive; `xlrd 2.0.2` was added. **D314–D315 minted** (a return is a magnitude with its direction in the row's type; a patient-identity match is graded and only the top grade may feed an audit). **F-85–F-88 raised** — two of them about this session's own process: F-87, a change shipped twice to a test suite that could not be run offline (F-84's own lesson repeated, remedied by `dev_seed_smoke_db.py` + differential verification), and F-88, a passing `md5sum -c` proving a kit internally consistent rather than current. A vendor-facing requirement document was written. Archive §S180 appended v1.27 → **v1.28** (pure append, prefix byte-identical). Register v5.1 → **v5.2** (additive). Live finance code is Register-pinned, NOT a manifest row — F-31 keeps the DB + patient CSVs out of repo and manifest.) (S179 was the clinic-finance medical go-live; S178 an EOS-light KB compaction; S173–S177 the Asset-Register sub-project.) **Rows changed this session are pinned from a live md5 recomputed at the S180 EOS.** **Seven rows were unreachable at Phase 0: FOUR RECOVERED by hash-search, THREE CLOSED AS LOST under D316 — see the section below. A closed row does not halt Phase 0.**

> **Phase 0 read rule (every session).** Verify **every** row below by md5 (cheap — hash compare only). **Read into context only Tier 0.** Tier 1 is opened on demand when the session's task touches it. Tier 2 is hash-verified but never read in the loop and never edited without an explicit waiver (D34 discipline). *A row whose md5 does not match halts work until reconciled (D172/D188). If a "pending" item looks done, verify it against reality first.*

---

## RESOLVED AT THE S180 CLOSE — four recovered, three CLOSED AS LOST (D316 · F-89)

At the S180 Phase 0, **33 of 33 reachable rows verified clean** and seven could not be reached. A
hash-based recovery tool then searched the owner's `D:` and `C:` drives — **by md5, not by filename**
(D188), opening `.zip` archives because the cold backup is one, and re-hashing LF-normalised copies
of near-misses. **26,745 files hashed.**

### Recovered — each matched its pinned md5 exactly

| Row | Tier | md5 | Found in |
|---|---|---|---|
| `Fault_Action_Register` v2.16 | **Tier 1 CURRENT** | `1702b5a8e0663847eaa097919aea94d3` | the S171 cold kit |
| `Staff_Daily_Register_Dossier` v1.1 | historical | `7969deadcbf062fccae302e1f8ae07f0` | the S165 cold kit |
| `KB_Asset_Register` v1.10.3 | historical | `07d01e80a1d6a49884650d2e542205df` | git `canonical-docs/` |
| `KB_Register` v4.6 | historical | `0503f255da0ab9a98dc6f092ddff2ef6` | git `canonical-docs/` |

### CLOSED AS LOST — under D316. **These do NOT halt Phase 0.**

| Row | md5 (kept for provenance) | Closure |
|---|---|---|
| `KB_Register` v5.0 (S178) | `ee12a63d4b87b1359f2d0954945457b2` | **LOST-SUPERSEDED** — v5.1 (`1c86b83a…`) verified present on disk. Nothing current depends on it. No action. |
| `KB_History_Archive` v1.26 (S178) | `30dc00b300a491105577b8c58b2c47e0` | **LOST-SUPERSEDED** — v1.27 (`adb85c35…`) verified present on disk. No action. |
| `KB_Asset_Register` v1.11.0 | `1c147beb44ad4413d3b147ad70e43ea7` | **LOST-RECONSTRUCTABLE** — Tier-1 CURRENT. Rebuild from the recovered v1.10.3 + Archive §S173–§S177. **Backlog item, not a blocker.** |

**Why exactly these three (F-89).** All are **S177–S178 outputs**. The newest full cold kit on the
machine is **`DrManoj_Clinic_FULL_Handoff_Session171`** — so they were created **nine sessions after
the last cold backup**. Everything up to S171 was comfortably recoverable; everything after depended
on whatever happened to be downloaded loose. Every document that *was* recovered came from a backup
mechanism that had actually run: the S171 kit, the S165 kit, or the git repo.

**D316 — a closed row is not drift.** Its md5 stays listed for provenance, but Phase 0 does not halt
on it. Only a row listed as *present* that fails its hash does that. A halt that fires every session
is a halt that gets waved through, and then it protects nothing.

---

## Tier 0 — session loop (read at start · rewritten at end)

| Doc | Version | md5 | Notes |
|---|---|---|---|
| `CANONICAL_MANIFEST.md` | S179 | *(self — recomputed last, each EOS)* | this file; the linchpin |
| `START_HERE_SESSION_198` | **S197 fold** | `4de2d34bed0aa69727867b62eb62ac95` | **CURRENT** entry point. Phase 0 = git-clone hash check · F-88 · F-107 inverse · F-123 · the A8 source_md5 check (against Register **v5.41**) · `verify_live_pins.py` (expect GREEN, match 45, `source: VERIFIED` — the first GREEN since S192; the list was regenerated from v5.41 this fold). The canon debt is cleared — a mismatch is an incident again, not the known S193–S196 gap. Carries the S198 backlog: owner actions (token rotation ⭐ · Darpan's application → approve `0cc0b26b38c5` before the Aug close · the ledger/filing items) · the Auditor's first reports · the August month-end · the builder backlog. |
| `START_HERE_SESSION_197` | S196 close | `512c89146269f111aca33b260ccdb78c` | superseded by 198; retained. Carried the STANDING CAVEAT (canon folded only to S192; S193–S196 mismatches EXPECTED) and the ⭐0 fold-in instruction executed this session. |
| `START_HERE_SESSION_196` | S195 close | `db43e7d9d3c9e5b68ab5a35ec024572e` | superseded; retained (filed at the S197 fold). Carried the attendance/renewals/Auditor priorities. |
| `START_HERE_SESSION_195` | S194 close | `2b0908c6c991bc618b00ebc3bc618832` | superseded; retained (filed at the S197 fold). Carried the S195 backlog + the medical-PC leg addendum. |
| `START_HERE_SESSION_194` | S193 close | `222a3820f55258d5515cf0a42fda8759` | superseded; retained (filed at the S197 fold). Carried the Daily Sale v2 build + the S193 pins. |
| `START_HERE_SESSION_193` | S192 close | `6ed3ca023e7530297db3f92d02b142ab` | superseded by 194; retained. Was **CURRENT** at S192 close. Phase 0 = git-clone hash check · F-88 · F-107 inverse · F-123 · the A8 source_md5 check (against Register v5.40) · `verify_live_pins.py` (expect GREEN, match 45, **from the S192 list** — the ledger pin moved three times this session). Carries the S193 tasks: ⭐0 has Darpan's application been scanned and the ₹20,000 approved (clock: before the August close) · ⭐1 **S192_F6, whose FIRST task is the seeded store, not the feature** (F-87) · ⭐2 F-153's one line · ⭐3 the July salary close · ⭐4 watch the first month-end on the new machinery. |
| `START_HERE_SESSION_192` | S191 close | `ec0bfa313fb1832d73dd80c96b2c3209` | superseded by 193; retained. entry point. Phase 0 = git-clone hash check · F-88 · F-107 inverse · F-123 · the A8 source_md5 check (against Register v5.39) · `verify_live_pins.py` (expect the thirteenth GREEN, match 45, VERIFIED). Carries the S192 tasks: **GO on the gated data corrections BEFORE the August close** (the ₹10,000 tripwire · the ₹20,000 SPECIAL 8/4/4/4 with the scanned application · the July composition entry · pct 75→50) · the D332 builds SL5→SL6→SL7→F6 · owner-side: Darpan's application, his portal introduction, the July sheet finalisation, Surendra's ₹8,000 · the first real month-end to watch · cold kit due. |
| `START_HERE_SESSION_191` | S190 close | `aa4af92ce62d7021ca22a3a07fa548cf` | superseded by 192; retained. Entry point. Phase 0 = git-clone hash check · F-88 · F-107 inverse · F-123 · the A8 source_md5 check · `verify_live_pins.py` (expect GREEN, match 45, VERIFIED). Carries the S191 tasks, all three deferred BY THE OWNER at the S190 close: Darpan's real 17/18 Aug figures + scans → approve · Surendra's ₹8,000 PENDING decision · the F-141 ruling (six candidates); plus the first real month-end on SL4 to watch. |
| `START_HERE_SESSION_190` (pre-S190-close) | S189 close | `cb119685e718b9023d546da809fbe290` | superseded by 191; retained. Entry point. Phase 0 = git-clone hash check · F-88 · F-107 inverse · F-123 · the A8 source_md5 check · `verify_live_pins.py` (expect GREEN, match 45, VERIFIED). Carries the S190 tasks: **the D329 Advance Pool build (S190_SL1 → token → S190_F1)**, the ₹30,000 sitting if not yet done, and the owed-and-named list. |
| `START_HERE_SESSION_189` | S188 final (REISSUED ×2) | `f04d19848a3a2c2b172e8e92f173d2d5` | superseded by 190. Was the **CURRENT** entry point. Phase 0 = git-clone hash check · F-88 cross-check · F-107 inverse · the F-123 one-manifest check · `verify_live_pins.py`. Carries the S189 tasks (F-130's three-line fix and F-131's 14 deletes first, then the rest of the signed contract: D-R returns + the D327 `counter` role → 360 → orthotics → D5 → D6), the §4a ₹70,000 gate, and the owner one-clicks — of which the only one a *person* must do is walking Darpan through Save → the check → File. |
| `START_HERE_SESSION_188` | S187 close | `b3bb94998a4c62b66980b0676c518de4` | **CURRENT** entry point. Phase 0 = git-clone hash check · F-88 cross-check · F-107 inverse · the F-123 one-manifest check · `verify_live_pins.py` (**expect GREEN with a PROVED `source: VERIFIED`** — the first). Carries the S188 build contract (D-R returns + D327 `counter` role → D2 mirror → 360 → orthotics purchase side → D5 feeds → D6), the §4a ₹70,000 gate, and the owner one-clicks. |
| `START_HERE_SESSION_187` | S186 post-close | `91996d84aaaf8057b931dfd9e2de2577` | superseded by 188. The **reissued** version. ⚠ carried an internal self-contradiction found at the S187 open (its head said Register v5.12 · Fault v2.21; its "Where the truth lives" said v5.11 · v2.20 · v1.34 · v120; its next-free said F-115) — corrected in 188, recorded in Archive §S187. The first version promised Phase 0 would be quiet and the pin run GREEN; neither was true. It now states what happened, adds the **F-119 inverse check** (`md5sum -c` must exit 0 — a WARNING is a FAIL), and carries the one owed tool fix. Phase 0 = git-clone hash check · the F-88 cross-check · the **F-107 inverse check** · `verify_live_pins.py` (expect **GREEN** this session — the pin list was regenerated at this close against a manifest that pins v5.11). Carries the S187 tasks: the item-wise go-live decision · **12 June's ₹8,487** · the F-107/F-108 structural checks. |
| `START_HERE_SESSION_186` | S185 | `4adc2c646fbdf668882c2587498c8ec5` | superseded by 187/188. Carries the git-clone Phase 0, the F-88 cross-check, the **NEW inverse check (F-107)** — confirm every Tier-0 doc has a manifest row — the `verify_live_pins.py` live-code check (D321), and the S186 tasks (complete the partial pin; resolve the opening float). |
| `START_HERE_SESSION_185` | S184 | `f65e76c2e270cabf522839ef25d4acbe` | superseded by 186. **FILED TO THE REPO AND PINNED AT THE S185 CLOSE (F-107)** — written to project knowledge only at the S184 close, so it was unverifiable at the S185 Phase 0; these are the bytes filed at S185 and they are canonical from here. |
| `START_HERE_SESSION_184` | S183 | `18c2bf463ad53bd075683aebfba8f373` | superseded by 185/186. Carried the git-clone Phase 0 **and** the `python3 /root/deploy/verify_live_pins.py` live-code check (D321) |
| `KB_Register` | **v5.41** | `5e7ac4b96755af0ce097803b296f1a62` | **CURRENT.** **v5.41 (S197 FOLD-IN):** the S193–S196 fold — ~12 moved live pins into the live-file table (all recorded from the S19x close docs, F-97); **D333** (cash-position model) + **D334** (present-request policy) into the decisions index; findings index extended F-155…F-168; reserved next-free decision corrected **D317 → D335**; how-to-use pointers advanced (Archive v1.44 · Fault v2.33 · Runbook v131); a v5.41 lineage row; end marker. **Zero loss proven by reverse application onto the `788139ae…` pin.** **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold) | v5.40 | `788139ae6d1a685f0a507e54cf3e4931` | superseded by v5.41; retained. **v5.40 (S192 CLOSE):** the three live pins recorded as they moved (`0ed19495…` → `0279540e…` → **`44e39d6a…`**) with the SL5/SL6/SL7 contents in the live-file table; F-147/F-149/F-150/F-151 marked CLOSED and F-152/F-153/F-154 added to the findings index; pointers advanced (Archive v1.43 · Fault v2.32 · Runbook v128); a v5.40 lineage row; end marker. **Zero loss proven by reverse application onto the `28a807a0…` pin** — the reconstruction hashes to it exactly. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-S192) | v5.39 | `28a807a04faf927a32087a04bd05d9bb` | superseded by v5.40; retained. **v5.39 (S191 CLOSE):** the fold-in — D332 into the decisions index, F-147…F-151 into the findings index, pointers advanced (Archive v1.42 · Fault v2.31 · Runbook v127), a v5.39 lineage row, end marker. Zero loss proven by reverse application onto the `c93139fd…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-close) | v5.38 | `c93139fd365a5cfd026ed28a8e122b75` | superseded by v5.39; retained. **v5.38 (S191):** **v5.38 (S191):** the F-141…F-146 ruling — the six S190 candidates ruled (five numbers, one fold: the E2 delivery-note path recorded INSIDE F-141 as its second instance); the new findings block, the Fault-Register pointer advanced to **v2.30**, a v5.38 lineage row, end marker. No live code moved; no decision minted (next free stayed D332). Zero loss proven by reverse application onto the `62183676…` pin. |
| `KB_Register` (pre-S191) | v5.37 | `62183676254645e2b2c268a73f283d1a` | superseded by v5.38; retained. **v5.37 (S190 CLOSE):** the fold-in — pointers advanced (Archive v1.41 · Runbook v126), a v5.37 lineage row, end marker. Zero loss proven by reverse application onto the `01567d7a…` pin. |
| `KB_Register` (pre-close) | v5.36 | `01567d7a5cabd55e2fc54f7b0ffd5d35` | superseded by v5.37; retained. **v5.36 (S190 fold 6):** kit `S190_SL4` live — the quota lane (owner ruling "A"): a quota advance (explicit `against_month` · not a loan · recover-fully instalment) recovers IN FULL at the first close ≥ its month, in its own lane beside the D250 waterfall — never queued behind the ₹3.59 lakh loan book. Ledger pin `3b09073a…` → `470bb113…`, selftest 214 → 218 (+4 exactly). Zero loss proven onto the `b8dc2cb1…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold-6) | v5.35 | `b8dc2cb1683e8ca08bc3b36ad749f6cb` | superseded by v5.36; retained. **v5.35 (S190 fold 5):** **v5.35 (S190 fold 5):** kit `S190_F5` live — an edited legacy-sheet day re-becomes an app entry and surfaces in the approvals queue (owner-found on the 31-July day whose money counted while its row hid; smoke 549 → 550). The 31-July ₹10,000 filed and approved; cash ₹1,95,198. Zero loss proven onto the `fde2e11a…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold-5) | v5.34 | `fde2e11ab71d957d4aa2bc625db0e077` | superseded by v5.35; retained. **v5.34 (S190 fold 4):** kit `S190_F4` live — the medical locked-day gate reads UNIT roles, never the SSO broker role (owner-found on the real 31-July screen; one functional line; smoke 547 → 549). Zero loss proven by reverse application onto the `34e31bd3…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold-4) | v5.33 | `34e31bd3dba0956867efb2d651622bdd` | superseded by v5.34; retained. **v5.33 (S190 fold 3):** kits `S190_SL3` + `S190_F3` live — four pins as they moved (ledger `3b09073a…` 212→214 · finance app `7445d20d…` · entry `bae2dd89…` · clinic entry `d4f7ddaa…`, count-equal reproduction-proven on the box), the quota-from-the-install ruling, two toolchain gate refusals recorded. Zero loss proven by reverse application onto the `82738bd7…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold-3) | v5.32 | `82738bd79ebe9e322aedc560d8e9cf9b` | superseded by v5.33; retained. **v5.32 (S190 fold 2):** D331 minted and executed — three pins recorded as they moved (`staff_ledger.py` `0408bbbe…` 190→212 · `finance_app.py` `ccc12afc…` · `finance_entry.html` `b411269f…` 542→547), the D331 decisions-index entry, §5.3 answered from the box's own CSV. Zero loss proven by reverse application onto the `468bf4ca…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-fold-2) | v5.31 | `468bf4ca57bd806d87301320d42a0f3f` | superseded by v5.32; retained. **v5.31 (S190 fold 1):** kit `S190_E2` live — the three D330 pins recorded **as they moved** (app `02062855…` · entry `f819bdf9…` · clinic entry `1c930a3e…`), D330 into the decisions index (supersedes D329), two candidate findings recorded not minted, the end-marker's stale "v1.39" corrected to v1.40. Zero loss proven by reverse application onto the `28b6ab06…` pin. **The live-pin list is generated from THIS version** (A8). |
| `KB_Register` (pre-S190) | v5.30 | `28b6ab06914fd5a6943956877d814cc0` | superseded by v5.31; retained. **v5.30 (S189 CLOSE):** the fold-in — D329 into the decisions index, pointers advanced (Archive v1.40 · Runbook v125), a v5.30 lineage row, end marker. Zero loss proven by reverse application onto the `ef40881f…` pin. |
| `KB_Register` (pre-close) | v5.29 | `ef40881f3b68a355db34632128a08b74` | superseded by v5.30; retained. **v5.29 (S189 expense menu):** the `S189_E1b` app+page pins recorded **as they moved**, the E1a retired-unlived row, F-139 + F-140 into the findings index, the §4a gate verification, pointer to Fault Register **v2.29**, a v5.29 lineage row. Zero loss proven by reverse application onto the `741ecde4…` pin. **The live-pin list is generated from THIS version.** |
| `KB_Register` (pre-menu) | v5.28 | `741ecde44e4263f36a88c0baf0e45907` | superseded by v5.29; retained. **v5.28 (S189 build):** the two `S189_W1a`/`W1b` live pins and the `S189_custody` applied-migration row recorded **as they moved**, F-137 + F-138 into the findings index, pointer to Fault Register **v2.28**, a v5.28 lineage row, end marker advanced. Zero loss proven by reverse application onto the `99b28830…` pin. **The live-pin list is generated from THIS version.** |
| `KB_Register` (pre-build) | v5.27 | `99b288309c2777b6c5d74c2662766c66` | superseded by v5.28; retained. **v5.27 (S189):** the `S189_G1a` live pin recorded **as it moved**, F-135 + F-136 into the findings index, the pointer to Fault Register **v2.27**, the stale "Archive v1.38" pointer corrected to **v1.39** (F-45/F-116 family, recorded not silent), a v5.27 lineage row, end marker advanced. Zero loss proven by **reverse application** onto the `3aa89f5a…` pin. **The live-pin list is generated from THIS version.** |
| `KB_Register` (pre-S189) | v5.26 | `3aa89f5a0c9dd7c6121c0a657dd573cd` | superseded by v5.27; retained. **v5.26 (S188 final):** F-134 into the findings index, the pointer to `END_OF_SESSION_PROMPT` **v5**, a v5.26 lineage row, end marker. **The live-pin list is generated from THIS version** (`register_pin_verified: yes`). |
| `KB_Register` (pre-final) | v5.25 | `fd14b63d894a15922f347318959a6f79` | superseded; retained *(de-labelled at S189 — it read **CURRENT** beside its successors)*. **v5.25 (S188 post-close):** the two `S188_D2c` live pins, F-132/F-133 into the findings index, pointers advanced (Archive v1.38 · Fault v2.25 · Runbook v124), a v5.25 lineage row, end marker corrected. Zero loss proven by reverse application onto the v5.24 pin. |
| `KB_Register` (pre-post-close) | v5.24 | `9b713355330306fbe5f192e9a5b91771` | superseded; retained *(de-labelled at S189)*. **v5.24 (S188 close):** the fold-in — F-130/F-131 into the findings index, pointers advanced (Archive v1.37 · Fault v2.24 · Runbook v123), a v5.24 lineage row, end marker corrected. **v5.23 (S188 build)** recorded the four live pins from `S188_D2a`/`S188_D2b` **as they moved**, not at the close, each predecessor kept as a `*(superseded)*` row. Both bumps proven zero-loss by **reverse application** — strip what S188 inserted, undo what it edited, and the reconstruction lands on the previous version's pin exactly. |
| `KB_Register` (pre-close) | v5.23 | `64814f4fdcf6570d2cd195ad07e20f14` | superseded by v5.24; the build-current Register the S188 pins were recorded into (also carried in kit `S188_KB`). |
| `KB_Register` (pre-S188) | v5.22 | `116a0bdba426f33c0fda69652bba46fc` | superseded; retained *(de-labelled at S189)*. **v5.22 (S187 close):** the full fold-in — D327/D328 into the decisions index, F-122…F-126 into the findings index (F-125/F-126 full entries added), the how-to-use pointers advanced (Archive v1.36 · Fault v2.22 · Runbook v122), a v5.22 lineage row, and the end-marker corrected (it had read "v5.11 (S186)" through v5.21 — the F-45/F-116 footer family, recorded not silent). Additive; nothing in v5.21 cut. **S187 → v5.22 across TEN bumps in one session** (v5.13 V1a · v5.14 M1a/D325/F-124 · v5.15 D1a/D326 · v5.16 P1a · v5.17 P1b/F-125 · v5.18 P2a · v5.19 H1a · v5.20 H1b/Design-Language · v5.21 H1c/logo · v5.22 close) — pins recorded as they moved, per the S186 practice. |
| `KB_Register` (pre-close) | v5.21 | `0f23b17567d16cf818d2de71574f8252` | superseded by v5.22; the build-current Register the S187 pin lists were generated from (kit `S187_H1c` carries it; the v5.13–v5.20 intermediates live in their kits — bytes preserved, deliberately not manifest rows). |
| `KB_Register` (pre-S187) | v5.12 | `1da5b0c4783e50fc2cbebe4b9ac7c61a` | superseded by v5.22. **v5.12 (S186 post-close):** `finance_workbench.html` re-pinned **from the box** to `18c71e63…` — the close had kept the superseded `S186_R2a` build and the first live-pin run went RED on it (**F-118**); the stale Archive/Fault-Register/Runbook pointers in §How-to-use corrected. Everything else byte-identical to v5.11: **3 lines changed, 7 added.** **S186 → v5.11 across FIVE bumps in one session** (v5.7 the completed `finance_app.py` pin + F-109/F-110; v5.8 F-112 + D323 + the cash close spec; v5.9 the close applied live; v5.10 the three upgrades' pins; v5.11 the ingest fix, the portal upload, F-104 cleared and **D324**). **Pins were recorded as they moved, not at the close** — deliberately, because unrecorded live pins are the F-97 condition and this session was spent digging out of it. Additive throughout; nothing in v5.6 cut. |
| `KB_Register` (pre-S186) | v5.6 | `bc4812168860dc7732d8902faa092f21` | superseded (was mislabelled CURRENT here until the S187 close — one of the five duplicate-CURRENT rows). **S184+S185 → v5.6** (additive: the S184 cash-correction + C2a-exception migration markers; **D322** into the decisions index; **F-105–F-108** into the findings index; `finance_app.py` advanced to the S184 build as an explicitly **PARTIAL pin** `c66bec2b76…` with the remainder owed from the box; the stale `v5.4` H1 corrected — itself an F-45/F-108-family self-reference; v5.6 lineage row; nothing in v5.5 cut). |
| `KB_Register` (pre-S185) | v5.5 | `3cad79e6361c6e1777f3bc9db983770d` | superseded by v5.6; **S183 → v5.5** (additive: 9 live pins corrected to the box + the Marg feed live entries (`marg_report.py 829f4344…`, `marg_backfill.py fa33ec8a…`, migration `S183_marg_map`, `/root/deploy/verify_live_pins.py`), **D321** into the decisions index, **F-100–F-104** into the findings index, finance/cash reconciliation state, v5.5 lineage row; nothing in v5.4 cut). **S182 → v5.4** (additive: the `portal.py` pin CORRECTED after F-97 found it two sessions stale, `marg_backfill.py` added, D320, F-96–F-99, v5.4 lineage row; nothing in v5.3 cut). **S181 → v5.3** (additive: the clinic-module live entries, D317–D319, F-90–F-95, v2.17/v1.11.0-R promotions, v5.3 lineage row; nothing in v5.2 cut). **S180 → v5.2** (additive: six finance live-file entries changed/added, D314–D316 into the decisions index, F-85–F-89 into the findings index, v5.2 lineage row; nothing in v5.1 cut). **S179 → v5.1** (`1c86b83a…`) (additive over the v5.0 compaction: the clinic-finance live-file block added to the consolidated table; **D313** folded into the decisions index; **F-84** into the findings index; v5.1 row added to the lineage; nothing in v5.0 cut). **S178 → v5.0** (`ee12a63d…`; COMPACTION — the three duplicated history forms removed zero-loss, decisions index completed through D312, truncation-proof END-marker; Archive UNCHANGED v1.25). Earlier lineage in the §S… blocks below. |
| `HANDOFF_RUNBOOK` | **v131 (S197 fold)** | `253165b9cf457e425b27a6b6325f8b9a` | **CURRENT.** §0 the S197 fold-in narrative (the four-session debt cleared; the F-series fork reconciled; no live code moved) · §1 mental models (+ *a four-session canon debt is F-108 at scale* · *reconcile a number fork by circulation, not chronology* · *a fold is proven like a code change — prefix proof + reverse application* · *file the doc before the close, not at it*) · §2 live backlog (⭐0 owner actions incl. token rotation · ⭐1 the Auditor's first reports · ⭐2 the August month-end · ⭐3 the builder backlog) · §3 install discipline (unchanged; no installs) · §4 the boundary (held — owner residual: PUBLISH_ALL + the on-box pin-list copy + verify). File `HANDOFF_RUNBOOK_2026-08-23_Session197fold_v131.md`. |
| `HANDOFF_RUNBOOK` (pre-fold) | v130 (S196 close) | `b48c68ea323d0ad36e11d3fcdd063d51` | superseded by v131; retained (was part of the S193–S196 debt; filed in `KB_canon_S196close/`). §0 the S196 narrative (six kits: attendance self-service + PWA + the renewals/tile/A4 health completion) · the Auditor scheduled. |
| `HANDOFF_RUNBOOK` (pre-S196) | v129 (S193 close) | `13ade4ddf919ffd242f7a1eb985a5b7e` | superseded by v130; retained. **Filed to the repo at the S197 fold** (`KB_canon_S197fold/filed/`) — was part of the S193 debt, project-knowledge-only until now. §0 the S193 narrative (F6 + discount + cash-position + D333). |
| `HANDOFF_RUNBOOK` (pre-S193) | v128 (S192 close) | `9e854c1682ebc00cf65d08d5c151612f` | superseded by v129; retained. **CURRENT at S192.** §0 the S192 narrative (the KB freed · three kits live · the gated corrections · F6 stopped on purpose · a warning that became a finding) · §1 mental models (+ *a warning is a finding* · *a gate that fires wrongly is worse than no gate* · *the files that gate an install are part of the install* · *test your own arithmetic before the test that blesses it* · *count checks programmatically, never by eye* · *check what is already connected before asking the owner to do it by hand* · *never ship an ellipsis into a terminal* · *survey → dry run → write*) · §2 live backlog (⭐0 the application + approval, with a clock · ⭐1 F6, seeded store FIRST · ⭐2 F-153 · ⭐3 the July close · ⭐4 Darpan's portal · ⭐5 the first month-end) · §3 install discipline (+ deliver into the repo, not into a download) · §4 the boundary (held). File `HANDOFF_RUNBOOK_2026-08-19_Session192close_v128.md`. |
| `HANDOFF_RUNBOOK` (pre-S192) | v127 (S191 close) | `8d56943c95fbb17ae4603a467be011de` | superseded by v128; retained. §0 the S191 narrative (the confirmation session; D332 signed; F-147…F-151) · §1 mental models (+ a machine inherits the manual system's judgment clauses as requirements · a policy lives where the machine can read it · whole-supersession re-homes dependencies · rules attach to instruments, never people · one approval, both books) · §2 live backlog (⭐0 the gated data corrections BEFORE the Aug close · ⭐1 the D332 builds · ⭐2 owner-side: application, portal introduction, July sheet · ⭐3 Surendra) · §3 install discipline (+ all-staff salary artefacts never enter the public repo) · §4 the boundary (held). File `HANDOFF_RUNBOOK_2026-08-19_Session191close_v127.md`. |
| `HANDOFF_RUNBOOK` (pre-S191) | v126 (S190 close) | `359b550e2dd2725e59673e7b85e34e4d` | superseded by v127; retained. §0 the S190 narrative (D330 + D331 executed; eight kits; the sitting closed to the counted rupee) · §1 mental models (+ the gates catch the toolchain too · a refusal that looks like a save costs real entries · attribution decides which month, the close collects it · identity from the unit layer, never the broker · a queue that hides a class must un-hide on class change · the native-select Chrome rule) · §2 live backlog (⭐0 Darpan's 17/18 Aug · ⭐1 Surendra's ₹8,000 · ⭐2 the F-141 ruling · the first SL4 month-end to watch) · §3 install discipline (+ gate constants by transcription · grep the whole output, never tail -1 · single chained VPS commands) · §4 the EOS automation boundary (held). File `HANDOFF_RUNBOOK_2026-08-19_Session190close_v126.md`. |
| `HANDOFF_RUNBOOK` (pre-S190) | v125 (S189 close) | `98d43dc3145100338d3f1d91887ad19e` | superseded by v126; retained. §0 the S189 narrative · §1 mental models (+ the seven new S189 rules) · §2 live backlog (⭐0 the ₹30,000 sitting · ⭐1 the D329 build) · §3 install discipline (+ reproduction-proof for count-equal kits · rehearsal stores carry the live SHAPE) · **§4 NEW: the EOS automation boundary**. File `HANDOFF_RUNBOOK_2026-08-18_Session189close_v125.md`. |
| `HANDOFF_RUNBOOK` (pre-S189) | v124 (S188 post-close) | `ed9ed3f994c7c2642b37e0d8e48ce60d` | superseded by v125; retained. Adds **§0A — what happened after the close**, and two mental models: *"already correctly scoped" is a test result or it is nothing* (F-132) and *survey the box before building a display of its data* (F-133). §2 gains **⭐0b — the ₹2 lakh question**: cash-in-hand is overstated by unbooked handovers and no record exists to net it down. File `HANDOFF_RUNBOOK_2026-08-18_Session188postclose_v124.md`. |
| `HANDOFF_RUNBOOK` (pre-post-close) | v123 (S188 close) | `a09b351142074c26a9ca34e911d26c04` | superseded; retained *(de-labelled AND re-named at S189 — see the note under this table)*. §0 what happened (S188 — stage D2 in two kits, and how each of five findings was found by building the next thing on the last) · §1 mental models (+ *a route states its own role* · *a test fixture must not grant the privilege the test exists to refuse* · *a marker that records "this was shown" must record who to* · *when a kit preserves every id, assert something it did not preserve* · *a command that looks read-only is not, until its side effects are checked*) · §2 live backlog — ⭐0 walk Darpan through it · ⭐1 F-130's three lines · ⭐2 F-131's 14 deletes · ⭐3 the rest of the contract · §3 install discipline (+ the projection written before measuring; the on-box differential smoke; `--no-optional-locks`). File `HANDOFF_RUNBOOK_2026-08-18_Session188close_v123.md`. |
| `HANDOFF_RUNBOOK` (pre-S188) | v122 (S187 close) | `5ab667f1ec9441b3659224b58d802654` | superseded; retained *(de-labelled and re-named at S189)*. §0 what happened (S187 — the six threads, eight kits) · §1 mental models (+ *never attest to a hash that will change after you hash it* · *a checker may not print a claim it did not test* · *a gate that fires is the system working* · *the untested path was the exit* · *secrets have a one-way valve into chat*) · §2 live backlog — ⭐0 prove the GREEN · ⭐1 the S188 contract build · ⭐2 the §4a ₹70,000 gate · §3 install discipline (+ `bash -n`, v1.2 tools, PUBLISH_ALL). File `HANDOFF_RUNBOOK_2026-08-18_Session187close_v122.md`. |
| `HANDOFF_RUNBOOK` | v121 (S186 post-close) | `cca9896a118d90fd6c6dbaccdc7d3496` | superseded by v122. ⚠ its own end-marker read "v120" — the F-45/F-116 footer family, found at the S187 open; corrected in v122; the v121 bytes stand as published. **v121 adds §0A** — what happened after the close (F-115…F-121) — and puts the owed `verify_live_pins.py` manifest check at the head of §2 as **item 0**. v120 (`b874064b…`) superseded, retained. §0 what happened (S186 — the three threads) · §1 mental models (+ *a record asserting something about another component is a claim, not a fact* · *a true statement can expire* · *test the mechanism, do not argue about it* · *the projection is the check*) · §2 live backlog — ⭐1 the item-wise go-live decision, ⭐2 the 12 June ₹8,487 · §3 install discipline; file `HANDOFF_RUNBOOK_2026-08-17_Session186close_v120.md` |
| `HANDOFF_RUNBOOK` (pre-S186) | v119 (S185) | `a435d2dd316786697cd46f4284b76a0f` | superseded *(re-named at S189; it had been mislabelled the-current-one here until the S187 close, and the word survived in the prose where a bare-name scan still reads it as a second CURRENT row)*. §0 what happened (S185 — Phase 0 green; F-107 + F-108 raised; the three-session fold-in executed) · §1 mental models (+ absence-blindness; + deferral compounds) · §2 live backlog — ⭐0 complete the partial pin, ⭐1 resolve the opening float · §3 install discipline; file `HANDOFF_RUNBOOK_2026-08-17_Session185close_v119.md` |
| `HANDOFF_RUNBOOK` | v118 (S184) | `2481324798c39c142a8286f1d1b8cd59` | superseded by v119. **FILED TO THE REPO AND PINNED AT THE S185 CLOSE (F-107).** Carries the full S184 narrative — the cash correction, D322, F-105/F-106, the reserve-model design and the opening-float investigation — and was the source for the §S184 Archive append. |
| `HANDOFF_RUNBOOK` | v117 (S183) | `cc523169dbcd0e2fb50a96ab132e215b` | superseded by v118/v119. §0 what happened (S183 — F-97 fix live; Marg feed live + backfilled; Sanjeevni cash reconciled, whole) · §1 mental models · §2 live backlog — ⭐S184 = book the Sanjeevni cash correction (gated) · §3 install discipline; file `HANDOFF_RUNBOOK_2026-08-16_Session183close_v117.md` |
| active incident | — | — | **only while open**; none open |

> **De-labelling note (S189).** Rows above that read **CURRENT** beside a live successor were de-labelled at the S187 close, and **five of them had come back by S188** — Registers v5.22/v5.24/v5.25, Fault Registers v2.22/v2.24/v2.25, Archives v1.36/v1.37/v1.38 and Runbooks v122/v123. All are corrected here. **The Runbook family was the one that mattered:** the Register, Archive and Fault-Register duplicates all carry a `(pre-…)` suffix in their first cell, which is exactly what lets `gen_live_pins.py` find the one true CURRENT row (it matches the bare name and raises rather than guesses if it sees two). **The three Runbook rows shared the bare name `HANDOFF_RUNBOOK`** — so had that same strict rule ever been pointed at the Runbook, it would have refused. Re-named `(pre-post-close)` and `(pre-S188)` here to match the convention that protects the others. **F-45 family, third recurrence in this file; recorded, not silently fixed.**

## Tier 1 — reference (hash-verified · read only if touched · rewrite only if changed)

| Doc | Version | md5 | Notes |
|---|---|---|---|
| `KB_History_Archive` | **v1.44** | `eba5247064e7a9ab6ebb24d84b64a44a` | **CURRENT.** **§S193…§S196 appended at the S197 fold** as ONE contiguous pure append — the **800,148 bytes** before v1.43's END marker **proven byte-identical by direct comparison** (+34,510). Carries the full S193 (F6/discount/cash-position/D333), S194 (five backlog stars), S195 (the long build session + the Marg-401 crisis + the Auditor seed), and S196 (attendance self-service + health completion + D334) narratives. END-marker present. |
| `KB_History_Archive` (pre-fold) | v1.43 | `5a591dbcd72464429016ac05671447f4` | superseded by v1.44; retained. **§S192 appended at the S192 close** as a **pure append** — the **786,212 bytes** before v1.42's END marker **proven byte-identical by direct comparison** (+14,280). Carries the full S192 narrative: the KB cleanup, the three kits, the gated corrections, F6's deliberate stop, and F-152 … F-154. END-marker present. |
| `KB_History_Archive` (pre-S192) | v1.42 | `b59532f7cda15662a8bb86bf7a85c1b5` | superseded by v1.43; retained. **§S191 appended at the S191 close** as a **pure append** — the **765,415 characters** before v1.41's END marker **proven byte-identical** (+9,311). Carries the full S191 narrative: the ruling fold, the confirmation, F-147…F-151, D332's rulings, Darpan's gated corrections and the July remediation. END-marker present. |
| `KB_History_Archive` (pre-S191) | v1.41 | `cf1afacafd93de762ee41e6c31142e0f` | superseded by v1.42; retained. **§S190 appended at the S190 close** as a **pure append** — the **754,537 characters** before v1.40's END marker **proven byte-identical** (+11,188). Carries the full S190 narrative, both decision summaries (full texts live in the pinned signed contracts), the six F-141 candidates, and the deferred-to-S191 list. END-marker present. |
| `KB_History_Archive` (pre-S190) | v1.40 | `464861906ca8cd4cd9a94a28f5afa33a` | superseded by v1.41; retained. **§S189 appended at the S189 close** as a **pure append** — the **742,406 characters** before v1.39's END marker **proven byte-identical** (+12,133). Carries the full S189 narrative + the D329 full text. END-marker present. |
| `KB_History_Archive` (pre-S189) | v1.39 | `81c34383365188632668898ffc50208c` | superseded by v1.40; retained. **§S188-FINAL appended** as a **pure append** — the **738,795 characters** before v1.38's END marker **proven byte-identical** (+3,625). END-marker present. |
| `KB_History_Archive` (pre-final) | v1.38 | `547f9f20e284b65a9af6250817c276cd` | superseded; retained *(de-labelled at S189)*. **§S188-POST appended** as a **pure append** — the **734,024 characters** before v1.37's END marker **proven byte-identical** (+4,788). END-marker present. |
| `KB_History_Archive` (pre-post-close) | v1.37 | `7d95a233925fbe47e3c2417cdf5bbc0f` | superseded; retained *(de-labelled at S189)*. **§S188 appended** (stage D2 in two kits; the five findings; no decision minted) as a **pure append** — the **726,539 characters** before v1.36's END marker **proven byte-identical** (+7,491). END-marker present. |
| `KB_History_Archive` (pre-S188) | v1.36 | `eb99a9b455764452f3ca86bc57cfd132` | superseded; retained *(de-labelled at S189)*. **§S187 appended** (the eight-kit session narrative + D325–D328 full texts) as a **pure append** — the **715,735 bytes** before v1.35's END marker **proven byte-identical** (+20,816 chars). END-marker present. |
| `KB_History_Archive` (pre-S187) | v1.35 | `d2adece3cf6e5dfb03c752169e0442e2` | superseded by v1.36. **§S186-POST appended** (the post-close correction, F-115…F-121) as a **pure append** — the 700,197 characters before v1.34's END marker **proven byte-identical** (+5,239). All history, verbatim; **§S186 is last** — appended at the S186 close as a **pure append**, content before the v1.33 END marker **proven byte-identical** (+12,250 chars). END-marker present. |
| `KB_History_Archive` (pre-S186) | v1.33 | `6548a1550e57409cafd507f1c90b9baa` | superseded (was mislabelled CURRENT here until the S187 close). All history, verbatim; **§S185 is last** — §S183, §S184 and §S185 appended at the S185 close as **one contiguous chronological append** (+21,183 chars), content before the v1.30 END marker **byte-identical to the `7a673ac6…` pin, proven mechanically**. Appending §S185 ahead of §S183/§S184 would have put the history permanently out of order; an append-only file cannot be repaired by a later append. END-marker present. |
| `KB_History_Archive` (pre-S185) | v1.30 | `7a673ac6e09abeb60642aa58367bf860` | superseded by v1.33. §S182 is last (appended at the S182 EOS; pure-append, **content before the v1.29 END marker byte-identical**, +18,638 chars); END-marker present. Previously §S181 was last (appended at the S181 EOS; pure-append, **content before the v1.28 END marker byte-identical to the `0e8b4bd6…` pin**, +15,747 chars); END-marker present. |
| `S186_Sanjeevni_Cash_FINAL_Close` | S186 | `c9b93821a1f0af815e673549c261f2eb` | **AUTHORITATIVE for the Sanjeevni cash close.** The Yes Bank evidence for F-112, the custody model, the ₹99,017, the drawer clearing that proved itself to the rupee, the ₹87,205 derivation, and what remains owed. Supersedes the float sections of `S183_Sanjeevni_Cash_Reconciliation_YesBank` and `S184_Float_Investigation` wherever they differ. |
| `S186_F113_Backfill_Silent_Shortfall` | S186 · **FILED S187** | `0fc78c1fe326f16e1a907a47805e8267` | **FILED to the repo and PINNED at the S187 close — the F-107 condition its row named is closed.** Hashed as delivered (a filing note is appended to the document; content otherwise as written at S186). | *(original note:)* **F-113 in full, including the two WRONG diagnoses struck through rather than deleted** (a short export; a driver abort) and how each was disproved against the real file and the real adapter. Kept as the worked example of D172/D188 applied to a diagnosis. |
| `S186_Cash_Movement_Sheet_Analysis` | S186 · **FILED S187** | `9b717ab7df89fbd7a973aa4e132a3ac5` | **FILED to the repo and PINNED at the S187 close — same F-107 condition, closed.** Hashed as delivered (filing note appended). | *(original note:)* the custody-sheet data extraction and ledger arithmetic. **Two conclusions in it were wrong and are struck through, not removed** (F-23 discipline). Superseded on conclusions by `S186_Sanjeevni_Cash_FINAL_Close`. |
| `S179_Finance_LIVE_State` | S179 | `54cb25a88adc5692360341113a87a43e` | **NEW S179 · SOLE live-state reference** for the clinic-finance subsystem (D313 · F-84). Live URLs/paths/service, final live md5s (UPI + browse folded), the three security faults + fixes, the B1 data findings, design invariants, and what is still open. Companions in project knowledge: build contract v2, migration analysis, B1 reconciliation, `S179_Marg_Sale_Report_Analysis`, `S180_Marg_Folder_Recon`, delivery notes. Opened on demand at any finance task. |
| `S187_Daily_Flow_v2_Target_Design` | S187 · **SIGNED CONTRACT (D326)** | `83e228d9c81a68d4c9c6dd6a1d15e0a0` | the staged Daily Flow v2 architecture — one canonical Day Page, save-then-see allow-but-badge, the Ledger bridge (gated on the ₹70,000 check), stages D1–D5. D1 shipped (`S187_D1a`). Opened at any v2 build. |
| `S187_Daily_Flow_v2_Design_Addendum_Returns_360` | S187 · **SIGNED CONTRACT** | `5f3d79871568f5838e9b2817c63af580` | returns at reception (eligibility legends · print slip · CN reconciliation) · Darpan's mirror · 360 wiring + refill-skippers · orthotics (asset-app purchase bills — the owner's §8 answer) · the Hub · the D327 `counter` role · Tailscale+RustDesk · §9 the parked D6. **The S188 build starts on this.** |
| `Clinic_Design_Language_v1` | S187 · **THE DEFAULT** | `a8b17290b7f487ee10cf5b02f2f31cca` | the design system every new or rebuilt page follows from S187 (warm surfaces · branded sticky header + tabs · tabular numerals · bounded tables · stat tiles · icon+label status, never color alone · folded help · back-to-top). Born with kit `S187_H1b`, live in H1c. |
| `S189_Advance_Pool_Design_D329` | S189 · **SUPERSEDED BY D330 (S190)** | `2f9c7f1b701c8df74d542bce5945317f` | the Advance Pool design. **Nothing of it was built; superseded whole by D330** — a hard derived ceiling removed the random-unbounded premise the pool, the B6 bridge and the LINK card existed for. Kept: the ₹40,000 stays out (verified recovered) · advances per-staff by construction. Retained for lineage. |
| `S190_Staff_Advance_Policy_D331` | S190 · **SIGNED CONTRACT (D331) · EXECUTED S190 (kits `S190_SL2` + `S190_F2`)** | `fd7ff1636dbdecdc1a47722880d37814` | the staff advance policy — the derived per-staff ceiling (50% default · Darpan 75%) shown inline for every staff member · SPECIAL above it, gated on the uploaded signed application · `against_month` attribution with the close eligibility filter · the forward-only cross-system count. FILED at the S190 second fold, the session it was signed. |
| `S191_Waiver_Capacity_Layer_D332_Design` | S191 · **SIGNED CONTRACT (D332) · FILED at the close it was signed** | `b59e9fdf99aba91b6937c1eac8a103e6` | v3, the owner's agreement and refinements minuted in the document: defer-only (waivable 3rd-defer penalty, loans only) · the waiver instrument · the capacity rule (F-147) · the schedule lane with uneven distributions · the request-not-draw pharmacy flow (F-148) · enforcement dates as settings (F-150) · perks view · the F-151 wording fix · Darpan's July-zero, ₹20,000 SPECIAL 8/4/4/4, and 50% ceiling rulings. Builds S192_SL5/SL6/SL7/F6. |
| `S192_SL5_Live_Pin_Record` | S192 · **project knowledge; repo-filing OWED at the S193 open** | *(md5 owed — a real hash, not a placeholder: D172/D188)* | the three ledger pins recorded **at the moment each moved** (F-97's condition closed in-session, not at the close), with what each kit contains, the consequence for `verify_live_pins.py`, the candidate findings and the debts owed at the close. |
| `S192_Gated_Data_Corrections_Executed` | S192 · **project knowledge; repo-filing OWED at the S193 open** | *(md5 owed)* | the survey that made the correction safe, the six writes with their row ids, the independent post-write verification, F-153, and what the August close will do once the SPECIAL is approved. |
| `S192_F6_Design_and_Survey` | S192 · **SIGNED DESIGN, build not started; repo-filing OWED at the S193 open** | *(md5 owed)* | F6 taken from the live bytes: what is already built, the ledger-bridge mechanism, idempotency, write ordering, fail-loud, and the honest reason the build was not started (F-87 — the smoke suite cannot run offline). **S193's first task is the seeded store, not the feature.** |
| `S191_Darpan_Money_Model_Objective_Report` | S191 · **FILED at the close** | `e0de19c9c1ad04c03f9645c980f14bd5` | the objective statement of how Darpan's salary, advances and instalments are actually managed — D250/D258/D331 read against the LIVE code and pages; the live position to the rupee; the F-147/F-148/F-149 holes as found. Companion to the D332 contract. |
| `S195_Medical_Watcher_LIVE_Reference` | S195 · **FILED at the S197 fold · SOLE reference for the Marg capture pipeline** | `885090ab946b61e7b5a990a14a190a15` | the resident medical-PC watcher (overwrite-proof capture, autostart, bundled portable Python — the F-167 standard), the manojz 10-min pull, the 5-type router, the archive + Drive offsite. Opened at any Marg-capture work. |
| `AUDITOR_SEED_v1` | S195 · **FILED at the S197 fold · the LIVE weekly Auditor briefing** | `b4e349cbcf01547ff774a7c3c434bb21` | the entire briefing for the read-only Auditor (separate role, finds-never-fixes; slice rotation; AF-# numbering; rules of evidence; coverage-not-clean). Scheduled Mondays ~07:05 IST (`trig_01XBRt7dcsXcjtmgdmemnR3x`). |
| `Clinic_Source_Data_Retention_Policy_v1` | S195 · **FILED at the S197 fold · draft for owner approval** | `90831162f985359b69725b1dc874e679` | Marg/Labmate/Docterz source-export retention: 8 years, Drive-synced `D:\MargArchive`, monthly cold-zip for closed FYs, purge rules; not tax advice (confirm with the CA). |
| `S193_Close_Summary_and_Pins` · `S193_*` · `S194_*` · `S195_*` · `S196_*` (session docs) | S193–S196 · **FILED at the S197 fold** | *(each hashed in `KB_canon_S197fold/filed/SUMS.md5`)* | the S193–S196 build-state / finding / design / pin records, filed to the repo to close the F-107 condition for those sessions. History now consolidated in **Archive §S193–§S196**; these are the session-scoped source records, opened on demand. The `S195_medical_kit/` sources (macro · guard · report parser · setup) live in project knowledge and in the repo `deploy_kits/S195_MARG/` kit. |
| `S190_Expense_Menu_Redesign_D330` | S190 · **SIGNED CONTRACT (D330) · EXECUTED S190 (kit `S190_E2`)** | `5bc70c4e6d6093984aa0779708ac3f3a` | the expense menu redesign — three categories · the derived per-staff advance ceiling (settings, floored to ₹100, F-136) · compulsory per-row evidence at File, no escape hatch · the draft-resave wipe closed by refill + stable uids · clinic in scope expenses-only · drawings split · petty book PARKED. FILED at the S190 first fold. |
| `EOS_DEFINITION_PORTABLE` | v1 (S189) | `49864ebdf4e4ec4b87e432f9fcb2bf91` | the cross-project EOS / EOS-light specification: the eight invariants, the automation boundary (the owner's residual work enumerated and minimal), the A0–A8/B–F sequence, and the three failure patterns it prevents (F-108, F-134, F-107). Project-agnostic; this project's v5 routine is the reference implementation. |
| `S189_70k_Gate_Verification` | S189 · **FILED at the third fold** | `563b2e3eaff5cf0d6bfa32450f7c8926` | **the D326(c) §4a gate: VERIFIED OPEN.** Five machine checks (the Staff Ledger raw, the finance drawer, the live workbook, the §S155 migration record, July's close) + the owner's confirmation — the Apr–Jun ₹40,000 was recovered from salaries in the workbook era; no double-count in any book; the 17 Aug ₹30,000 is in NEITHER book yet (owner one-click). The salary bridge (D3) is UNBLOCKED. |

| `Dr_Manoj_Clinic_Umbrella_Architecture` | v1.58 | `728cc64950502011ff220e1249e488ce` | strategy + decisions log |
| `Call_Console_Evolution_Spec` | v2.4 | `63978d982d1f8037f728023d15a01328` | dashboard-as-dialer (active) |
| `Frontend_Dashboard_Documentation` | v4 (S140) | `02ef929b75aa77ec071c903705335375` | dashboard still evolving |
| `Diagnostics_Surveillance_System_Spec` | v2.3 | `bdd5fa5479a57dfb73fa653054a3f329` | fault codes / detection |
| `Maintenance_SOP_System_Spec` | v1.1 | `35b257ee0c59ff2e4ba9820a6ac64d37` | forward-looking (project not live) |
| `API_QUICK_REFERENCE_CARD` | — | `68c4fc344bf74caaea706149cd22e64c` | small + stable; in the repo `canonical-docs/` (byte-identical) |
| `AI_Verdict_Layer_Master` | v1 (S145) | `bd4b67f6810cd2316eb58dfe6bf180cd` | Product B analytics |
| `Clinic_Callback_Tracker_AppsScript_Audit` | v1.9 | `41dd9fd6b607e59e15e3e646b775d640` | unfinished audit (Pass 4 not started); reference only — NOT the frozen dossier |
| `Fault_Action_Register` | **v2.33** | `fc0a9d534101cc01d7beb0922d387e37` | **CURRENT** findings register (F-##). **v2.33 (S197 FOLD):** the F-series fork reconciled and **F-155 … F-168 landed** — F-155–F-159 (S193, all closed same-session), F-160–F-162 (S196), F-163 (S194's minted candidate), F-164–F-168 (S195's five, F-168 the only new OPEN). **F-148 and F-153 rows updated to CLOSED-S193** (kit `S193_F6`). Numbering non-chronological across F-160–F-168, recorded not silent. §7 index F-154 → **F-168**; three new §7.1 sections; next free **F-169**. Reverse-application-proven onto the `a52fa154…` pin. |
| `Fault_Action_Register` (pre-fold) | v2.32 | `a52fa15451d8ad614455030d9f6aac58` | superseded by v2.33; retained. **v2.32 (S192):** **four CLOSED by shipping the code that answers them** — F-147 (capacity rule, SL6) · F-149 (perks made READABLE, SL7) · F-150 (`attendance_enforce_from`, SL5) · F-151 (the prohibited word, SL5); **F-148 stays OPEN** (F6 designed, deliberately unbuilt — F-87); **three minted** — F-152 (`.gitattributes` never pinned `*.txt`/`*.md5`, so a CRLF `SUMS.md5` would refuse a good kit at its own gate; the publish *warning* was the finding), F-153 (`make_contra` drops `against_month`, so reversed money keeps eating its quota — worked around, one line still open), F-154 (a live bridge to the owner's machine went unused while he was asked to unzip by hand). §7 index F-151 → **F-154**; full text in the new §7.1 S192 section; next free **F-155**. |
| `Fault_Action_Register` (pre-S192) | v2.31 | `a9484bc4d20ffeb027c8e411a5f62cd0` | superseded by v2.32; retained findings register (F-##). **v2.31: F-147…F-151 appended at the S191 close, the session they were raised** — none found by a failure; all five found by confirming the live system against its own signed rulings, all five ruled by the owner same-day (build · build-and-test · correct · build-as-setting · correct), all five OPEN pending the S192 builds. §7 index F-146 → **F-151**; full text in the new §7.1 S191 section; next free **F-152**. Zero loss proven by reverse application onto the `e38e9789…` pin. |
| `Fault_Action_Register` (pre-close) | v2.30 | `e38e9789278c7197893e563c5f2d7d19` | superseded by v2.31; retained. Findings register (F-##). **v2.30: F-141 … F-146 appended at S191** — the six S190 candidates, raised that session and deliberately **recorded-not-minted** (the ruling is the owner's; at S191 he ruled the call was the assistant's). Five numbers, one fold: the E2 delivery-note path is recorded INSIDE F-141 as its second instance. **F-146 alone is OPEN** — the "verify in the book, not on the form" discipline is standing, the UI fix is owed. §7 index F-140 → **F-146**; full text in the new §7.1 S190 section; next free **F-147** (and it agrees with the last index row — the F-108 check). Zero loss proven by reverse application onto the `b4c0e40c…` pin. |
| `Fault_Action_Register` (pre-S191) | v2.29 | `b4c0e40cb788ee592bfb5fb7cd7abe24` | superseded by v2.30; retained. Findings register (F-##). **v2.29: F-139 + F-140 appended at the S189 expense-menu build**, the session they were raised — both CLOSED the same day, live (§7 index F-138 → **F-140**; full text in the new §7.1 section). Next free **F-141**. Zero loss proven by reverse application onto the v2.28 pin. |
| `Fault_Action_Register` (pre-menu) | v2.28 | `fcbfdefac3d83f07aa7ea28a30437b73` | superseded by v2.29; retained. **v2.28: F-137 + F-138 appended at the S189 build**, the session they were raised — and both CLOSED the same day, live (§7 index F-136 → **F-138**; full text in the new §7.1 S189-build section). Next free **F-139**. Zero loss proven by reverse application onto the v2.27 pin. |
| `Fault_Action_Register` (pre-build) | v2.27 | `d8b13cf0aae35429d533f9f02bde39b6` | superseded by v2.28; retained. **v2.27: F-135 + F-136 appended at S189**, the session they were raised — fifth consecutive clean close (§7 index F-134 → **F-136**; full text in the new §7.1 S189 section). Next free **F-137**. Zero loss proven by reverse application onto the v2.26 pin. |
| `Fault_Action_Register` (pre-S189) | v2.26 | `09c072d8e403d901b36223b0a003512c` | superseded by v2.27; retained. **v2.26: F-134 appended at the final fold** — **eight** findings this session, every one appended the session it was raised (§7 index F-133 → **F-134**). Next free **F-135**. |
| `Fault_Action_Register` (pre-final) | v2.25 | `ba5feb1bc2f3c0ab4e1b82168723ab38` | superseded; retained *(de-labelled at S189)*. **v2.25: F-132 + F-133 appended after the close** — seven findings this session, every one appended the session it was raised (§7 index F-131 → **F-133**; full text in the new §7.1 S188 POST-CLOSE section). Next free **F-134**. Zero loss proven by reverse application onto the v2.24 pin. |
| `Fault_Action_Register` (pre-post-close) | v2.24 | `c54a7369aa3cbc686111d0257a81b919` | superseded; retained *(de-labelled at S189)*. **v2.24: F-130 + F-131 appended at the S188 close**, after v2.23 appended F-127…F-129 during the build — five findings, all the session they were raised, **fourth consecutive close with no owed append** (§7 index F-126 → **F-131**; full text in the new §7.1 S188 section). Next free **F-132**. Both bumps proven zero-loss by reverse application onto the previous pin. |
| `Fault_Action_Register` (pre-close) | v2.23 | `8630142ffa5198058cd7ea2fb398c1f5` | superseded by v2.24; carries F-127…F-129, appended during the S188 build (also in kit `S188_KB`). |
| `Fault_Action_Register` (pre-S188) | v2.22 | `cfd8f958cd37fbee502dd46726e8256d` | superseded; retained *(de-labelled at S189)*. **v2.22: F-122 … F-126 appended the same session they were raised** — second consecutive clean close (§7 index F-121 → **F-126**; full text in the new §7.1 S187 section; the stale "*Next free finding: F-115*" line — unadvanced at v2.20/v2.21 — corrected visibly). Next free **F-127**. Only 3 lines changed, 130 added. |
| `Fault_Action_Register` (pre-S187) | v2.21 | `58edbf2364a2959b9957707fbe072100` | superseded by v2.22. **v2.21: F-115 … F-121 appended the same day they were raised** (§7 index F-114 → F-121; full text in the new §7.1 S186 POST-CLOSE section; H1 corrected — the v2.20 file still carried a `v2.19` heading, F-45/F-108 family, recorded not silently fixed). Next free **F-122**. Only **2 lines changed, 162 added**. **S186: F-109 … F-114 appended THE SAME SESSION they were raised — no owed append for the first time since S181.** §7 index extended F-108 → **F-114**; a new §7.1 continued section carries the full text; changelog row added; everything above the changelog **proven byte-identical** to v2.19. Next free **F-115**. |
| `Fault_Action_Register` (pre-S186) | v2.19 | `77f90db55186a755bb7f2cd42f385d94` | superseded (was mislabelled CURRENT here until the S187 close). **S185: the FOUR owed appends applied in one pass** — F-90…F-95 (S181, *never applied at all*), F-100…F-104 (S183), F-105…F-106 (S184), F-107…F-108 (S185). **§7 index extended from F-89 to F-108** (nineteen rows); three new §7.1 continued sections carry full text; v2.18's missing changelog row reconstructed. Next free **F-109**. One version bump, not four — the file has one final state. |
| `Fault_Action_Register` (pre-S185) | v2.18 | `ff0f020a3b645cbfa65400a51448cf0f` | superseded by v2.19. **S182: F-96–F-99 appended to §7.1**, pure append — everything above the new block byte-identical to v2.17. ⚠ this version bumped the file and left **no changelog row**, and added no §7 index rows — half of **F-108**. |
| `Fault_Action_Register` (pre-S182) | v2.17 | `7bcde8c98d62e6570f9995b7bbbd5166` | findings register (F-##). **BUILT at S181**: the three owed appends APPLIED (F-82+F-83 · F-84 · F-85–F-89); NEW §7.1 carries their full text; zero-loss proven mechanically against the v2.16 pin; source-of-truth line corrected; seven changelog rows reconstructed from evidence (v2.9→v2.7 relabel on two independent Archive proofs). §0–§6 lanes unchanged. The three append artefacts are provenance only. |
| `GAS_Outcome_Vocabularies_v1_S171` | v1 | `71140b7b2259d8e6e04f04691b777fff` | verbatim K/FU/IN/L outcome sets + K_CODE_MAP + Hindi coaching map; seeds `console_options` + `HI_OUTCOME`; code wins over doc summaries (D172) |
| `Portal_WhatsApp_Casepack_Dossier_v1_S172` | v1 | `3d97ec8040c81fb4812d04f209ca46b2` | **SOLE reference** for the in-portal Surgical Case Pack (D309), the shared canonical WhatsApp sender (D310), and the follow-up batch (D311) + UI-served-from-disk (D312). All live-file md5s/paths/config + the F-82 vendor outage + go-live steps. Opened on demand. |

| `D297_Call_Console_Contract_v4_FINAL` | S166 | `42991579f3c20cbd4f512131e58c22f9` | **signed, build-ready** Call-Intelligence Console contract + Appendix A verified ground truth. Tier 1 — opened at the D297 build. |
| `D297_Console_Portal_Build_Dossier` | v1 (S168) | `7429a696f4f1f7186c12d66a4a39ac75` | **self-contained build reference** for the console/portal work: console.db schema · staff-attribution mechanism + roster · dedup/query rules (F-74) · display contract · install state · staged roadmap. Opened alongside the contract at any console build. |
| `Console_Rev5_Punchlist` | v1 (S169) | `e8f707d7be1fb20b20e360ba9453df9a` | the autonomous console build plan (D302) — ordered items each with source·file·function·change·gate·install·acceptance. |
| `Clinic_Estate_Master_Inventory` | v1.1 (S177; lineage v1.7 S157) | `a8450fd44a0d69cc5dd97da8f7b1f6eb` | reconciled cross-project app+service estate (D260); S177: Asset-Register row → v1.11.0 + NEW `/root/shared/` shared-libs row. *(Forward: a clinic-finance row is owed when the estate is next reconciled.)* |
| `KB_Asset_Register` | **v1.11.0-R** (S181 reconstruction) | `631a2ba7ff907b98aadee89ac97d0412` | **the D316 rebuild of the LOST v1.11.0** (lost pin `1c147beb…` kept for provenance; this is NOT those bytes — the -R suffix says so in the version string). Built from the hash-verified v1.10.3 + Archive §S177 (the recipe §S178 records); adversarially verified. Opened on demand at any asset-app work. Next free A-D25. |
| `Clinic_Portal_SSO_Architecture` | v1 (S157) | `0c843bb64d579205d8c64946721c10f6` | SSO broker + shared verify-shim (D261) |
| `Clinic_Portal_Build_Plan` | v1 (S157) | `3d6468cb4927d5d77d7a7d687ffabfe7` | tile rosters + per-app selection (D262) |
| `Salary_Attendance_Master_Dossier` | v1 (S164) | `669917fcaca3fece3a3f6caa1899edbf` | **SOLE reference** for the salary + attendance + staff-daily-register machine. Supersedes `Attendance_System_Dossier_v1.2` (Tier-2 frozen row retained as integrity anchor), `Salary_System_KB_v1`, `Staff_Daily_Register_Dossier_v1.1` — all retained historical. |
| `END_OF_SESSION_PROMPT` | **v5** | `d2b6a22d0c195da311f8b6285f2cb375` | **CURRENT** close-out routine. **v5 adds step A8 (F-134): regenerate the live-pin list AFTER the manifest** — it is derived from the Register, and the generator refuses unless the Register hashes to the manifest's CURRENT row (F-110). *A close that rebuilds the manifest and not the pin list is not finished.* Everything else is v4 unchanged. |
| `END_OF_SESSION_PROMPT` (pre-S188) | v4 | `9fa2be50c527865982f195d347ab0283` | superseded by v5; its §A ended at A7, which is F-134. |


## Tier 1 — HISTORICAL / superseded (retained · **still hash-verified at Phase 0** · never read in the loop)

*Kept for lineage + integrity anchoring, not as current references. Their content is superseded; do not open them for current work — use the doc named in the "superseded by" note.*

| Doc | Version | md5 | Superseded by / status |
|---|---|---|---|
| `Salary_System_KB` | v1 (S157) | `71bb915dff0dac26fe20192b91cd3940` | → `Salary_Attendance_Master_Dossier` (S164) |
| `Staff_Daily_Register_Dossier` | v1.1 (S161) | `7969deadcbf062fccae302e1f8ae07f0` | → `Salary_Attendance_Master_Dossier` (S164); §5 also superseded by the C-model (D279/D280) |
| `INCIDENT_2026-07-14_…_F44` | — (closed) | `774898e80fac3e006d80e8c2f77488e6` | closed incident; consult on demand only |
| `KB_Asset_Register_v1_10_3` | v1.10.3 (S176) | `07d01e80a1d6a49884650d2e542205df` | → v1.11.0 (LOST, D316) → **v1.11.0-R (S181 reconstruction)** |
| `KB_Register` (pre-compaction) | v4.6 (S177) | `0503f255da0ab9a98dc6f092ddff2ef6` | → `KB_Register` v5.0 (compacted S178) → v5.1 (S179) |
| `KB_Register` (compaction base) | v5.0 (S178) | `ee12a63d4b87b1359f2d0954945457b2` | → `KB_Register` v5.1 (S179, additive finance fold) |
| `KB_History_Archive` (pre-S179) | v1.26 (S178) | `30dc00b300a491105577b8c58b2c47e0` | → `KB_History_Archive` v1.27 (S179, §S179 pure-append) |
| `KB_Register` (pre-S180) | v5.1 (S179) | `1c86b83acefcf9bce8c00f1b39bcb111` | → `KB_Register` v5.2 (S180, additive) |
| `KB_History_Archive` (pre-S180) | v1.27 (S179) | `adb85c35cabfc4a826738e491554ec27` | → `KB_History_Archive` v1.28 (S180, §S180 pure-append) |
| `START_HERE_SESSION_180` | S179 | `b2f89f18af10f110cc26e11d7ab03b7b` | → `START_HERE_SESSION_181` (S180) |
| `START_HERE_SESSION_181` | S180 | `d4de1df35c72f364e77b395534c4ac3e` | → `START_HERE_SESSION_182` (S181) |
| `KB_Register` (pre-S181) | v5.2 (S180) | `fb6c3e40221250d1c6c5848bb8f7c231` | → `KB_Register` v5.3 (S181, additive) |
| `KB_History_Archive` (pre-S181) | v1.28 (S180) | `0e8b4bd6b4e09fd2dcb6ce7fbf2c14ad` | → `KB_History_Archive` v1.29 (S181, §S181 pure-append) |
| `HANDOFF_RUNBOOK` | v114 (S180) | `aab96fc8c83d11ad8ab6ec4c8d750408` | → `HANDOFF_RUNBOOK` v115 (S181) |
| `Fault_Action_Register` (pre-append) | v2.16 (S171/recovered S180) | `1702b5a8e0663847eaa097919aea94d3` | → **v2.17 (S181, appends applied)** |
| `HANDOFF_RUNBOOK` | v113 (S179) | `f743a639d8750122ec3be17be752094a` | → `HANDOFF_RUNBOOK` v114 (S180) |
| `KB_Register` (pre-S182) | v5.3 (S181) | `df00d5c253c1f1cd6b2c0387d6b7dbe6` | → `KB_Register` v5.4 (S182, additive) |
| `KB_History_Archive` (pre-S182) | v1.29 (S181) | `8ef9bc8bdce233c03de60bdb75969dfd` | → `KB_History_Archive` v1.30 (S182, §S182 pure-append) |
| `HANDOFF_RUNBOOK` | v115 (S181) | `61b2216107f38798287c258013475904` | → `HANDOFF_RUNBOOK` v116 (S182) |
| `START_HERE_SESSION_182` | S181 | `3fad5ed45c0a98cb63a9cf0a070e0396` | → `START_HERE_SESSION_183` (S182) |
| `Fault_Action_Register` | v2.20 (S186) | `d7e553a9ba1e98f57e160879708bf977` | → v2.21 (S186 post-close). **LISTED AT THE S188 CLOSE** — it had sat in `KB_canon_all` with no manifest row since S186. |
| `KB_History_Archive` | v1.34 (S186) | `e47a7069ce7d555487c325dbebf017cc` | → v1.35 (S186 post-close). **LISTED AT THE S188 CLOSE** — same gap. |
| `KB_Register` | v5.11 (S186) | `d0da61a095435b1a3ef559c210788c37` | → v5.12 (S186 post-close). **LISTED AT THE S188 CLOSE** — same gap, and the version whose *phantom* hash was F-116; this row carries the file's REAL md5, transcribed from the file. |

## Tier 2 — frozen products (hash-verified only · never in the loop · waiver to change)

Each frozen product has one canonical **dossier**; this is the FROZEN ledger. **Four** products.

| Product | Dossier | Dossier md5 | Artefact (the live thing) | Artefact md5 | Frozen | Waiver |
|---|---|---|---|---|---|---|
| WABA templates | `WABA_Approved_Templates_v1_S137.md` **(adopted)** | `63dd1883ed6677bc96620c087fc1d154` | MyOperator panel — 14 approved | compute at freeze | S147 / D247 | Meta re-approval + bump |
| Attendance system | `Attendance_System_Dossier_v1_2_S153.md` **✓ built** | `bf19179181c553777e4cc8e3834bc754` | `attendance/` folder + VPS deploy + `att_month_report.py` (**v2.5 `e64cad19…` INSTALLED + July-verified**); Staff Ledger app `staff_ledger.py` **v2.4** — *md5 deliberately NOT restated here (**F-136**, fixed at S189); the KB Register's live-file table owns it and pins `/root/staff_ledger.py`, verified on the box at S189* (separate live system, Register-tracked) | 10-file frozen-core digest `dc12f4a0…` byte-unchanged; **full-folder re-pin `c4c9c83f44fbbbb39609047671e77d60`** (11 files) | S151 / D251 | frozen core: explicit waiver + bump; additive report layer sanctioned |
| Nutrition/Diet (`clinic_writer`) | `Nutrition_Diet_clinic_writer_Dossier_v1_1_S150.md` **✓ built** | `6900ff40d43da0013f6ea81c3c31a0e4` | `clinic_writer/` folder + PC `D:\clinic_writer\` | `fcedae30…` (`vitals_page.html` v28; folder digest `1b4f0f2299cd6c9e72b6d04f45847556`) | S147 / D247; **waiver exercised S150 / D248** | explicit waiver + bump |
| Callback Tracker **core** | `Callback_Tracker_Core_Dossier_v1_S147.md` **✓ built** *(scope pending confirm)* | `7e445ff04f086af0fdce656b1eae5dc1` | live Apps Script project (`WebApp.gs` D34 + core `.gs`) + Sheet `1USj…klo0` | `e4fd4512522c2e2723cb50690b92c5e8` (live project digest) | S147 / D247 | explicit waiver (D34) + bump |

**Deferred — NOT frozen (future Tier 2 candidate):**
- **Consent HTML** — folded into the still-in-development Surgical Estimate tool; dossiered + frozen only when that tool ships to the repo.

*Note: the Callback Tracker **Console/Dashboard** is NOT frozen — it stays active under Tier 1. Only the tracker **core** freezes.*

---

## Companion

- `SYSTEM_DOC_COVERAGE_MAP_S147.md` (md5 `50085e7564cb83476a6f587782143048`) — every subsystem → its authoritative doc. Read on demand. *(The clinic-finance subsystem's authoritative doc is `S179_Finance_LIVE_State`; add its row when the coverage map is next rebuilt.)*
- `README_CANONICAL_SET.md` (repo `canonical-docs/`) — a repo-navigation doc that carries no version numbers and defers to this manifest; not a Phase-0-verified canonical row.

---

## Governance

- **D247** (the tiering + Register/Archive split + this manifest) lives in the KB Register's decisions index.
- **Provenance rule:** every md5 here is computed from the live artefact; none is assumed (D172/D188). "compute at freeze" = a real hash still owed, not a placeholder to skip.
- **Install:** project-knowledge swaps + one GitHub push travel together per EOS.

---

*(**S179 consolidation note — flagged for owner review, reversible.** The manifest's pre-S178 per-session changelog blocks (§S149–§S177) were consolidated OUT this EOS: each is duplicated verbatim in **KB History Archive §S…** and its per-version md5 lineage is in the **KB Register version-lineage table**, so keeping a third copy here only re-grew the linchpin. Only the current-state tables above (the sole Phase-0-verified rows) plus the S178 and §S179 blocks are kept. **This is a size reduction of the manifest, not a loss of provenance** — every dropped hash still lives in the Archive/Register. If you'd rather the manifest carry the full changelog history again, say so and I'll restore §S149–§S177 verbatim at the next EOS. This mirrors the S178 Register compaction philosophy applied to the manifest.)*

### S178 documentation close (14 Aug 2026, EOS-light — NO live code · NO new decision/finding)
Owner directive: *"organize the KB docs thoroughly · cut bloat · compact without any loss of context."* Phase 0 green.
- **KB Register compacted v4.6 → v5.0** (`ee12a63d4b87b1359f2d0954945457b2`; 752 → 500 lines). Cut the three duplicated history forms (verbatim in the untouched Archive); kept current-state + indexes; folded D283–D312 into the index; added a consolidated live-file table + a truncation-proof END-marker. Zero-loss proven mechanically.
- **KB Asset Register refreshed v1.10.3 → v1.11.0** (`1c147beb44ad4413d3b147ad70e43ea7`) — A-D24 wave.
- **De-clutter:** `Salary_System_KB`, `Staff_Daily_Register_Dossier`, the closed F-44 incident, and the two pre-refresh docs → new **Tier 1 — HISTORICAL** subsection.
- **Session-loop close:** Archive §S178 → **v1.26** (`30dc00b300a491105577b8c58b2c47e0`); Runbook v111 → **v112** (`a6c4f218db8d9fc4e324eb1124eae3f5`); `START_HERE_SESSION_179` (`00d100191922aff5e69c25a170d9e390`). **Next free: D313 · F-84 · A-D25 · Session 179.**

**END OF CANONICAL_MANIFEST — S178.**

---

### §S179 EOS (15 Aug 2026, FULL — the Sanjeevni (medical) daily-revenue system LIVE on the VPS off Google Forms; D313; F-84 (three self-found security faults) fixed)
**S179 canonical filenames (Phase-0 mapping):** `KB_Register_v5_1_S179.md` · `KB_History_Archive_v1_27_S179.md` · `HANDOFF_RUNBOOK_2026-08-15_Session179close_v113.md` · `START_HERE_SESSION_180.md` · `S179_Finance_LIVE_State.md` (NEW Tier-1) · `Fault_Register_append_F84_S179.md` (append artefact, not a canonical row) · this `CANONICAL_MANIFEST.md`. (All other Tier-1/Tier-2 rows UNCHANGED — re-hashed clean.)
- **Tier-0 bumps (md5s pinned this EOS):** `KB_Register` v5.0 → **v5.1** (`1c86b83acefcf9bce8c00f1b39bcb111`; additive finance fold — live-file block + D313 + F-84); `HANDOFF_RUNBOOK` v112 → **v113** (`f743a639d8750122ec3be17be752094a`); `START_HERE_SESSION_179` → **`START_HERE_SESSION_180`** (`b2f89f18af10f110cc26e11d7ab03b7b`).
- **Tier-1 bumps:** `KB_History_Archive` v1.26 → **v1.27** (`adb85c35cabfc4a826738e491554ec27`; §S179 **pure-append**, prefix byte-identical to the v1.26 pin `30dc00b3…`, +13,540 chars, END-marker present); **NEW Tier-1 doc** `S179_Finance_LIVE_State` (`54cb25a88adc5692360341113a87a43e`) — the clinic-finance sole live-state reference. `Fault_Action_Register` stays **v2.16 pinned** (`1702b5a8…`) with the F-82+F-83 append (`3393d527…`) **and** the new F-84 append (`Fault_Register_append_F84_S179.md`, md5 `cce4009f373971fdadf8ed1f9b031d03`) owed → v2.17 on owner apply. All other Tier-1/Tier-2 rows UNCHANGED (re-hash clean); two pre-S179 doc versions added to the HISTORICAL subsection.
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps the DB + patient CSVs out):** **NEW subsystem** `clinic-finance` at `/root/finance/` (system `python3`, port 8106, `/finance` on the portal origin — F-68): `finance_app.py 61e36d5522e4e99e1e65e159ef50c85e` (smoke 176/176) · `finance_ingest.py 872ec33ef7c628cd474224b0c6c78ba5` (30/30) · `finance_import_medical.py 7cfde93ef…` (12/12) · `finance_upi.py 3f5016f0c64f12b91ab55c18252705c1` (14/14) · `finance_schema.sql bef0d8100…` · `finance_ui/finance_entry.html 8ec6ad49…` · `finance_ui/finance_review.html ddd3d5f6…` · `finance_backup.sh efe6f1b5…` · `clinic-finance.service 59c03bfa…` · clinic-Gmail GAS `VPS_Push_UPI.gs 955b291c…`. PHI/data gitignored (`finance.db*`, `scans/`, `exports/`, `medical_*.csv`). All other clinic live files UNCHANGED from S177/S178.
- **D313 minted** (clinic-finance subsystem architecture — medical live; clinic + lab a replication). **F-84 minted + FIXED** (three self-found security faults — ungated reads · spoofable header identity · unchecked epoch; "the offline-testing shortcut was the vulnerability"). **No incident** (all three found on self-review, fixed before close; installer auto-rolls-back on `sso_epoch_ok:false`). Git kit `gitkit_S179.zip` prepared (`finance/` + `gas/` + `.gitignore.additions` + commit message) — **owner action: `.gitignore` the PHI paths in the SAME commit before `git add` (F-31/F-49).**
- ⭐ **Next-session top task: CLINIC + LAB finance modules (a replication of medical).** Next free: **D314 · F-85 · A-D25 · Session 180.** This was Session 179.

**END OF CANONICAL_MANIFEST — S179.**

---

### §S180 EOS (15 Aug 2026, FULL — the Marg pharmacy feed built offline end-to-end; sale returns made to reach the books; four live installs; D314–D315; F-85–F-88)
**S180 canonical filenames (Phase-0 mapping):** `KB_Register_v5_2_S180.md` · `KB_History_Archive_v1_28_S180.md` · `HANDOFF_RUNBOOK_2026-08-15_Session180close_v114.md` · `START_HERE_SESSION_181.md` · `Fault_Register_append_F85_F89_S180.md` (append artefact, not a canonical row) · this `CANONICAL_MANIFEST.md`. (All other Tier-1/Tier-2 rows UNCHANGED — the 33 reachable ones re-hashed clean. Of the seven unreachable: four recovered and back in the set, three closed as LOST — see the resolution section above.)
- **Tier-0 bumps (md5s pinned this EOS):** `KB_Register` v5.1 → **v5.2** (`fb6c3e40221250d1c6c5848bb8f7c231`; additive — six finance live-file entries changed/added, D314–D315, F-85–F-88, v5.2 lineage row); `HANDOFF_RUNBOOK` v113 → **v114** (`aab96fc8c83d11ad8ab6ec4c8d750408`; gains a §1 mental-models section); `START_HERE_SESSION_180` → **`START_HERE_SESSION_181`** (`d4de1df35c72f364e77b395534c4ac3e`).
- **Tier-1 bumps:** `KB_History_Archive` v1.27 → **v1.28** (`0e8b4bd6b4e09fd2dcb6ce7fbf2c14ad`; §S180 **pure-append**, prefix byte-identical to the v1.27 pin `adb85c35…`, +25,910 chars, END-marker present). `Fault_Action_Register` **v2.16 RECOVERED** (hash verified from the S171 cold kit), with THREE appends owed → v2.17.
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps patient DATA out):** `finance_ingest.py` `872ec33e…` → **`2cd0f264fb1a091f3e3ec7c3f4a17438`** (smoke 50/50) · `finance_app.py` `61e36d55…` → **`7b62b7ae661914505c864d71cc6c9abc`** (smoke 179/179) · **NEW** `marg_report.py` `28b47d447cfd966411742055717a5c56` · **NEW** `finance_returns.py` `a46a87e65d951d59baeb9d86c9d8fe59` · **NEW** `finance_returns.sql` `9cec4e317590f845beda87881721cf69` · **NEW** `finance_identity.py` `81092e3ca18c9a85f1de06cc8055d967`. Database: `v_day_attribution` redefined; `sale_line_item` + 4 indexes + 3 settings added; both non-destructive. VPS python gained `xlrd 2.0.2`.
- **D314–D316 minted. F-85–F-89 raised**, two about the session's own process. **No incident** — every failure was caught by an install gate or by self-review before reaching live use. **Git kits COMMITTED at this close**, clearing the two-session lag. **The seven unreachable rows were resolved: four recovered by hash-search, three closed as LOST under D316 (F-89 — the cold-kit cadence had lapsed nine sessions).** Cold-backup discipline restarted: `KB_S180_close.zip`; **next kit due within 3–5 sessions, and the count is checked at every close.**
- ⭐ **Next-session top task: owner's choice — the CLINIC + LAB finance modules (the carried S180 star), or finishing the Marg chain (U5·U7·U8·U9·U12).** Next free: **D317 · F-90 · A-D25 · Session 181.** This was Session 180.

**END OF CANONICAL_MANIFEST — S180.**

---

### §S181 EOS (16 Aug 2026, FULL — the CLINIC finance module LIVE via the NEW D317 deploy chain; housekeeping cleared; D317–D319; F-90–F-95)
**S181 canonical filenames (Phase-0 mapping):** `KB_Register_v5_3_S181.md` · `KB_History_Archive_v1_29_S181.md` · `HANDOFF_RUNBOOK_2026-08-16_Session181close_v115.md` · `START_HERE_SESSION_182.md` · `Fault_Action_Register_v2_17.md` (**promoted CURRENT**) · `KB_Asset_Register_v1_11_0_R_S181.md` (**promoted CURRENT**, D316 reconstruction) · this `CANONICAL_MANIFEST.md`. All other rows unchanged, re-hash owed at the S182 Phase 0 as usual.
- **Tier-0 bumps:** Register v5.2 → **v5.3** · Runbook v114 → **v115** · START_HERE 181 → **182**. **Tier-1:** Archive v1.28 → **v1.29** (§S181 pure append; content before the v1.28 END marker byte-identical to `0e8b4bd6…`, +15,747 chars) · Fault Register **v2.17** CURRENT (`7bcde8c9…`) · Asset Register **v1.11.0-R** CURRENT (`631a2ba7…`).
- **Live VPS (Register-pinned):** `finance_app.py` → `86382f62907b65cf17fded2ee914328e` (clinic unit + owner redesign; live smoke **316/316**) · NEW `finance_ui/finance_entry_clinic.html` `0c64fda2…` · migrations `S182_clinic` + `S182_c2` applied · new tables `clinic_verification` / `clinic_line_side` / `tracker_day` · clinic roles seeded real (makers shavez/alisha/shivani; checkers manoj/bhawna; `clinic.final_checker`=manoj). Kits S182_C1a…C2a in the repo's `deploy_kits/` (anticipatory labels — F-85 note); GAS `VPS_Push_TrackerDay.gs` + PC-side `docterz_report.py` delivered, wiring pending.
- **D317–D319 minted · F-90–F-95 raised** (F-90 repo PUBLIC — owner ruling owed). **No incident** — three installer reds were caught by gates with nothing half-installed; one red was the bank arbiter working. **KB swap executed per D319 for the first time**: the assistant wrote this canonical set into project knowledge directly; owner actions at this close = one KB-kit double-click + one cold-kit download. ⚠ the S181 FULL cold kit is **PHI-bearing** (six unmasked numbers pre-existing in the canonical set) — keep private; owner ruling owed.
- ⭐ **S182 top task: portal tiles · GAS tracker-feed wiring · first parallel-run checks.** Cold-kit count **1 of 3–5** (F-89). Next free: **D320 · F-96 · A-D25 · Session 182.** This was Session 181.

**END OF CANONICAL_MANIFEST — S181.**

---

### §S182 EOS (16 Aug 2026, FULL — Phase 0 proved against git bytes; the clinic PORTAL TILES live; a fail-open identity default closed; D320; F-96–F-99)
**S182 canonical filenames (Phase-0 mapping):** `KB_Register_v5_4_S182.md` · `KB_History_Archive_v1_30_S182.md` · `HANDOFF_RUNBOOK_2026-08-16_Session182close_v116.md` · `START_HERE_SESSION_183.md` · `Fault_Action_Register_v2_18.md` · this `CANONICAL_MANIFEST.md`. All other rows unchanged.
- **Tier-0 bumps:** Register v5.3 → **v5.4** (`9506a0fe…`) · Runbook v115 → **v116** (`5b871ab7…`) · START_HERE 182 → **183** (`076e301b…`). **Tier-1:** Archive v1.29 → **v1.30** (`7a673ac6…`; §S182 pure append, prefix byte-identical, +18,638 chars) · Fault Register v2.17 → **v2.18** (`ff0f020a…`; F-96–F-99 appended to §7.1, prefix byte-identical).
- **Phase 0 was verified independently this session:** the repo was cloned anonymously and the **45 manifest pins hashed against the git bytes**, separately from the kit's own `MD5SUMS_ALL.txt` (48 = 45 rows + 3 append artefacts). Both passed. The rule adopted: **a hash verdict is only pronounced on bytes delivered as a FILE**; re-keyed inline text may corroborate, never convict — a re-keyed Phase 0 had produced a false red on `KB_Register` v4.6 earlier the same day (104 bytes of transcription drift, proven not assumed).
- **Live VPS (Register-pinned, NOT manifest rows):** `/root/portal/portal.py` `da417709…` → `410388da…` (S182_P1a, clinic tiles, gate 42/42) → **`2784b1cb76abfb9dbe2407c38da5bd83`** (S182_P2a, F-98 fixed, gate 48/48). **NEW** `/root/finance/marg_backfill.py` `e101c595619dc39a19397abb040d64c9` (placed, dry-run by default). Kits `S182_P1a` · `S182_P2a` · `S182_M1a` in `deploy_kits/`.
- **D320 minted** (the repo stays PUBLIC, owner ruling — with the binding corollary that no PHI-bearing artefact enters it). **F-96–F-99 raised**, F-98 fixed the same session. **No incident** — every failure was caught by a gate, by an offline rehearsal, or by reading the code before writing it. ⚠ **F-97 is the one to carry:** Phase 0 verifies documents; **nothing verifies the Register's live-code pins**, and one was stale by two sessions. Mitigated per-kit by a new **live-file currency gate**; the structural fix is owed.
- ⭐ **S183 top task: the Marg April→August backfill** (v2 driver writing `sale_item` AND `sale_line_item`; the `marg_export` column map + activation; the fortnight chunks). Reachable and zero-risk: filed days run 1 Apr → 13 Aug and both target tables are empty. Cold-kit count **2 of 3–5**. Next free: **D321 · F-100 · A-D25 · Session 183.** This was Session 182.

**END OF CANONICAL_MANIFEST — S182.**

---

### §S183 EOS (16 Aug 2026, FULL — the F-97 fix shipped; the Marg feed went live + backfilled 5 months; the Sanjeevni cash chain reconciled from bank records and found whole)
**S183 canonical filenames (Phase-0 mapping):** `KB_Register_v5_5_S183.md` (`3cad79e6…`) · `HANDOFF_RUNBOOK_2026-08-16_Session183close_v117.md` (`cc523169…`) · `START_HERE_SESSION_184.md` (`18c2bf46…`) · this `CANONICAL_MANIFEST.md`. **Two NEW Tier-1 finance docs** in project knowledge: `S183_Sanjeevni_Daily_Cash_Design_and_Marg_Findings.md` (`de4f88b3a48e71c19e708f6a1d274f41`) · `S183_Sanjeevni_Cash_Reconciliation_YesBank.md` (`ca49c4113b3cbd658fd2986b1aa7bb89`). (Also created this session: `S183_Marg_backfill` analysis is folded into the design doc.)
- **Tier-0 bumps:** Register v5.4 → **v5.5** · Runbook v116 → **v117** · START_HERE 183 → **184**.
- **Tier-1 this close:** `KB_History_Archive` STAYS **v1.30** and `Fault_Action_Register` STAYS **v2.18** — the formal **§S183 Archive append + F-100–F-104 Fault-Register append are OWED as S184 opening housekeeping** (precedent: S181 applied owed appends). The S183 narrative and findings are captured verbatim in Register v5.5, Runbook §0, and the two S183 finance docs, so nothing is lost; only the formal into-Archive fold is deferred. All other Tier-1/Tier-2 rows UNCHANGED (re-hash owed at S184 Phase 0 as usual).
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `marg_report.py` `28b47d44…` → **`829f4344df6e086510bb0fb6112ecb77`** (reads `.xlsx` too; `.xls` path byte-identical) · `marg_backfill.py` `e101c595…` → **`fa33ec8a6dfa0ee0b6af5613160f3394`** (v2, ran to completion) · **NEW** migration `S183_marg_map` `9340675c9105f9d5e78cc37980494999` (applied) · **NEW** `/root/deploy/verify_live_pins.py` `ce36dbf10e7d5bbd5310507add41f3cb` + `gen_live_pins.py` + generated `live_pins.txt`. The 9 corrected call-hook/verdict pins are in the Register live-file table. finance.db gained 15,574 `sale_line_item` + 982 `sale_item` rows via the backfill; `day_line` (the money) untouched.
- **D321 minted. F-100–F-104 raised.** No incident — every failure was caught by a gate or by read-only analysis. **The Sanjeevni cash reconciliation was read-only; no live finance write was made** (the 16 Yes Bank deposit bookings + opening anchor + Yes Bank reconciliation are the S184 ⭐ top task, gated). Cold kit `KB_S183_close` taken (count **3 of 3–5**, F-89 met).
- ⭐ **S184 top task: book the Sanjeevni cash correction (16 Yes Bank deposits + ₹40k drawer advances + opening anchor + Yes Bank reconciliation), then WALK-IN reclass (F-104), then the daily Marg live flow.** Next free: **D322 · F-105 · A-D25 · Session 184.** This was Session 183.

**END OF CANONICAL_MANIFEST — S183.**

---

### §S184 EOS (17 Aug 2026, FULL — the Sanjeevni cash books CORRECTED LIVE, exceptions regenerated, the D322 holiday classifier shipped, the reserve/daily-flow model designed; D322; F-105, F-106)
**⚠ Recorded retrospectively at the S185 close.** S184 shipped live code and live data and folded **no** canon — no Archive append, no Fault-Register append, no Register bump, no manifest rebuild. Its two Tier-0 outputs went to project knowledge only, which is **F-107**. Both were filed to the repo and pinned at the S185 close: `HANDOFF_RUNBOOK_2026-08-17_Session184close_v118.md` (`2481324798c39c142a8286f1d1b8cd59`) · `START_HERE_SESSION_185.md` (`f65e76c2e270cabf522839ef25d4acbe`).
- **Live DATA (gated migrations, both INSTALLED; not manifest rows — F-31 keeps `finance.db` out of the repo):** **`S184_C1a`** — preceded by the read-only survey `S184_S1a`, **which is the only reason the correction did not double-count ₹16 lakh**: the record said the 16 deposits were unrecorded, the box said the sheet's 31 deposit movements were already there. 31 sheet deposits → **16 Yes Bank verified credits (₹16,45,600)**; 36 legacy adjustments removed (backup rows `s184_removed_*`); **₹40,000 Darpan advances** as drawer expenses (no `staff_id` → deliberately not posted to the Staff Ledger); ₹337 procedure-medicine as noncash. **Closing 13 Aug −30,056 → +27,654**, `day_line` byte-identical. Marker `migration.S184_cash_correction`; DB backup `finance.db.bak_S184C1_20260817_065446`. **`S184_C2a`** — the exception tables are written only by the one-shot importer, so C1a left them stale (books right, alarms still red): 36 breaks resolved, negative_cash recomputed from `v_cash_ledger` to the **29 real parking-window days** (4 Jun – 4 Aug), each labelled "cash parked with Dr Bhawna ahead of a bank trip". Marker `migration.S184_C2a_exceptions`. Dashboard: cash-in-hand **₹42,993**, unexplained adjustments **0**.
- **Live CODE (Register-pinned, NOT a manifest row):** `/root/finance/finance_app.py` `86382f62907b65cf17fded2ee914328e` → **`c66bec2b76…` (PARTIAL — see below)**, kit `S184_F1b`, the **D322** missing-day classifier; new `clinic_holidays()` helper reads the attendance DB read-only and fail-soft; **314/314** on the corrected store. **F1a first went RED (F-106)** because its `--selftest` asserted the pre-S184 store state — the session's own correct migrations read as failures and the gate restored; F1b made those checks state-adaptive.
- ⚠ **THE PARTIAL PIN.** The S184 close recorded the new `finance_app.py` md5 only as `c66bec2b` / `c66bec2b76…`. **The full 32-character value was never written down anywhere, and it was NOT invented at the S185 fold-in** — "compute at freeze" means a real hash still owed, not a placeholder to skip (D172/D188, and F-107's own rule applied to itself). Complete it from the box at the S186 open via `verify_live_pins.py` (D321(d): the box wins).
- **D322 minted** (Sundays + attendance-sourced clinic holidays are optional days, not owed days; revises D313's "missing days must shout" by narrowing what counts as missing; fail-soft holiday source; F-99's zero-anchor blind spot unaffected). **F-105** (the Submit guard correctly blocked a catch-up the S183 record said needed nothing — *the record was wrong and the running guard was right*) and **F-106** raised. **No incident** — every failure caught by a gate.
- **Designed, NOT built:** the reserve / counter-person model (biometric-as-hint, four cash destinations, multi-day stretches reconciled by Marg + bank, counter-person registry seeded Vinay Saxena), the reconciliation workbench (Marg ⋈ bank ⋈ entry; cash→UPI suggestions graded like D315, never auto-applied), and the holiday + parking-window analyses. Seven S184 design docs remain in project knowledge.
- **The opening float is OPEN and instrumented:** booking the 29 negatives away is *mathematically impossible at float 0* (short ≈ ₹85k, matching the sheet's 8-Apr ₹99,017 injection), so "no negatives" and "drawer ≈ ₹43k" are mutually exclusive and only a physical count decides. `Sanjeevni_Cash_Reconciliation.xlsx` (4 tabs) fills to a verdict; both booking paths prepped.
- **Next free after S184: D323 · F-107 · A-D25 · Session 185.** This was Session 184.

**END OF CANONICAL_MANIFEST — S184.**

---

### §S185 EOS (17 Aug 2026, FULL — Phase 0 proved the canon intact; F-107 and F-108 raised from the record's own blind spots; THREE sessions of canonical debt cleared in one pass)
**S185 canonical filenames (Phase-0 mapping):** `KB_Register_v5_6_S185.md` (`bc481216…`) · `KB_History_Archive_v1_33_S185.md` (`6548a155…`) · `Fault_Action_Register_v2_19.md` (`77f90db5…`) · `HANDOFF_RUNBOOK_2026-08-17_Session185close_v119.md` (`a435d2dd…`) · `START_HERE_SESSION_186.md` (`4adc2c64…`) · plus the two S184 files filed under F-107 · this `CANONICAL_MANIFEST.md`.
- **Phase 0 (documents): GREEN.** Repo cloned anonymously, `md5sum -c MD5SUMS_ALL.txt` → **55 of 55 OK** (kit ID `536961e984832a38e008d9c26524b097`). The **F-88 cross-check** then ran separately, because a passing `md5sum -c` proves a kit internally consistent rather than current: all **77** manifest md5 tokens matched against real file hashes → **52 matched real bytes**; the **25** that did not are each legitimately non-document (live VPS code pins · Tier-2 artefact digests · the three D316 closed-as-lost rows · two superseded S178 versions). Nothing unaccounted for, nothing halted.
- **Phase 0 (live code): NOT run** — `verify_live_pins.py` executes on the VPS and the session had no reach to the box. The `finance_app.py` drift was therefore reconciled from the S184 install record rather than from a live reading, which is exactly why its pin is recorded **partial** rather than completed.
- **F-107 minted — Phase 0 is blind to a document that was never listed.** The two Tier-0 documents the S184 close produced went to project knowledge only, so **the two documents Phase 0 is required to read were the two it could not verify**; they were read on trust and nothing complained, *because nothing looks for a missing row*. Phase 0 asks of each listed row *do these bytes still match?*, never of each document in use *are you listed?* **F-97's documentary twin — both are absence-blindness**, and absence (not corruption) is what this project has actually lost documents to (F-89). Remediated: both filed, hashed as delivered, pinned. **Structural fix owed: the inverse check.**
- **F-108 minted — findings recorded in the KB Register were never applied to the Fault Register.** Its §7 index ended at F-89 and read *"Next free finding: F-90"* while **F-90…F-95 (S181) had never landed** and F-96…F-99 (S182) sat in §7.1 with no index rows; v2.18 had also bumped the file leaving no changelog row. Nothing was lost — the Register carried them — but the findings register was four sessions behind and said so nowhere. **The F-45 family recurring**, one version after v2.17 reconstructed six instances of it and named the pattern.
- **The fold-in, executed in one pass:** Archive **v1.30 → v1.33** (§S183 · §S184 · §S185, chronological, prefix proven byte-identical, +21,183 chars) · Fault Register **v2.18 → v2.19** (F-90…F-108; §7 index F-89 → F-108; next free **F-109**) · Register **v5.5 → v5.6** · this manifest rebuilt · `START_HERE_SESSION_186` promoted · pushed to GitHub · cold kit taken **after** the fold-in.
- **No decision minted. F-107, F-108 raised. No incident. No live code or live data changed.** **Next free: D323 · F-109 · A-D25 · Session 186.** Cold-kit count **1 of 3–5** (`KB_S185_close`). This was Session 185.

**END OF CANONICAL_MANIFEST — S185.**

---

### §S186 EOS (17 Aug 2026, FULL — the cash chain closed by count, a phantom deposit found in the live books, and six upgrades across five gated installs; D323, D324; F-109 … F-114)
**S186 POST-CLOSE canonical filenames (Phase-0 mapping) — every token below transcribed from the file it names, none abbreviated beyond 8 characters:** `KB_Register_v5_12_S186.md` (`1da5b0c4…`) · `KB_History_Archive_v1_35_S186.md` (`d2adece3…`) · `Fault_Action_Register_v2_21.md` (`58edbf23…`) · `HANDOFF_RUNBOOK_2026-08-17_Session186postclose_v121.md` (`cca9896a…`) · `START_HERE_SESSION_187.md` (`91996d84…`) · three S186 finance docs · this `CANONICAL_MANIFEST.md`.

> **F-116, recorded here because this is where it happened.** The line above previously read `KB_Register_v5_11_S186.md` (`d5ec45a5…`). **No file in this repository carries that hash** — an md5 index of all 936 files, taken as stored and with line endings normalised both ways, matches it nowhere, and the token appeared in exactly one place in the entire tree: this footer. The Register *row* above was correct throughout. A phantom in the linchpin's own self-description, direct descendant of **F-109**. **RULE: a hash is transcribed from a file or it is not written — and a document's footer is a claim about itself, checked like any other.**

> **Retired at the S186 post-close, moved to `deploy_kits/_attic_S186/` and NOT deleted:** `MD5SUMS.txt` and `SUMS.md5` (stale rival checksum files, **F-120** — `MD5SUMS_ALL.txt` is now the folder's single authority), `COMMIT_S185.txt` (superseded by `COMMIT_S186.txt`), and `_superseded_S182/` (3 documents, already labelled superseded and never listed in the checksums). Also attic'd from other kits: two `__pycache__` folders and a stray `live_pins.tsv`. **The canon folder now contains canon and nothing else.**
- **Tier-0 bumps:** Register v5.6 → **v5.11** (five bumps in one session, pins recorded as they moved) · Runbook v119 → **v120** · START_HERE 186 → **187**. **Tier-1:** Archive v1.33 → **v1.34** (§S186 pure append, prefix proven byte-identical, +12,250 chars) · Fault Register v2.19 → **v2.20** (F-109 … F-114, appended the same session; §7 index F-108 → F-114; next free **F-115**).
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `finance_app.py` `c66bec2b9e…` → `31642789bc…` → **`d04167a848e5d6f0baae19df014f70d4`** · `finance_ingest.py` `2cd0f264fb…` → **`1f730bcdf3c7044841cedc06833bc228`** (F-114) · **NEW** `finance_yesbank.py` **`5dcbdd3a41360c96310929083524fc93`** · **NEW** `finance_ui/finance_workbench.html` **`45cb85b353ba8675114ca23eaa6afa90`** · `verify_live_pins.py` `ce36dbf10e…` → **`ea3677b9fc6456b514a1ef623a9ced15`** (v1.1) · `gen_live_pins.py` v1.1 `bf300632259cce66a82b04e1c6091ce0` (PC-side). Migrations applied: `S186_cash_close`, `S186_reserve_yesbank`, `S186_walkin`.
- **Kits:** `S186_V1a` (pin chain) · `S186_C1a` (cash close) · `S186_R1a` (data layer) · `S186_R2a` (three surfaces) · `S186_I1a` (F-114 + portal Marg upload) · `S186_W1a` (F-104). **Two went red and both restored with nothing half-applied** — F1a-style state assertions and a migration that silently dropped 116 credit notes, the latter caught because the verify held the outcome to the projection printed sixty seconds earlier.
- **D323, D324 minted. F-109 … F-114 raised and ALL appended.** No incident. **Live numbers at close:** cash in hand **₹2,05,198** (→ ₹1,75,198 once Darpan's ₹30,000 is entered) · `negative_cash` **0** · review queue **0** · `line_sum_vs_day_total` **4** · 15 verified Yes Bank deposits (₹15,70,600).
- ⭐ **S187 top task: owner's choice — the item-wise go-live decision · the 12 June ₹8,487 · the F-107/F-108 structural checks.** Next free: **D325 · F-115 · A-D25 · Session 187.** This was Session 186.

**END OF CANONICAL_MANIFEST — S186.**

---

### §S187 EOS (18 Aug 2026, FULL — EIGHT kits live: the provable attestation chain, B5 reception push, Daily Flow v2 stage D1, every seat's tile, the branded Sanjeevni Hub; D325–D328; F-122 … F-126)
**S187 canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:** `KB_Register_v5_22_S187.md` (`116a0bdba426f33c0fda69652bba46fc`) · `KB_History_Archive_v1_36_S187.md` (`eb99a9b455764452f3ca86bc57cfd132`) · `Fault_Action_Register_v2_22.md` (`cfd8f958cd37fbee502dd46726e8256d`) · `HANDOFF_RUNBOOK_2026-08-18_Session187close_v122.md` (`5ab667f1ec9441b3659224b58d802654`) · `START_HERE_SESSION_188.md` (`b3bb94998a4c62b66980b0676c518de4`) · **NEW Tier-1:** `S187_Daily_Flow_v2_Target_Design.md` (`83e228d9c81a68d4c9c6dd6a1d15e0a0`) · `S187_Daily_Flow_v2_Design_Addendum_Returns_360.md` (`5f3d79871568f5838e9b2817c63af580`) · `Clinic_Design_Language_v1.md` (`a8b17290b7f487ee10cf5b02f2f31cca`) · **FILED under F-107:** `S186_F113_Backfill_Silent_Shortfall.md` (`0fc78c1fe326f16e1a907a47805e8267`) · `S186_Cash_Movement_Sheet_Analysis.md` (`9b717ab7df89fbd7a973aa4e132a3ac5`) · this `CANONICAL_MANIFEST.md`.
- **Tier-0 bumps:** Register v5.12 → **v5.22** (ten bumps across the session, pins recorded as they moved; the close bump adds D327/D328 + F-122…F-126 and corrects the stale "v5.11" end-marker) · Runbook v121 → **v122** · START_HERE 187 → **188**. **Tier-1:** Archive v1.35 → **v1.36** (§S187 pure append, prefix proven byte-identical, +20,816 chars) · Fault Register v2.21 → **v2.22** (F-122…F-126 same-session; second consecutive clean close; the stale next-free line corrected visibly).
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `finance_app.py` `d04167a8…` → **`db4373a5671dc90d384166a5771e098b`** (five builds: M1a `81c26653…` · D1a `cd3faaa4…` · P1b `fe92a74d…` · P2a `04088c31…` · H1a; live smoke **400/400**) · `finance_approvals.html` NEW → **`028255054662924713e03362c3976b05`** (D1a `3798f9f7…` → P1a `e37cb13b…` → P2a `8ec5ff70…` → H1a Hub `e7ae6208…` → H1c branded; H1b `29eb6326…` published, retired unlived) · `portal.py` `2784b1cb…` → **`bd4ed0a3b89659676e7e193998eeb1a9`** (P1a `34dbeef7…` → P2a; portal gate 22/22) · `finance_workbench.html` `18c71e63…` → **`420f82c2846bc49d0d12ab5040d8c542`** (M1a pushed-reports card) · `verify_live_pins.py` → **v1.2 `b4da75ec19f8c7fa613fb9962a272a1a`** · `gen_live_pins.py` → **v1.2 `9c402c366e7c902f27047a2014062107`** (PC-side). New table `marg_push_staging` (lazily created, DDL authoritative in code). New scoped secret `FINANCE_MARG_TOKEN` (systemd unit only; **rotated once after a chat exposure — a pasted token is burned**, D328). Medical PC: `SEND_TO_CLINIC.bat` + `SendToClinic.ico` + `MAKE_DESKTOP_ICON.bat` (kit `S187_M1a` folder). Repo root: **`PUBLISH_ALL.bat`** — the D328 default publisher, proven on its first field run.
- **Kits:** `S187_V1a` · `S187_M1a` · `S187_D1a` · `S187_P1a` (**RED at its own gate — F-125 — restored byte-perfect, no incident**) · `S187_P1b` · `S187_P2a` · `S187_H1a` (F-126 in its goodbye, after all real work) · `S187_H1b` (published, never installed) · `S187_H1c`.
- **D325–D328 minted. F-122 … F-126 raised and ALL appended.** **F-123 executed at this close:** `canonical-docs/` → `deploy_kits/_attic_S187/canonical-docs/` (**moved, not deleted**), its manifest renamed `CANONICAL_MANIFEST.md.RETIRED_S177_stale`, pointer `README_RETIRED.md` left at the old path; **exactly one `CANONICAL_MANIFEST.md` remains in the repo.** The five duplicate-CURRENT rows above de-labelled; START_HERE_187's self-contradiction and Runbook v121's "v120" footer corrected in their successors (all recorded in Archive §S187; none minted — existing families).
- **The pin list is regenerated from Register v5.22 against THIS manifest** (`gen_live_pins.py` v1.2) and ships beside the canon in `deploy_kits/KB_canon_S187close/` → after publish + VPS pull + one copy command, `verify_live_pins.py` should print **GREEN with a PROVED `source: VERIFIED`** — the first in the project's history (F-97 → D321 → F-110 → F-117 → F-122, the whole chain finally closed end to end).
- ⭐ **S188 top task: the build on the signed Daily Flow v2 + returns/360 contract** (D-R returns + the D327 `counter` role → D2 mirror → 360 wiring → orthotics purchase side → D5 feeds → D6), **gated by the §4a ₹70,000 Staff Ledger check before any D3 work**. Cold kit `KB_S187_close` taken (count **1 of 3–5**). Next free: **D329 · F-127 · A-D25 · Session 188.** This was Session 187.

**END OF CANONICAL_MANIFEST — S187 CLOSE.**

---

### §S188 EOS (18 Aug 2026, FULL — Daily Flow v2 stage D2 LIVE in two kits: Darpan's mirror, save-then-see enforced server-side, and a badge that reaches the checker unaided; NO decision minted; F-127 … F-131)
**S188 canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:** `KB_Register_v5_24_S188.md` (`9b713355330306fbe5f192e9a5b91771`) · `KB_History_Archive_v1_37_S188.md` (`7d95a233925fbe47e3c2417cdf5bbc0f`) · `Fault_Action_Register_v2_24.md` (`c54a7369aa3cbc686111d0257a81b919`) · `HANDOFF_RUNBOOK_2026-08-18_Session188close_v123.md` (`a09b351142074c26a9ca34e911d26c04`) · `START_HERE_SESSION_189.md` (`2bee97ac63e35c28597fadd7d88069e6`) · **build-time intermediates, now listed:** `KB_Register_v5_23_S188.md` (`64814f4fdcf6570d2cd195ad07e20f14`) · `Fault_Action_Register_v2_23.md` (`8630142ffa5198058cd7ea2fb398c1f5`) · this `CANONICAL_MANIFEST.md`.
- **Tier-0 bumps:** Register v5.22 → **v5.24** (v5.23 mid-session, recording the four live pins **as they moved**) · Runbook v122 → **v123** · START_HERE 188 → **189**. **Tier-1:** Archive v1.36 → **v1.37** (§S188 pure append; the **726,539 characters** before the v1.36 END marker proven byte-identical, +7,491) · Fault Register v2.22 → **v2.24** (v2.23 mid-session; F-127…F-131, next free **F-132**).
- **Zero loss proven by REVERSE APPLICATION, not asserted.** For each document bump: strip exactly the blocks S188 inserted, undo exactly the lines S188 edited, and require the result to equal the prior version byte-for-byte. Every reconstruction landed on the manifest's own pin — `cfd8f958…` (Fault v2.22), `116a0bdb…` (Register v5.22), `8630142f…` (v2.23), `64814f4f…` (v5.23). If anything else had moved, the hashes could not have matched.
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `finance_app.py` `db4373a5…` → `5a7fea4fe50f67a687bf27eeec97f411` (`S188_D2a`, live smoke **453/453**) → **`3a7086f851720dd161bc43c3c1fd45dd`** (`S188_D2b`, live smoke **464/464**) · `finance_ui/finance_entry.html` `8ec6ad49…` (untouched for nine sessions) → `a114ebc48565491cd2d145ed767bb923` (`S188_D2a`) → **`2c23b461bdae5a4ed6a4c4ed4708b4f9`** (`S188_D2b`). New lazily-created table `day_mirror_reveal` (DDL authoritative in code). New `data_flag` code `EDITED_AFTER_REVEAL`. Dev-only tool corrected: `dev/dev_seed_smoke_db.py` (**F-128**).
- **Kits:** `S188_D2a` · `S188_D2b` · `S188_KB` (docs only, nothing to install). **Both code kits were built on bytes recovered from the deploy kits by HASH, not by filename (D188)** — the repo's `finance/` working tree is **seven builds stale** and does not carry the live bytes at all (**F-97 part 2**, now named in the backlog with its evidence).
- **F-127 … F-131 raised and ALL appended.** No incident. **NO DECISION MINTED** — S188 is the execution of D326; next free stays **D329**. **Three projections written down before measurement, three landed to the number** (453/453 · 464/464 · and the S188_D2a delivery note's live figure).
- **`finance_approvals.html` VERIFIED ON THE BOX this session** at `028255054662924713e03362c3976b05` — the owner's saved copy of the Hub was the pre-H1c design, which turned out to be an older save rather than a live regression; the record was right. That nothing we own could have told the difference is **F-130**.
- **Closed at this close:** the three superseded intermediates that had sat in `KB_canon_all` with no manifest row since S186 are now listed in the HISTORICAL table — the F-107 shape in reverse.
- ⭐ **S189 top tasks: F-130's three-line design-fingerprint fix and F-131's 14 deletes (both cheap), then the rest of the signed contract — D-R returns + the D327 `counter` role → 360 wiring → orthotics purchase side → D5 feeds → D6.** The one item only a person can do: **walk Darpan through Save → the check → File, before 10am.** Cold-kit count **2 of 3–5**. Next free: **D329 · F-132 · A-D25 · Session 189.** This was Session 188.

**END OF CANONICAL_MANIFEST — S188 CLOSE.**

---

### §S188-POST EOS (18 Aug 2026 — the close was published, the owner opened Darpan's page AS Darpan, and one look reopened the session; F-132, F-133; kit `S188_D2c` live)
**Filenames (Phase-0 mapping) — every token transcribed from the file it names:** `KB_Register_v5_25_S188.md` (`fd14b63d894a15922f347318959a6f79`) · `KB_History_Archive_v1_38_S188.md` (`547f9f20e284b65a9af6250817c276cd`) · `Fault_Action_Register_v2_25.md` (`ba5feb1bc2f3c0ab4e1b82168723ab38`) · `HANDOFF_RUNBOOK_2026-08-18_Session188postclose_v124.md` (`ed9ed3f994c7c2642b37e0d8e48ce60d`) · `START_HERE_SESSION_189.md` **reissued** (`6262db09f823f7fbf7fa387ee5bc7e9e`) · this `CANONICAL_MANIFEST.md`.
- **Tier-0:** Register v5.24 → **v5.25** · Runbook v123 → **v124** · START_HERE 189 **reissued**. **Tier-1:** Archive v1.37 → **v1.38** (§S188-POST pure append; **734,024 characters** before the v1.37 END marker proven byte-identical, +4,788) · Fault Register v2.24 → **v2.25** (F-132, F-133; next free **F-134**). Both bumps proven zero-loss by **reverse application** onto the v5.24 and v2.24 pins.
- **Live VPS code (Register-pinned, NOT manifest rows):** `finance_app.py` `3a7086f8…` → **`f06e139b7651329a72b08bbc5779077f`** · `finance_ui/finance_entry.html` `2c23b461…` → **`d3844bb96a1d496e5882cfbbb695cbf4`** (kit `S188_D2c`, live smoke **478/478**). NEW `GET /finance/api/where-is-the-cash` (maker-safe) and `fy_start()` — parked cash scoped to the Indian financial year on the owner's ruling; the bank-trip clock deliberately NOT scoped.
- **F-132 is a fault in THIS CANON as much as in the code.** The claim *"payload unchanged, because it was already correctly scoped"* was written into kit `S188_D2a`, into Register v5.23, and into the message to the owner — **untested, and false for six hours.** Only a human opening the actual screen caught it. **RULE recorded: "already correctly scoped" is a test result or it is nothing.**
- **F-133 remains OPEN and is not a code fault.** The ledger's "cash in hand" (₹2,05,198) is overstated by handovers that were never entered as `cash_movement` rows; the capability has existed since S179 and has never once been used. Closing it needs the handovers entered retrospectively or a counted reconciliation of the S186 kind. Mitigated meanwhile by rendering the zero as an instruction.
- **Three kits this session, three projections written before measurement, three landed to the number** (453/453 · 464/464 · 478/478). Seven findings, all appended the session they were raised.
- ⭐ **S189 top tasks: F-133's ₹2 lakh question (the owner's books) · F-130's three-line design-fingerprint fix · F-131's 14 deletes · then the rest of the signed contract.** The one item only a person can do: **walk Darpan through Save → the check → File.** Cold-kit count **2 of 3–5**. Next free: **D329 · F-134 · A-D25 · Session 189.**

**END OF CANONICAL_MANIFEST — S188 POST-CLOSE.**

---

### §S188-FINAL EOS (18 Aug 2026 — F-134: the close-out routine's own missing step, found by running the check the routine is supposed to end with)
**Filenames (Phase-0 mapping) — every token transcribed from the file it names:** `KB_Register_v5_26_S188.md` (`3aa89f5a0c9dd7c6121c0a657dd573cd`) · `KB_History_Archive_v1_39_S188.md` (`81c34383365188632668898ffc50208c`) · `Fault_Action_Register_v2_26.md` (`09c072d8e403d901b36223b0a003512c`) · **`END_OF_SESSION_PROMPT_v5.md`** (`d2b6a22d0c195da311f8b6285f2cb375`) · `START_HERE_SESSION_189.md` reissued ×2 (`f04d19848a3a2c2b172e8e92f173d2d5`) · `HANDOFF_RUNBOOK … v124` unchanged (`ed9ed3f994c7c2642b37e0d8e48ce60d`) · this `CANONICAL_MANIFEST.md`.
- **F-134 is a fault in the ROUTINE, and this manifest is where the evidence sat.** The §S187 block records that the pin list was regenerated at that close — a sentence about what somebody once did. `END_OF_SESSION_PROMPT_v4` §A had no corresponding step, so the S188 close skipped it and `verify_live_pins.py` reported RED on `finance_app.py` and `finance_entry.html`, **two files the box had exactly right**, from a list still built on Register **v5.22**. **RULE: a derived artefact must be rebuilt in the same routine that changes its source; "someone did it last time" is narrative, only a numbered step is procedure.**
- **Tier-1 bump on the routine itself:** `END_OF_SESSION_PROMPT` **v4 → v5**, adding **A8** with the command, the `register_pin_verified: yes` check, and the ordering reason (it must follow A7 because F-110 makes the generator refuse a Register the manifest does not pin).
- **The pin list, regenerated:** from Register v5.26, `register_pin_verified: yes`, **43 VPS rows + 11 BLIND**, shipping as `deploy_kits/KB_canon_S188final/live_pins_S188final.txt`. **Owner action: one copy to `/root/deploy/live_pins.txt`, then re-run the checker — expect GREEN with `source : VERIFIED`.**
- **Session 188 final tally: three kits · three projections written before measurement, three landing on the number (453/453 · 464/464 · 478/478) · EIGHT findings, all appended the session they were raised · NO decision minted** (the whole session executes D326; next free stays **D329**).
- ⭐ **S189: F-133 (the ₹2 lakh — the owner's books) · F-130 (three lines per page) · F-131 (14 deletes) · then the rest of the signed contract.** The one item only a person can do: **walk Darpan through Save → the check → File.** Cold-kit count **2 of 3–5**. Next free: **D329 · F-135 · A-D25 · Session 189.**

**END OF CANONICAL_MANIFEST — S188 FINAL.**

---

### §S189 MID-SESSION FOLD (18 Aug 2026 — kit `S189_G1a` live, F-130 closed; F-135 and F-136 raised, F-136 fixed in this file; the pin recorded AS IT MOVED)

**This is not a close.** It is the S186/S188 practice applied at the moment the pin changed: *record
live pins as they move, not at the close* — because an unrecorded live pin is the F-97 condition.
The full §S189 EOS block, the Archive append and the Runbook bump come at the close.

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_27_S189.md` (`99b288309c2777b6c5d74c2662766c66`) ·
`Fault_Action_Register_v2_27.md` (`d8b13cf0aae35429d533f9f02bde39b6`) ·
`deploy_kits/S189_G1a/` (KIT_ID `S189_G1a 1d5bb4c12db97f84ea91ffd2617e0a70`) · this `CANONICAL_MANIFEST.md`.
`KB_History_Archive` stays **v1.39** and `HANDOFF_RUNBOOK` stays **v124** at this fold — both are owed
at the close, and are named here so the debt cannot go unrecorded (F-107's lesson applied forward).

- **Tier-0:** Register v5.26 → **v5.27**. **Tier-1:** Fault Register v2.26 → **v2.27**. Both bumps
  proven zero-loss by **reverse application** — strip exactly what S189 inserted, undo exactly what it
  edited, and require the result to equal the prior version byte-for-byte. Both reconstructions landed
  on this manifest's own pins, `3aa89f5a…` and `09c072d8…`. If anything else had moved, the hashes
  could not have matched.
- **Live VPS code (Register-pinned, NOT a manifest row; F-31 keeps PHI out):** `finance_app.py`
  `f06e139b…` → **`16faf98caa720a662316fa235a4b35b9`** (kit `S189_G1a`, live smoke **482/482**).
  **Thirty-five lines, every one inside `def selftest()` at line 6657 of 6710** — no route, page,
  query, migration or served byte touched. Built on live bytes recovered from `deploy_kits/S188_D2c`
  **by hash, not by filename** (D188), because the repo's `finance/` tree is now **eight** builds
  stale (F-97 part 2, still open).
- **The offline rehearsal was reconstructed from nothing but live bytes**, which is the reason its
  numbers mean anything: twelve live files recovered by md5, the four **additive** migrations applied
  (three hash-matched their Register pins exactly), and the four data-correcting migrations
  deliberately skipped. Projection **476/478 → 480/482** written before measuring; measured
  **480/482**. The offline check *total* (478) equalled the box's, and the box then went **482/482**.
- **F-135 raised and fixed in the build. F-136 raised and FIXED IN THIS FILE.** No decision minted —
  S189 so far is the execution of D326's backlog, and an implementation detail does not earn a
  D-number. Next free stays **D329**.
- **F-131 closed in practice:** the 14 `.git/index.lock.*` files are out of `.git/` and staged for the
  owner to delete. **`.gitattributes` extended** — `*.html`, `*.new` and `*.sql` pinned `eol=lf`,
  closing the gap D164 left when it stopped at `*.py`/`*.sh`; the duplicated `*.py` line found there
  was removed and the removal written into the file rather than done quietly.
- ⭐ **Still ahead at S189:** F-133's ₹2 lakh question (the owner's books) · the §4a ₹70,000 gate —
  **now safe to read, because S189 proved `staff-ledger.service` runs the Register-pinned
  `/root/staff_ledger.py`** · then the rest of the signed contract. Cold-kit count **2 of 3–5**.
  Next free: **D329 · F-137 · A-D25 · Session 189.**

**END OF CANONICAL_MANIFEST — S189 MID-SESSION FOLD.**

---

### §S189-B SECOND FOLD (18 Aug 2026 — the cash-custody build: F-137 closed across three kits, F-138 raised by an honest red and closed the same day; the pin recorded AS IT MOVED, twice)

**Still not a close.** The full §S189 EOS block, the Archive append and the Runbook bump remain owed at
the close and are named here so the debt cannot go unrecorded.

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_28_S189.md` (`741ecde44e4263f36a88c0baf0e45907`) ·
`Fault_Action_Register_v2_28.md` (`fcbfdefac3d83f07aa7ea28a30437b73`) ·
kits `S189_W1a` (KIT_ID `79a391f3b2abf083ce8c3edcb516a604`) · `S189_W1b` (KIT_ID
`747d4e2c8f0b9c09d8c3fa561678a543`) · `S189_C1a` (KIT_ID `7180e0f1149f194e99cb91cd2a7e5bb1` = the
migration sql's own md5) · this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.27 → **v5.28**. **Tier-1:** Fault Register v2.27 → **v2.28**. Both proven
  zero-loss by **reverse application** onto this manifest's own pins (`99b28830…` · `d8b13cf0…`).
- **Live VPS code (Register-pinned, NOT manifest rows):** `finance_app.py` `16faf98c…` →
  `583092c015c37d97fc240d09637b5ea7` (`S189_W1a`, 482 → 488) → **`41788368ec815b804d276df63c796575`**
  (`S189_W1b`, 488 → 488 — count-equal, proven by reproducing the F-138 red on a migrated copy: 485/488
  with every FAIL naming F-137, then 488/488 twice). **Migration `S189_custody` APPLIED** (second run;
  the first was RESTORED by the suite's own honest red, which is F-138): four `cash_custody_event` rows
  totalling **₹1,75,198 to the paise** against the 17 Aug `cash_count`; **cash in hand ₹2,05,198 →
  ₹2,05,198, gate-proven byte-identical** across `day_line`, movements, adjustments, expenses and the
  ledger net; backup `finance.db.bak_S189_C1a_20260818_171453`.
- **The correction this fold makes to THIS manifest's own record:** the S188-POST claim *"that
  overstatement is OPEN and is about the owner's books"* and Runbook v124's ⭐0b are **superseded by
  F-137 — there was no overstatement.** The books were right; the custody facts were recorded in prose
  where no query could reach them. F-133 closes with this fold: the capability unused since S179 now
  holds the counted position.
- **Darpan's card now reads:** Dr Manoj ₹18,963 · Dr Bhawna ₹1,56,235 · total ₹1,75,198 · as at the
  count of 17 Aug — with the bank-trip clock beside it. Cash in hand unchanged at ₹2,05,198
  (→ ₹1,75,198 once his ₹30,000 is entered, the same figure that was counted).
- **NO decision minted** — the owner's custody ruling is recorded inside F-137 rather than minted, per
  the S188 precedent that an execution detail does not earn a D-number; say the word and it becomes
  D329. Next free stays **D329 · F-139 · A-D25 · Session 189**. Cold-kit count **2 of 3–5**.
- ⭐ **Still ahead:** the §4a ₹70,000 gate (safe — S189 proved the service runs the Register-pinned
  ledger file) · Darpan's ₹30,000 · walk Darpan through Save → check → File · the signed contract.

**END OF CANONICAL_MANIFEST — S189 SECOND FOLD.**

---

### §S189-C THIRD FOLD (18 Aug 2026 — the expense menu live after its own gate refused the first kit; F-139 + F-140 raised, fixed and installed the same day; the §4a ₹70,000 gate VERIFIED OPEN)

**Still not a close.** The Archive §S189 append and the Runbook bump remain owed at the close.

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_29_S189.md` (`ef40881f3b68a355db34632128a08b74`) ·
`Fault_Action_Register_v2_29.md` (`b4c0e40cb788ee592bfb5fb7cd7abe24`) ·
**NEW Tier-1, FILED:** `S189_70k_Gate_Verification.md` (`563b2e3eaff5cf0d6bfa32450f7c8926`) ·
kits `S189_E1a` (KIT_ID `9eba2351563bf8265764a788bc164111` — **published, refused by its own gate,
retired unlived**) · `S189_E1b` (KIT_ID `99fc620153c5444e53f4da0893479810`) · this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.28 → **v5.29**. **Tier-1:** Fault Register v2.28 → **v2.29**. Both proven
  zero-loss by **reverse application** onto this manifest's own pins (`741ecde4…` · `fcbfdefa…`).
- **Live VPS code (Register-pinned, NOT manifest rows):** `finance_app.py` `41788368…` →
  **`5cb73ff83b591535053c7911026ecd8b`** · `finance_ui/finance_entry.html` `d3844bb9…` →
  **`1c7d2dc3179f29e9de0b9fb0d77c6fe1`** (kit `S189_E1b`, live smoke **488/488 → 509/509, +21
  exactly**). The E1a build (`7d6a87aa…`) was refused by its own gate and never installed. The one
  real `staff_ref` row is created lazily on Darpan's first real advance save — the selftest runs on a
  throwaway, so the live table stays empty until then, and that is correct.
- ⭐ **Ahead:** the ₹30,000 walkthrough (now menu-driven: ₹20,000 → *My salary advance* · ₹10,000 →
  *Other*, "Salary July settled in cash") · Darpan's Save → check → File walk-through · 14/15 Aug ·
  then EOS or the signed contract. Cold-kit count **2 of 3–5**. Next free: **D329 · F-141 · A-D25 ·
  Session 189.**

**END OF CANONICAL_MANIFEST — S189 THIRD FOLD.**

---

### §S189 EOS (18 Aug 2026, FULL — the close; D329 minted; the EOS automation boundary adopted; cold kit taken)

**S189 canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_30_S189.md` (`28b6ab06914fd5a6943956877d814cc0`) ·
`KB_History_Archive_v1_40_S189.md` (`464861906ca8cd4cd9a94a28f5afa33a`) ·
`Fault_Action_Register_v2_29.md` (`b4c0e40cb788ee592bfb5fb7cd7abe24`, unchanged at the close — nothing owed) ·
`HANDOFF_RUNBOOK_2026-08-18_Session189close_v125.md` (`98d43dc3145100338d3f1d91887ad19e`) ·
`START_HERE_SESSION_190.md` (`cb119685e718b9023d546da809fbe290`) ·
**NEW Tier-1:** `S189_Advance_Pool_Design_D329.md` (`2f9c7f1b701c8df74d542bce5945317f`, SIGNED CONTRACT) ·
`EOS_DEFINITION_PORTABLE.md` (`49864ebdf4e4ec4b87e432f9fcb2bf91`) · this `CANONICAL_MANIFEST.md`.

- **Tier-0 bumps:** Register v5.29 → **v5.30** (zero loss proven by reverse application) · Runbook
  v124 → **v125** · START_HERE 189 → **190**. **Tier-1:** Archive v1.39 → **v1.40** (§S189 pure
  append, the 742,406 characters before the v1.39 END marker proven byte-identical, +12,133; carries
  the D329 full text). Fault Register stays **v2.29** — F-130…F-140 were all appended the session
  they were raised; **nothing is owed**, the fifth consecutive clean close.
- **D329 MINTED** (the Advance Pool — full text Archive §S189; signed design pinned above). **No
  finding minted at the close**; `dev_seed_smoke_db.py`'s schema stall is recorded in Runbook §2 as
  the owner's call. Next free **D330 · F-141**.
- **The EOS automation boundary adopted (Runbook v125 §4, owner directive):** the assistant executes
  the entire close — documents A0–A8, the project-knowledge swap, Notion, the repo commit staged
  onto the PC, the cold kit when due. **The owner's residual work: one `PUBLISH_ALL.bat`
  double-click (the D328 boundary) + the on-box pin-list copy.** `EOS_DEFINITION_PORTABLE.md`
  generalises this for other projects.
- **Cold kit `KB_S189_close` taken AT the close** (count 3 of 3–5; next due ~S192–S194), written by
  the assistant to `D:\dr-manoj-git\cold_kits\`.
- **The pin list regenerated LAST (A8)** from Register v5.30: `register_pin_verified: yes`, 43 VPS +
  12 BLIND, shipping as `deploy_kits/KB_canon_S189/live_pins_S189close.txt`. **Owner action: one
  copy + one run — expect the fifth GREEN.**
- ⭐ **S190: the D329 build (SL1 → token → F1)**, after the ₹30,000 sitting if it hasn't happened.
  This was Session 189.

**END OF CANONICAL_MANIFEST — S189 CLOSE.**

---

### §S190 FIRST FOLD (19 Aug 2026 — kit `S190_E2` LIVE: D330 minted, executed the same session, supersedes D329; the pins recorded AS THEY MOVED)

**Not a close.** The Archive §S190 append and the Runbook bump are owed at the close and are named
here so the debt cannot go unrecorded (F-107's lesson applied forward).

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_31_S190.md` (`468bf4ca57bd806d87301320d42a0f3f`) ·
**NEW Tier-1, SIGNED + EXECUTED:** `S190_Expense_Menu_Redesign_D330.md` (`5bc70c4e6d6093984aa0779708ac3f3a`) ·
kit `S190_E2` (KIT_ID v2 `91918645db1354301169fbb732a45ec7`; v1 KIT_ID `de8ed3d622027c4fc851a35f33ac3d91`,
**refused by its own currency gate on the box — see below — payloads identical, never installed as v1**) ·
this `CANONICAL_MANIFEST.md`. `Fault_Action_Register` stays **v2.29** at this fold — two candidate
findings are **recorded in Register v5.31, not minted**; the owner's call whether either earns F-141.

- **Tier-0:** Register v5.30 → **v5.31**, zero loss proven by **reverse application** onto the
  `28b6ab06…` pin. **Tier-1:** the D330 contract FILED and pinned the session it was signed (the
  F-107 condition closed same-day); D329's row marked superseded, retained.
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `finance_app.py`
  `5cb73ff8…` → **`02062855ccd97056c2be64ce04d606cb`** · `finance_ui/finance_entry.html`
  `1c7d2dc3…` → **`f819bdf95de14fc331428cf6bea4c37e`** · `finance_ui/finance_entry_clinic.html`
  `0c64fda2…` → **`1c930a3ec71873ce774770dab524ba0e`** (kit `S190_E2`, live smoke
  **509/509 → 542/542, +33 exactly** — the sixth projection in a row to land on its number).
  Rehearsed offline on FOUR store shapes (F-140) including the month-at-ceiling post-sitting world.
  Schema: two lazy ALTERs + one lazy table, all additive; the schema's own CHECK on
  `category_fixed` (NULL/'salary_advance' only) was discovered by the rehearsal and left standing —
  the new categories live in `category_kind` beside it.
- **The gate refused kit v1, and it was right.** The installer's clinic-page constant carried a
  full md5 whose tail had been written from the truncated narrative prefix `0c64fda2…` — a value
  no file has ever had (the F-109/F-116 shape, in an installer). The D317 chain stopped at [2/7]
  with nothing touched; on-box `tr -d '\r'` comparison proved the payloads were built on the exact
  live bytes; kit v2 changed ONE constant, transcribed from the owner's own md5sum run. **The pin
  list had carried the full correct value all along — the Register's table is the source; a
  narrative prefix is a pointer, never a pin.** Also caught by the owner running it: the delivery
  note's install path said `/root/deploy` for `/root/deploy/repo` (the F-135 shape, from memory
  not the record). Both recorded, not minted.
- **D330 minted AND executed the same session** (the signed contract + Register v5.31 carry the
  full rulings: the derived ceiling — Darpan 75% of ₹20,000 = ₹15,000/month, all others 50%, over
  it the staff pipeline and never a drawer · compulsory evidence at File, no escape hatch · home =
  drawings, split in reporting · petty spends stay on the manual book, digital petty book PARKED ·
  clinic in scope expenses-only). **D329 superseded whole; next free D331 · F-141.**
- ⭐ **Ahead at S190:** the on-box pin-list copy + `verify_live_pins.py` (expect GREEN, match 45,
  VERIFIED) · the ₹30,000 sitting Part A on the NEW menu (proof line **₹1,85,198.00**) · Part B —
  31 July now SAFE to reopen (the refill ships in this kit): add the ₹10,000 advance to what comes
  back on screen (proof line **₹1,75,198.00**, the counted figure) · then EOS. Cold-kit count
  **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 FIRST FOLD.**

---

### §S190-B SECOND FOLD (19 Aug 2026 — D331 minted AND executed: the staff advance policy live on BOTH systems; the pins recorded AS THEY MOVED)

**Still not a close.** The Archive §S190 append and the Runbook bump remain owed at the close.

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_32_S190.md` (`82738bd79ebe9e322aedc560d8e9cf9b`) ·
**NEW Tier-1, SIGNED + EXECUTED + FILED:** `S190_Staff_Advance_Policy_D331.md`
(`fd7ff1636dbdecdc1a47722880d37814`) · kits `S190_SL2` (KIT_ID
`85914bde7a5da75928aaf2cd8598de47`) · `S190_F2` (KIT_ID `d88fc63e55847f6b630b98383e571484`) ·
this `CANONICAL_MANIFEST.md`. `Fault_Action_Register` stays **v2.29**; the two S190
candidate findings remain recorded-not-minted, the owner's F-141 ruling still open.

- **Tier-0:** Register v5.31 → **v5.32**, zero loss proven by reverse application onto the
  `468bf4ca…` pin. The D331 contract FILED and pinned the session it was signed (F-107 closed
  same-day, twice in one session).
- **Live VPS code (Register-pinned, NOT manifest rows):** `staff_ledger.py` `92665b64…` →
  **`0408bbbe9d31fc17c144a601dcd7d9b0`** (kit `S190_SL2`, selftest **190 → 212, +22 exactly**;
  `advance_pct.json` seeded `{"Darpan": 75}`; **the installer answered D331 §5.3 from the box's
  own `staff_master.csv`: base ₹20,000 → ceiling ₹15,000 at 75%**) · `finance_app.py`
  `02062855…` → **`ccc12afc54a0878e7b808c62034eb027`** · `finance_entry.html` `f819bdf9…` →
  **`b411269fd75bfcde3160b78dc28d6c77`** (kit `S190_F2`, live smoke **542 → 547, +5 exactly**).
  Four projections written before measuring this session-stage, four landed on the number —
  seven-through-ten consecutive.
- **The forward-only rule, recorded because it is the design's load-bearing beam:** the
  Sanjeevni gate counts ONLY ledger advances attributed forward (`against_month` ≠ entry
  month). A drawer draw is never forward-attributed, so no rupee can be counted in both
  books — the double-count D329's LINK machinery existed to prevent, solved structurally.
  Documented blind spot: a same-month direct-pipeline advance is not netted (rare by flow).
- **The month-at-ceiling rehearsal shape earned its keep twice more:** it caught the legacy
  advance checks going red on a post-sitting store (fixed: the throwaway raises the ceiling
  for attribution-and-menu blocks, restores it for the ceiling's own block) and a
  negative-room formatting bug in the F2 checks themselves.
- ⭐ **Ahead at S190:** owner one-clicks — PUBLISH_ALL + the on-box pin-list copy + verify
  (expect GREEN, match 45) · the sitting (Part A proof **₹1,85,198.00** · Part B proof
  **₹1,75,198.00**) · the three ledger entries (₹10,000 July · ₹15,000 August · ₹5,000
  **against September** — the inline line and the drawer limit now both know) · the F-141
  ruling · then EOS. Next free: **D332 · F-141 · A-D25.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 SECOND FOLD.**

---

### §S190-C THIRD FOLD (19 Aug 2026 — the owner's first live look fixed the quota's blind spot; the inline bill flow he ruled shipped the same hour; kits `S190_SL3` + `S190_F3` live)

**Still not a close.** The Archive §S190 append and the Runbook bump remain owed at the close.

**Filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_33_S190.md` (`34e31bd3dba0956867efb2d651622bdd`) · kits `S190_SL3` (KIT_ID
`1f2c65152fcecf87c73a6f5c921a1bc7`) · `S190_F3` (KIT_ID v2 `ebfa29af184116e9c8f9bc912f633f68`;
v1 `2f7906755f2e3fddd177467384f3510e` **refused by its own gate on the box** — the gate's
`tail -1` harness read a FAIL line as the summary; the refusal was the chain working, the
payloads never moved, v2 changed the harness only) · this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.32 → **v5.33**, zero loss proven by reverse application onto the
  `82738bd7…` pin.
- **The finding the owner's look produced (F-132 practice, recorded for the F-141 ruling):**
  SL2's month-counter counted every `ADVANCE_ISSUE` row by month, and the **S155 migration
  rows — years of loan history — are DATED August 2026**: Darpan's inline line read
  *"Rs 3,63,000 of Rs 15,000"* and his ordinary ₹15,000 entry would have been refused. No
  offline store could have caught it — the rehearsal store has no migration rows; the live
  look did. **Owner rulings:** the quota counts from the install forward (pre-install rows
  grandfathered — visible everywhere, recovering as normal, never eating the month);
  interest-bearing loans never consume the ordinary quota and bypass its gate; a new loan's
  application requirement stays procedural (wiring it would break the migration path —
  recorded, not hidden).
- **Live VPS code (Register-pinned, NOT manifest rows):** `staff_ledger.py` `0408bbbe…` →
  **`3b09073a3dd0142a61c80d5a6d7aa711`** (kit `S190_SL3`, selftest **212 → 214, +2 exactly**) ·
  `finance_app.py` `ccc12afc…` → **`7445d20dc87a2650ab21144558a2aebf`** ·
  `finance_entry.html` `b411269f…` → **`bae2dd8983c8c3b886705a4f6b6d8dba`** ·
  `finance_entry_clinic.html` `1c930a3e…` → **`d4f7ddaa4c2151935bc81f1bf38c8945`** (kit
  `S190_F3`, count-equal **proven by reproduction on the box: 545/547 with exactly two fails
  both naming F3**, then 547/547). Session projection tally: **twelve consecutive landing
  exactly** (509→542→547→547-by-reproduction finance · 190→212→214 ledger).
- **The inline bill flow (owner ruling, from first live use):** the bill is a file input in
  the expense row, uploaded automatically on Save; File-with-pending becomes draft-save →
  upload → File; the scanner stays as the camera-now path; both units.
- ⭐ **Ahead:** owner one-command (pin-list copy + verify — expect GREEN, match 45) · the
  sitting (Part A **₹1,85,198.00** · Part B **₹1,75,198.00**) · the ledger entries (₹10,000
  July · ₹15,000 August · ₹5,000 **against September**) · the F-141 ruling · EOS. Next free:
  **D332 · F-141 · A-D25.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 THIRD FOLD.**

---

### §S190-D FOURTH FOLD (19 Aug 2026 — kit `S190_F4` live: the approved-day gate reads the unit role; the owner's third live-eyes finding of the day)

**Still not a close.** The Archive §S190 append and the Runbook bump remain owed at the close.

**Filenames — every token transcribed from the file it names:** `KB_Register_v5_34_S190.md`
(`fde2e11ab71d957d4aa2bc625db0e077`) · kit `S190_F4` (KIT_ID `51a6cee07124061ff31de8b9f5971d76`) ·
this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.33 → **v5.34**, zero loss proven by reverse application onto the
  `34e31bd3…` pin.
- **The finding (owner, on the real screen, F-132 practice):** the medical save's locked-day
  gate tested `u["role"] != "checker"` — the SSO **broker** role — so the doctor himself was
  refused from editing an approved day ("only the doctor can change it", shown to the doctor).
  The clinic save has carried the correct unit-roles form since S182; the medical twin never
  did, and today was the first re-edit of an approved medical day ever attempted. The F-84
  family. An audit found this the ONLY wrong `u["role"]` use in the file.
- **Live VPS code (Register-pinned):** `finance_app.py` `7445d20d…` →
  **`f95cc4911cb8f1218a19b691f9a3b686`** (kit `S190_F4`, live smoke **547 → 549, +2 exactly**
  — the fourteenth consecutive projection to land).
- ⭐ **Ahead:** owner one-command (pin-list copy + verify, expect GREEN match 45) · re-File
  31 July (now accepted) → approve → the sitting → the ledger entries · **the F-141 ruling —
  now FIVE candidates:** the fabricated hash tail · the wrong install path · the `tail -1`
  harness · the migration-dated quota · the broker-role locked-day gate · EOS. Next free:
  **D332 · F-141 · A-D25.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 FOURTH FOLD.**

---

### §S190-E FIFTH FOLD (19 Aug 2026 — kit `S190_F5`: an edited day is an app entry; the 31-July ₹10,000 IN THE BOOKS and approved)

**Still not a close.** The Archive §S190 append and the Runbook bump remain owed at the close.

**Filenames — every token transcribed from the file it names:** `KB_Register_v5_35_S190.md`
(`b8dc2cb1683e8ca08bc3b36ad749f6cb`) · kit `S190_F5` (KIT_ID `a217e764de5896c80d8b298c50fd06ad`) ·
this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.34 → **v5.35**, zero loss proven by reverse application onto the
  `fde2e11a…` pin.
- **The finding (owner, fourth live-eyes catch of the day):** his edited 31-July day
  vanished from the approvals queue while its ₹10,000 already counted — the day was
  imported (`source='legacy_sheet'`) and the queue hides legacy days by design. Fix: a
  correction re-marks the day `source='app'`, both units; the revision keeps the original.
- **Live VPS code:** `finance_app.py` `f95cc491…` → **`17e6b84ce90ca7d7a0a9ba0c668ab15f`**
  (kit `S190_F5`, live smoke **549 → 550, +1 exactly** — the fifteenth consecutive).
- **Books state:** 31-July ₹10,000 advance FILED and APPROVED (via `/finance/review`);
  cash in hand **₹1,95,198** → lands ₹1,75,198 after the sitting's ₹15,000 + ₹5,000.
- ⭐ **Ahead:** owner one-command (pin copy + verify, tenth GREEN) · the three LEDGER
  entries (₹10,000 dated 31 Jul · ₹15,000 Aug · ₹5,000 against Sept) · July squared off in
  staff salaries · the sitting (17 Aug) · 14/15 Aug + the 18 Aug draft · **F-141: SIX
  candidates** (the fabricated hash tail · the wrong install path · the tail-1 harness ·
  the migration-dated quota · the broker-role gate · the hidden-legacy queue) · EOS.
  Next free: **D332 · F-141 · A-D25.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 FIFTH FOLD.**

---

### §S190-F SIXTH FOLD (19 Aug 2026 — kit `S190_SL4`: the quota lane; the sitting's advances recover THEMSELVES)

**Still not a close.** The Archive §S190 append and the Runbook bump remain owed at the close.

**Filenames — every token transcribed from the file it names:** `KB_Register_v5_36_S190.md`
(`01567d7a5cabd55e2fc54f7b0ffd5d35`) · kit `S190_SL4` (KIT_ID `6b1a91898827399335801688a9099117`) ·
this `CANONICAL_MANIFEST.md`.

- **Tier-0:** Register v5.35 → **v5.36**, zero loss proven by reverse application onto the
  `b8dc2cb1…` pin.
- **The finding (owner, on Darpan's statement minutes after the three advances went in):**
  ₹10,000 · ₹15,000 · ₹5,000 all read "(waiting for the loan to clear)" — the D250
  waterfall queues every interest-free advance behind the loan book; right for legacy
  tranches, wrong for a month's own salary money. **OWNER RULING "A":** the ledger's own
  close recovers them — August's close takes ₹10,000 + ₹15,000, September's the ₹5,000;
  no manual workbook squaring.
- **The lane:** in `close_month()`, after the D331 eligibility filter, a QUOTA advance
  (explicit `against_month` · `interest=False` · `instalment == amount`) recovers in full
  in its own lane. A deliberately partial instalment opts back into the waterfall; a loan
  Skip pauses ONLY the waterfall. Waterfall order and arithmetic byte-untouched. Statement
  cards name the recovery month (first close ≥ the against-month — the July-attributed
  ₹10,000 collects at the August close, July being already closed).
- **Live VPS code:** `staff_ledger.py` `3b09073a…` → **`470bb1133046d9076de5a2edd413f66c`**
  (kit `S190_SL4`, selftest **214 → 218, +4 exactly** — the sixteenth consecutive
  projection). Backup `staff_ledger.py.bak_S190_SL4_20260819_101237`. Service active.
- **Books state:** 14 & 15 Aug APPROVED by the owner. All three ledger advances in
  (₹10,000 · 31 Jul · against Jul / ₹15,000 · 19 Aug · against Aug / ₹5,000 · 18 Aug ·
  against Sep). Cash in hand ₹1,75,198 — the counted figure, verified on the live tile.
- ⭐ **Ahead:** owner one-command (pin copy + verify, eleventh GREEN) · Darpan completes
  17 & 18 Aug drafts (real figures + scans) → approve · Surendra ₹8,000 PENDING decision
  (over his ₹5,200 ceiling; grandfathered entry) · **F-141: SIX candidates** (the
  fabricated hash tail · the wrong install path · the tail-1 harness · the migration-dated
  quota · the broker-role gate · the hidden-legacy queue) · EOS. Next free:
  **D332 · F-141 · A-D25.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S190 SIXTH FOLD.**

---

### §S190-G THE CLOSE (19 Aug 2026 — the full fold-in; no live code moved after the sixth fold)

**Filenames — every token transcribed from the file it names:** `KB_History_Archive_v1_41_S190.md`
(`cf1afacafd93de762ee41e6c31142e0f`) · `KB_Register_v5_37_S190.md` (`62183676254645e2b2c268a73f283d1a`) ·
`HANDOFF_RUNBOOK_2026-08-19_Session190close_v126.md` (`359b550e2dd2725e59673e7b85e34e4d`) ·
`START_HERE_SESSION_191.md` (`aa4af92ce62d7021ca22a3a07fa548cf`) · this `CANONICAL_MANIFEST.md`.

- **Archive v1.41:** §S190 pure append — the 754,537 characters before v1.40's END marker proven
  byte-identical, +11,188. The full session narrative, both decisions, the six F-141 candidates.
- **Register v5.36 → v5.37:** the close bump (pointers, lineage, end marker), zero loss proven by
  reverse application onto the `01567d7a…` pin.
- **Fault Register stays v2.29** — nothing owed: the F-141 ruling is the owner's, deferred to S191
  with six candidates recorded (Archive §S190 · Runbook v126 §2 ⭐2).
- **Session totals:** eight kits live (`S190_E2` 509→542 · `SL2` 190→212 · `F2` 542→547 · `SL3`
  212→214 · `F3` 547→547 reproduction-proven · `F4` 547→549 · `F5` 549→550 · `SL4` 214→218) —
  sixteen consecutive exact projections; two kit v1s refused by their own gates, both toolchain
  faults, both refusals right, nothing on the box moved either time; D330 + D331 minted and
  executed; the ₹30,000 sitting closed to the counted rupee (₹1,75,198.00, Chrome-verified); six
  mid-session folds zero-loss-proven; eleven GREEN `verify_live_pins.py` runs.
- **Cold kit NOT taken** (count 3 of 3–5; next due ~S192–S194).
- ⭐ **S191:** Darpan's real 17/18 Aug figures + scans → approve · Surendra's ₹8,000 PENDING ·
  the F-141 ruling · watch the first real SL4 month-end. Next free: **D332 · F-141 · A-D25.**
- **A8 (after this file was final):** the pin list regenerated from Register v5.37 —
  `live_pins_S190close.txt`, `register_pin_verified: yes`. The owner copies it to
  `/root/deploy/live_pins.txt` on the box.

---

### §S191 (19 Aug 2026 — the ruling session: the six S190 candidates become F-141 … F-146; NO live code moved, NO decision minted)

**Filenames — every token transcribed from the file it names:** `Fault_Action_Register_v2_30.md`
(`e38e9789278c7197893e563c5f2d7d19`) · `KB_Register_v5_38_S191.md`
(`c93139fd365a5cfd026ed28a8e122b75`) · this `CANONICAL_MANIFEST.md`.
`KB_History_Archive` stays **v1.41** and `HANDOFF_RUNBOOK` stays **v126** at this fold — both are
owed at the close, and are named here so the debt cannot go unrecorded (F-107's lesson applied
forward). `START_HERE_SESSION_191` unchanged.

- **Phase 0: GREEN, both halves of the document check.** `md5sum -c MD5SUMS_ALL.txt` against a fresh
  anonymous clone → **124 of 124 OK, exit 0, no WARNING** (the F-119 inverse check). The **F-88
  cross-check**: 198 full md5 tokens in this manifest, **183 matched real bytes in the repo**; the 15
  that did not are each legitimately non-document — the 3 D316 closed-as-lost rows, 3 Tier-2
  folder/project digests, 2 historical live-VPS code pins, 3 kit IDs (including both v1 kits their own
  gates refused), and 4 superseded doc versions appearing only in narrative. **F-123**: exactly one
  `CANONICAL_MANIFEST.md` (the other two are correctly named `.SNAPSHOT_S181` and
  `.RETIRED_S177_stale`). **F-107 inverse**: every Tier-0 doc in use has a row. **A8/F-134**: the pin
  list's `source_md5` was verified by hashing `KB_Register_v5_37_S190.md` directly — it equals both the
  list's claim and this manifest's CURRENT Register pin.
- **Tier-1:** Fault Register v2.29 → **v2.30**. **Tier-0:** Register v5.37 → **v5.38**. Both proven
  zero-loss by **reverse application** onto this manifest's own pins (`b4c0e40c…` · `62183676…`) —
  strip exactly what S191 inserted, undo exactly what it edited, require the result to equal the prior
  version byte-for-byte. *(Recorded because it is the discipline working on itself: the Fault
  Register's first reverse run reported **False**. The document was correct; the **proof harness** had
  stripped one newline too many in its own bookkeeping. Fixed and re-run to an exact match — F-142's
  rule, minted minutes earlier, firing on the tool that was minting it.)*
- **THE RULING (owner, S191).** The six candidates were raised at S190 and deliberately
  **recorded-not-minted**, because ruling on what earns a number is the owner's call; nothing was owed.
  Asked to rule, the owner's answer was that the call was the assistant's to make. **Five numbers, one
  fold:** **F-141** the fabricated hash tail, *with the E2 delivery note's wrong install path recorded
  inside it as a second instance* — same session, same root (a value written from narrative or memory
  with the record in reach), and splitting it would have made the F-109/F-116/F-135 family history less
  legible, not more · **F-142** the `tail -1` harness · **F-143** the migration-dated quota · **F-144**
  the broker-role locked-day gate · **F-145** the hidden-legacy queue · **F-146** a refusal that looks
  like a save. **F-146 is the only one left OPEN**: its discipline (verify in the BOOK, never on the
  form) is adopted and standing in Runbook v126 §1.3, but the UI fix that would make a server refusal
  impossible to mistake for a save is **specified and not built**. Next free **F-147** — and it agrees
  with the last index row, which is the check F-108 exists to demand.
- **No decision minted.** A ruling on findings already raised is not an architectural decision; next
  free stays **D332**. No live code moved this fold — no pin changed, so `verify_live_pins.py` is
  unaffected.
- **Surendra's ₹8,000 (Runbook v126 §2 ⭐1): left PENDING by owner ruling, and surveyed first.** Read
  from the live `/ledger/pending`: Rs 8,000 dated 2026-08-14, entered by shavez, *"given by dr
  bhawna"*, the only pending row, **no SPECIAL badge**. The behaviour was then read out of the live
  bytes — `staff_ledger_SL4.py` recovered from kit `S190_SL4` and hash-verified to the live pin
  `470bb113…` — rather than inferred: **(a)** Approve will succeed and will NOT demand an application,
  because `decide()` gates only on `r.get("special")` and this row predates SL2 by five days;
  **(b)** it will NOT consume his August quota, because `advance_month_taken()` counts only rows with an
  explicit `against_month` (the SL3 grandfathering, working structurally); **(c)** ⚠ **it will recover
  IN FULL at the August close** — no `against_month` puts it outside SL4's quota lane and into the D250
  waterfall, where he has no other open advance and the instalment defaulted to the whole amount, so
  `budget = min(8000, 8000)`. Against the ₹5,200 ceiling the record gives him, that is very nearly his
  whole month. **Also established: there is no route to change an instalment after approval** — the
  contra error says "adjust instalments instead", but no such handler exists in the file. A gentler
  recovery is reachable only by rejecting and re-entering with an instalment set at entry. The owner
  deferred; the fact is recorded here so the next session does not re-derive it.
- ⭐ **Ahead:** Darpan's real 17/18 Aug figures + scans → approve (Runbook §2 ⭐0) · Surendra's ₹8,000
  · the first real SL4 month-end (end Aug) · §2 item 4, the owed-and-named list · then the rest of the
  signed Daily Flow v2 contract. **Owed at the close: the Archive §S191 append and the Runbook bump.**
  Next free: **D332 · F-147 · A-D25 · Session 192.** Cold-kit count **3 of 3–5**.

**END OF CANONICAL_MANIFEST — S191 (mid-session fold block, retained).**

---

### §S191-B EOS (19 Aug 2026, FULL — the close; D332 minted and SIGNED; F-147…F-151 appended; NO live code moved, NO live data changed)

**S191-close canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_39_S191.md` (`28a807a04faf927a32087a04bd05d9bb`) ·
`KB_History_Archive_v1_42_S191.md` (`b59532f7cda15662a8bb86bf7a85c1b5`) ·
`Fault_Action_Register_v2_31.md` (`a9484bc4d20ffeb027c8e411a5f62cd0`) ·
`HANDOFF_RUNBOOK_2026-08-19_Session191close_v127.md` (`8d56943c95fbb17ae4603a467be011de`) ·
`START_HERE_SESSION_192.md` (`ec0bfa313fb1832d73dd80c96b2c3209`) ·
**NEW Tier-1, FILED:** `S191_Waiver_Capacity_Layer_D332_Design.md` (`b59e9fdf99aba91b6937c1eac8a103e6`, SIGNED CONTRACT) ·
`S191_Darpan_Money_Model_Objective_Report.md` (`e0de19c9c1ad04c03f9645c980f14bd5`) · this `CANONICAL_MANIFEST.md`.

- **Tier-0 bumps:** Register v5.38 → **v5.39** (zero loss proven by reverse application onto the `c93139fd…` pin — the
  reconstruction hashes to it exactly) · Runbook v126 → **v127** · START_HERE 191 → **192**. **Tier-1:** Archive v1.41 →
  **v1.42** (§S191 pure append; the 765,415 characters before v1.41's END marker proven byte-identical, +9,311) · Fault
  Register v2.30 → **v2.31** (F-147…F-151; next free **F-152**; reverse application onto the `e38e9789…` pin).
- **D332 MINTED AND SIGNED** — the Waiver, Defer & Repayment-Defined Advance layer; the contract FILED and pinned the
  session it was signed (the F-107 condition closed same-day). Full rulings in the contract + Archive §S191.
- **F-147 … F-151 appended the session they were raised** — none found by a failure; all five found because the owner
  asked for CONFIRMATION and it was performed against the live system instead of the record. All five OPEN pending the
  S192 builds (SL5 · SL6 · SL7 · F6).
- **Deliberately NOT filed, recorded so the F-107 inverse reads intent:** `Salary_July_2026_for_finalisation.xlsx` —
  all-staff salary data; F-31/D320 keep it out of the PUBLIC repo. It lives owner-side (PC, outside any git working
  tree) and closes the July month when the owner fills waivers + actual-paid.
- **No live code moved, no live data changed, no pin changed** — `verify_live_pins.py` expects the same 43. The gated
  data corrections (the ₹10,000 tripwire · the ₹20,000 SPECIAL · the July composition entry · pct 75→50) run at S192
  on the owner's separate explicit GO, each row shown before writing, ALL before the August close.
- **Cold kit NOT taken** (count 3 of 3–5 — due within 1–3 sessions; take at the S192 or S193 close).
- **A8 (after this file was final):** the pin list regenerated from Register v5.39 — `live_pins_S191close.txt`,
  `register_pin_verified: yes`. The owner's residual: one `PUBLISH_ALL.bat` double-click + the on-box copy + verify
  (expect the thirteenth GREEN).
- ⭐ **S192:** the gated corrections (⭐0) · the D332 builds · owner-side: Darpan's signed application, his introduction
  to the Sanjeevni daily entry portal, the July sheet finalisation, Surendra's ₹8,000 · watch the first real month-end.
  Next free: **D333 · F-152 · A-D25 · Session 192.**

**END OF CANONICAL_MANIFEST — S191 CLOSE.**

**END OF CANONICAL_MANIFEST — S190 CLOSE.**

---

### §S192 EOS (19 Aug 2026, FULL — the KB freed, three D332 kits live, the gated money corrections executed, F6 stopped at its design on purpose)

**S192 canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_40_S192.md` (`788139ae6d1a685f0a507e54cf3e4931`) ·
`KB_History_Archive_v1_43_S192.md` (`5a591dbcd72464429016ac05671447f4`) ·
`Fault_Action_Register_v2_32.md` (`a52fa15451d8ad614455030d9f6aac58`) ·
`HANDOFF_RUNBOOK_2026-08-19_Session192close_v128.md` (`9e854c1682ebc00cf65d08d5c151612f`) ·
`START_HERE_SESSION_193.md` (`6ed3ca023e7530297db3f92d02b142ab`) · this `CANONICAL_MANIFEST.md`.

- **Tier-0 bumps:** Register v5.39 → **v5.40** · Runbook v127 → **v128** · START_HERE 192 → **193**.
  **Tier-1:** Archive v1.42 → **v1.43** (§S192 pure append; the **786,212 bytes** before v1.42's END
  marker **proven byte-identical by direct comparison**, +14,280) · Fault Register v2.31 → **v2.32**
  (F-147/F-149/F-150/F-151 CLOSED; F-152 · F-153 · F-154 minted; §7 index extended and the next-free
  line advanced to **F-155** — the F-108 check, met).
- **Zero loss proven by REVERSE APPLICATION, not asserted.** The Register reconstruction — strip what
  S192 inserted, restore the one live-file line it replaced — hashes to `28a807a0…` **exactly**.
  *(Recorded because it is the discipline working on itself: the first reverse run reported a
  mismatch. The document was correct; the **proof harness** had failed to keep the original line it
  was meant to restore. Fixed and re-run to an exact match — the same shape as S191's own harness
  fault, and F-142's rule firing on the tool rather than the artefact.)*
- **Live VPS code (Register-pinned, NOT manifest rows; F-31 keeps PHI out):** `/root/staff_ledger.py`
  `470bb113…` → `0ed19495e026d9629b75294f39075dc2` (`S192_SL5`, 218 → 240) →
  `0279540ed8e6fe8ebd75781544ffc209` (`S192_SL6`, 240 → 274) →
  **`44e39d6abf34db5e11acc2223ac908d3`** (`S192_SL7`, 274 → 287). Three installs, **each landing
  first time on its stated number**, no rollback, no incident. New system categories `ADVANCE_DEFER`
  and `CAPACITY_HOLD`; new stores `ledger_settings.json` and `waivers_<YYYY-MM>.json`. **No schema
  change, no migration, no data write by any kit.**
- **Live DATA (the gated corrections, D332 §6 items 1–4, on a separate explicit GO):** contras
  `c287af8feea5` (−₹10,000, **the tripwire killed**), `aba609b148ee` (−₹15,000), `9b8462f9ac2e`
  (−₹5,000), each stamped with its original's `against_month` (see F-153); `advance_pct` Darpan
  **75 → 50**; ONE **₹20,000 SPECIAL** `0cc0b26b38c5` (**PENDING** on its signed application) with the
  owner's **8/4/4/4** schedule; a ₹0 record `791d321b9dd4` narrating the July zero. **Survey → dry run
  → GO → re-run the survey to verify.**
- **F-152 · F-153 · F-154 raised** (the owner having ruled at S191 that the call is the assistant's);
  **F-147 · F-149 · F-150 · F-151 CLOSED**; **F-148 open**. **No decision minted** — S192 executes
  D332; next free stays **D333**.
- **`.gitattributes` extended** (`*.md5`, `*.txt` → `eol=lf`) with the reasoning written into the file
  — F-152, found from a publish warning and fixed the same session.
- **The KB cleanup:** 47 superseded project-knowledge docs deleted, **every one proven byte-present in
  the git canon by md5 first**; knowledge **1,919,222 → 1,149,776 chars (96% → 57.5%)**; five
  Category-C docs deliberately kept. The S192 opening note deleted, its work done.
- **Three S192 documents live in project knowledge and are OWED to the repo at the S193 open** —
  named above with *md5 owed* rather than a placeholder, because a hash is transcribed from a file or
  it is not written (**F-116**). This is the **F-107** condition, recorded rather than left to be
  discovered.
- **Cold kit TAKEN** at this close (was 3 of 3–5 and due; count resets).
- ⭐ **S193 top tasks:** the owner's ⭐0 (scan Darpan's application, approve `0cc0b26b38c5` **before the
  August close** or the ₹8,000 shifts) · **`S192_F6`, whose FIRST task is the seeded store, not the
  feature** (F-87) · F-153's one line · the July salary close · watch the first month-end on the new
  machinery. Next free: **D333 · F-155 · A-D25 · Session 193.** This was Session 192.

**END OF CANONICAL_MANIFEST — S192 CLOSE.**


---

### §S193–§S197 THE FOLD-IN (23 Aug 2026, Session 197 — EOS-light, the S185 precedent; the four-session canon debt cleared in one pass; owner-delegated; NO live code moved, NO live data changed, NO pin moved)

**S197 canonical filenames (Phase-0 mapping) — every token transcribed from the file it names:**
`KB_Register_v5_41_S197.md` (`5e7ac4b96755af0ce097803b296f1a62`) ·
`KB_History_Archive_v1_44_S197.md` (`eba5247064e7a9ab6ebb24d84b64a44a`) ·
`Fault_Action_Register_v2_33.md` (`fc0a9d534101cc01d7beb0922d387e37`) ·
`HANDOFF_RUNBOOK_2026-08-23_Session197fold_v131.md` (`253165b9cf457e425b27a6b6325f8b9a`) ·
`START_HERE_SESSION_198.md` (`4de2d34bed0aa69727867b62eb62ac95`) ·
the filed S192–S196 project-knowledge docs (`KB_canon_S197fold/filed/`, each in its own `SUMS.md5`) ·
this `CANONICAL_MANIFEST.md`.

- **The context.** The canon had been folded only to **S192** while four full build sessions ran; S193–S196 lived as standalone `claude/S19x_*` close docs, and `verify_live_pins.py` had been **unprotecting since S193** (its list is generated from Register v5.40). Every START_HERE from 194 to 197 carried the debt as a standing caveat. This session cleared it — the F-108 pattern at four-session scale, resolved rather than deferred a fifth time.

- **The F-series fork RECONCILED FIRST** (it had frozen all bare F-numbers at the S196 close). Swept across the repo and project knowledge; **every circulated number keeps its meaning**: F-155–F-159 are S193's (F-155 consumed the canonical next-free; all five closed same-session), F-160–F-162 are S196's (no S194/S195 doc had used a bare F-160+ token), S194's recorded "F-160 candidate" is minted **F-163**, S195's five unnumbered faults are minted **F-164–F-168**. Numbering is deliberately non-chronological across F-160–F-168 — recorded, not silently reordered. **F-168 is the only new OPEN finding** (the read-only medical share). **F-148 and F-153 rows updated to CLOSED-S193.**

- **Tier-0 bumps:** Register v5.40 → **v5.41** (reverse-application-proven onto the `788139ae…` pin — strip what S197 inserted, restore the CURRENT-row displacements, and the reconstruction hashes to it exactly) · Runbook v128 → **v131** (v129/v130 were the debt; v129 filed at this fold, v130 already in `KB_canon_S196close/`) · START_HERE 193 → **198**. **Tier-1:** Archive v1.43 → **v1.44** (§S193…§S196 pure append; the **800,148 bytes** before v1.43's END marker **proven byte-identical by direct comparison**, +34,510) · Fault Register v2.32 → **v2.33** (F-155…F-168; reverse-application-proven onto the `a52fa154…` pin). Three durable S19x reference docs promoted to Tier-1 rows (the medical-watcher reference, the Auditor seed, the retention policy).

- **Decisions folded:** **D333** (S193 — the cash-position accountability model: drawer = closing − reserve − manoj; the drawer+reserve+manoj = unbanked invariant) and **D334** (S196 — the present-request policy: request-time-as-punch, same-day-only, no-punch guard, verify-then-doctor, month-count visibility). The reserved next-free decision line corrected **D317 → D335** (it had read D317 since S180 while D317–D334 were spent — the F-45 family at index scale, corrected not silent). Next free **D335 · F-169 · A-D25**.

- **The F-107 filing.** Every S192-owed doc (`S192_SL5_Live_Pin_Record`, `S192_Gated_Data_Corrections_Executed`, `S192_F6_Design_and_Survey`) and every S193–S196 narrative/design/finding/pin doc that had lived only in project knowledge was filed into `deploy_kits/KB_canon_S197fold/filed/` and hash-covered — closing the absence-blindness condition those sessions carried. The `S195_medical_kit/` code sources keep their existing home (project knowledge + `deploy_kits/S195_MARG/`).

- **No live pin moved this fold** — `verify_live_pins.py` expects the same **43**, now GREEN because the list was regenerated from v5.41 (A8): `live_pins_S197fold.txt`, `register_pin_verified: yes`. Owner residual: `PUBLISH_ALL.bat`, then on the box `git pull` + copy the list to `/root/deploy/live_pins.txt` + run the checker (expect the first GREEN since S192).

- **Cold kit TAKEN** at this fold (was due — 4 of 3–5 since S192; count resets).

- **Doc-drift recorded, not minted:** `END_OF_SESSION_PROMPT_v5.md` carries the **v6** routine internally (step A9, the Notion checkpoint, added at S194). The filename bump v5→v6 + the manifest/custom-instructions re-point is owed — folded forward, flagged so a future Phase 0 does not read it as a mismatch.

⭐ **S198:** the owner-action backlog (token rotation ⭐ highest severity · Darpan's application → approve `0cc0b26b38c5` before the August close · the ledger/filing items) · the Auditor's first reports · the August month-end on the new machinery · the builder backlog. Next free: **D335 · F-169 · A-D25 · Session 198.** This was Session 197.

**END OF CANONICAL_MANIFEST — S197 FOLD-IN.**
